# INSTRUKCJA WDROŻENIA PROJEKTU QR STUDIO NA PLATFORMĘ VERCEL

Dokument zawiera szczegółową instrukcję wdrożenia aplikacji **QR Studio** przy użyciu bezpłatnego narzędzia **Vercel Drop**.

---

## DWA WARIANTY PACZEK DEPLOYMENTOWYCH

Dla wygody przygotowane zostały dwie gotowe paczki ZIP w głównym katalogu projektu:

1. **`qr-studio-vercel-drop.zip` (ZALECANA PACZKA ŹRÓDŁOWA)**
   - Zawiera pełny kod źródłowy projektu (`src/`, `public/`, `package.json`, `vite.config.ts`, `vercel.json` itd.).
   - Vercel automatycznie wykryje framework Vite, zainstaluje zależności w chmurze (`npm ci`) i wygeneruje produkcyjną kompilację.

2. **`qr-studio-static-dist.zip` (ALTERNATYWNA PACZKA STATYCZNA)**
   - Zawiera skompilowaną stronę statyczną z katalogu `dist/` (`index.html`, `assets/`, `brand-logo.png`).
   - Przeznaczona do natychmiastowej publikacji na dowolnym serwerze statycznym (np. Netlify, GitHub Pages, Cloudflare Pages, Nginx) bez potrzeby budowania kodu.

---

## KROK PO KROKU: WDROŻENIE NA VERCEL DROP (ZALECANY SPOSÓB)

### Krok 1: Pobierz paczkę ZIP
Pobierz plik **`qr-studio-vercel-drop.zip`** z wygenerowanych zasobów projektu.

### Krok 2: Otwórz Vercel Drop w przeglądarce
Przejdź na oficjalną stronę szybkich wdrożeń Vercel:
👉 **[https://vercel.com/drop](https://vercel.com/drop)**

### Krok 3: Zaloguj się do konta Vercel
Jeśli nie jesteś zalogowany, zaloguj się na swoje bezpłatne konto Vercel (możesz użyć konta GitHub, GitLab, Bitbucket lub adresu e-mail).

### Krok 4: Przeciągnij i upuść plik ZIP
Przeciągnij plik `qr-studio-vercel-drop.zip` i upuść go w wyznaczonym obszarze na stronie Vercel Drop.

### Krok 5: Nazwij swój projekt
Wprowadź docelową nazwę projektu, np. `qr-studio-app` lub `moje-qr-studio`.

### Krok 6: Automatyczne wykrycie i budowanie
Platforma Vercel automatycznie odczyta plik `vercel.json` oraz `package.json`:
- **Framework Preset:** Vite
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Install Command:** `npm ci`

Kliknij **Deploy** i odczekaj około 30–45 sekund na zakończenie procesu instalacji i kompilacji.

### Krok 7: Gotowe! Otwórz adres aplikacji
Po zakończeniu budowania Vercel wygeneruje unikalny publiczny adres URL (np. `https://qr-studio-app.vercel.app`).
Kliknij odnośnik i przetestuj generowanie kodów QR, personalizację oraz pobieranie plików PNG i SVG.

---

## WAŻNA UWAGA DOTYCZĄCA PLANU VERCEL HOBBY I UŻYTKU KOMERCYJNEGO

- Bezpłatny plan **Vercel Hobby** przeznaczony jest do celów prywatnych, edukacyjnych oraz do prezentacji własnego portfolio programistycznego.
- Korzystanie z planu Hobby do prowadzenia komercyjnego serwisu SaaS lub płatnej sprzedaży usług może być niezgodne z regulaminem usługi Vercel.
- Przed wdrożeniem komercyjnym zapoznaj się z oficjalnym regulaminem platformy:
  👉 **[https://vercel.com/legal/terms](https://vercel.com/legal/terms)**

---

## CZĘSTO ZADAWANE PYTANIA (FAQ)

### Czy muszę wgrywać katalog `node_modules`?
**NIE.** Paczka `qr-studio-vercel-drop.zip` celowo nie zawiera katalogu `node_modules`. Vercel sam pobierze bezpieczne i zweryfikowane wersje pakietów przy użyciu skryptu `npm ci`.

### Czy aplikacja wymaga bazy danych lub kluczy API?
**NIE.** QR Studio działa w 100% lokalnie w przeglądarce użytkownika. Generowanie kodów QR oraz zapis historii w IndexedDB nie wymagają żadnego backendu ani zmiennych środowiskowych `.env`.
