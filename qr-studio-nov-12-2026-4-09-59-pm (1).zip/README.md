# QR Studio – Professional QR Code Generator

**QR Studio** is a modern, privacy-first, client-side web application for generating, customizing, exporting, and managing QR codes. Designed as a production-grade SaaS design tool, it operates 100% locally in the user's browser with zero backend or external tracking services.

---

## Key Features & Capabilities

### 1. Eight Core QR Code Generators

- **Standard QR:**
  - **URL:** Web addresses with full HTTP/HTTPS protocol validation and query parameter preservation.
  - **Text:** Plain text, Unicode, Polish characters, multiline text, and emojis.
  - **Wi-Fi:** Network SSID, password, WPA/WPA2, WEP, Open security, and hidden network flags with character escaping (`\:`, `\;`, `\\`, `,`).
  - **vCard:** Digital contact business cards compliant with vCard 3.0 specification (CRLF line folding and character escaping).

- **Business & Social QR:**
  - **WhatsApp Chat:** International phone number normalization and pre-filled message URL encoding (`wa.me`).
  - **Google Reviews:** Instant feedback links for Google Business Profiles.
  - **Call Us:** Instant phone dialer link (`tel:` URI).
  - **Google Maps:** Direct location sharing with complete map query links.

### 2. High-Performance Visual Customization

- **Foreground & Background Colors:** Custom hexadecimal color pickers with real-time WCAG 2.1 & QR machine contrast validation.
- **Six Design Presets:** One-click visual themes (Classic Black, Deep Indigo, Emerald Forest, Slate Monochrome, Sunset Crimson, Royal Purple).
- **Export Resolutions:** 256×256 px, 512×512 px, 1024×1024 px, and 2048×2048 px.
- **Error Correction Levels:** L (~7%), M (~15%), Q (~25%), and H (~30% recovery).
- **Optional Center Logo:** Brand overlay auto-scaled to a safe 16% width with protective white backing (circular or rounded square) and forced Level H error correction.

### 3. Production Export Engine

- **PNG Export:** High-resolution raster images rendered directly via HTML5 Canvas.
- **Vector SVG Export:** Scalable vector graphics with embedded SVG paths and XML declaration.
- **Privacy-Safe Filenames:** Standardized file naming (e.g., `qr-studio-wifi.png`, `qr-studio-vcard.svg`) without exposing user passwords or payloads.

### 4. Local History & IndexedDB Storage

- **IndexedDB Persistence:** Local storage database (`qr-studio-db`, store `qr-history`) supporting up to **50 saved items**.
- **Open in Editor:** Full 1:1 restoration of saved QR categories, types, form inputs, custom colors, and logo settings.
- **Management Tools:** Search, category/type filtering, title sorting, rename (max 60 chars), duplicate, single delete, and clear all history.

---

## Privacy & Security Disclaimers

> **Privacy Notice:** QR Studio processes all QR generation, image manipulation, SVG creation, and history storage locally inside the browser. No QR payloads, Wi-Fi passwords, or contact details are ever sent to remote servers or third-party APIs.
>
> **Storage Security:** Saved history is persisted in browser-local IndexedDB. IndexedDB is **not encrypted**. Anyone with physical or administrative access to your browser profile can inspect saved QR codes. Avoid saving sensitive credentials on shared devices.

---

## Technology Stack

- **Framework:** React 19
- **Language:** TypeScript 5.8 (Strict Mode enabled)
- **Build Tool:** Vite 8
- **Styling:** Tailwind CSS v4
- **QR Engine:** `qrcode` & `jsQR` (for live camera & file decoding verification)
- **Icons:** Lucide React
- **Storage:** Browser IndexedDB API
- **Testing & Quality:** Vitest / Node Test Runner & ESLint 10 Flat Config

---

## Development & Production Commands

| Command | Description |
| :--- | :--- |
| `npm run dev` | Starts the local Vite development server on `http://localhost:3000` |
| `npm run build` | Runs TypeScript compilation and generates optimized production build in `dist/` |
| `npm run preview` | Serves the `dist/` production build locally for QA verification |
| `npm run lint` | Runs ESLint and strict TypeScript type checking (`tsc --noEmit`) |
| `npm run typecheck` | Runs TypeScript type checking (`tsc --noEmit`) |
| `npm run test` | Executes unit test suite across validators, generators, and IndexedDB storage |
| `npm run clean` | Cleans production build output (`dist/`) |

---

## Project Directory Structure

```text
src/
├── assets/         # Static branding and logo assets
├── components/     # UI layout, modals, header, sidebar, customization panels
│   ├── history/    # History management modals and cards
│   ├── layout/     # App shell, navigation sidebar, top header
│   ├── qr/         # QR preview, customization, content selectors
│   └── ui/         # Reusable badges and primitives
├── features/       # Feature modules
│   └── qr/         # Generators, decoders, exporters, Wi-Fi, vCard, business logic, IndexedDB storage
├── hooks/          # React custom hooks
├── lib/            # Application constants, defaults, color presets
├── pages/          # Top-level page views (HomePage, HistoryPage)
├── types/          # TypeScript domain interfaces and discriminated unions
└── utils/          # Pure helper functions, hex validators, contrast calculators, unit tests
```

---

## License & Usage

Created for commercial SaaS production deployment. All rights reserved.
