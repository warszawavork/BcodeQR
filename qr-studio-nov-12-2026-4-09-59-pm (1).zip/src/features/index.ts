export * from './qr';

export interface FeatureModuleDescriptor {
  id: string;
  title: string;
  scope: string;
}

export const PLANNED_FEATURE_MODULES: readonly FeatureModuleDescriptor[] = [
  {
    id: 'generator',
    title: 'Multi-Format QR Generator',
    scope: 'URL, Plain Text, Wi-Fi Network, and vCard 3.0 payload builders.',
  },
  {
    id: 'customization',
    title: 'Visual Appearance Studio',
    scope: 'Foreground/background colors, dimensions, quiet zone, and ECC levels.',
  },
  {
    id: 'export',
    title: 'Lossless Export Engine',
    scope: 'High-DPI PNG rasterization and clean SVG vector downloads.',
  },
  {
    id: 'history',
    title: 'Local History Vault',
    scope: 'Zero-backend persistence in browser localStorage with instant reload.',
  },
] as const;
