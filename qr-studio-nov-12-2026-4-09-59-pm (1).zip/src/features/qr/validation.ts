import type { QrCodeType } from '@/types';
import { isValidHttpUrl } from '@/utils';

export interface QrValidationResult {
  isValid: boolean;
  error: string | null;
  sanitized: string;
}

/**
 * Maximum safe byte length for standard QR code at Error Correction Level M.
 * Version 40 with Binary (8-bit byte) encoding supports up to 2331 bytes.
 */
export const MAX_QR_BYTE_LENGTH = 2300;

/**
 * Calculates the UTF-8 byte length of a string.
 */
export function getUtf8ByteLength(value: string): number {
  return new TextEncoder().encode(value).length;
}

/**
 * Validates content for the specified QR type.
 * Returns sanitized string and user-friendly error message if invalid.
 */
export function validateQrInput(
  type: QrCodeType,
  rawContent: string
): QrValidationResult {
  const sanitized = rawContent.trim();

  if (!sanitized) {
    return {
      isValid: false,
      error: 'Enter some content to generate your QR code.',
      sanitized: '',
    };
  }

  const byteLength = getUtf8ByteLength(sanitized);
  if (byteLength > MAX_QR_BYTE_LENGTH) {
    return {
      isValid: false,
      error: 'This content is too long for a standard QR code.',
      sanitized,
    };
  }

  if (type === 'url') {
    if (!isValidHttpUrl(sanitized)) {
      return {
        isValid: false,
        error: 'Please enter a valid HTTP or HTTPS URL.',
        sanitized,
      };
    }
  }

  return {
    isValid: true,
    error: null,
    sanitized,
  };
}
