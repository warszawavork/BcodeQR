import QRCode from 'qrcode';
import type { QrStyleConfig } from '@/types';
import { DEFAULT_QR_STYLE } from '@/lib/constants';

export interface QrGenerationOptions extends Partial<QrStyleConfig> {
  width?: number;
}

/**
 * Helper to load an image from a Data URL or URL as an HTMLImageElement.
 */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(new Error('Failed to load image for QR overlay: ' + e));
    img.src = src;
  });
}

/**
 * Draws rounded rectangle path onto canvas context.
 */
function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

/**
 * Overlays a center logo with safe backing onto a generated QR canvas.
 */
async function overlayLogoOnCanvas(
  baseQrDataUrl: string,
  width: number,
  logoUrl: string,
  backingShape: 'circle' | 'rounded'
): Promise<string> {
  if (typeof document === 'undefined') {
    return baseQrDataUrl;
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = width;
  const ctx = canvas.getContext('2d');
  if (!ctx) return baseQrDataUrl;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // 1. Draw base QR image
  const qrImg = await loadImage(baseQrDataUrl);
  ctx.drawImage(qrImg, 0, 0, width, width);

  // 2. Load logo
  try {
    const logoImg = await loadImage(logoUrl);

    // Strictly limit logo box to ~16% of QR width to guarantee scan tolerance
    const logoBoxSize = Math.round(width * 0.16);
    const padding = Math.max(4, Math.round(width * 0.025));
    const backingSize = logoBoxSize + padding * 2;

    const bx = (width - backingSize) / 2;
    const by = (width - backingSize) / 2;
    const center = width / 2;

    // 3. Draw Backing
    ctx.save();
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.12)';
    ctx.shadowBlur = Math.round(width * 0.015);
    ctx.shadowOffsetY = Math.round(width * 0.005);

    if (backingShape === 'circle') {
      ctx.beginPath();
      ctx.arc(center, center, backingSize / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      const radius = Math.round(backingSize * 0.22);
      drawRoundedRect(ctx, bx, by, backingSize, backingSize, radius);
      ctx.fill();
    }
    ctx.restore();

    // 4. Draw subtle backing border
    ctx.save();
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.08)';
    ctx.lineWidth = Math.max(1, Math.round(width * 0.003));
    if (backingShape === 'circle') {
      ctx.beginPath();
      ctx.arc(center, center, backingSize / 2, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      const radius = Math.round(backingSize * 0.22);
      drawRoundedRect(ctx, bx, by, backingSize, backingSize, radius);
      ctx.stroke();
    }
    ctx.restore();

    // 5. Draw logo centered with object-fit: contain proportions
    const lx = (width - logoBoxSize) / 2;
    const ly = (width - logoBoxSize) / 2;

    const logoAspect = (logoImg.naturalWidth || 1) / (logoImg.naturalHeight || 1);
    let drawW = logoBoxSize;
    let drawH = logoBoxSize;
    let drawX = lx;
    let drawY = ly;

    if (logoAspect > 1) {
      drawH = logoBoxSize / logoAspect;
      drawY = ly + (logoBoxSize - drawH) / 2;
    } else {
      drawW = logoBoxSize * logoAspect;
      drawX = lx + (logoBoxSize - drawW) / 2;
    }

    ctx.drawImage(logoImg, drawX, drawY, drawW, drawH);

    return canvas.toDataURL('image/png');
  } catch {
    // If logo loading fails, return base QR safely
    return baseQrDataUrl;
  }
}

/**
 * Generates a high-quality PNG Data URL representing a QR code.
 * Runs purely client-side in the browser using the qrcode library.
 */
export async function generateQrDataUrl(
  content: string,
  options?: QrGenerationOptions
): Promise<string> {
  const mergedStyle: QrStyleConfig = {
    ...DEFAULT_QR_STYLE,
    ...options,
    logo: {
      ...DEFAULT_QR_STYLE.logo,
      ...options?.logo,
    },
  };

  // When center logo is enabled, automatically enforce High ('H') error correction level
  const effectiveErrorCorrection = mergedStyle.logo.enabled
    ? 'H'
    : mergedStyle.errorCorrectionLevel;

  const targetWidth = options?.width ?? mergedStyle.size ?? 512;
  const targetMargin = Math.max(4, mergedStyle.margin ?? 4);

  try {
    const baseDataUrl = await QRCode.toDataURL(content, {
      errorCorrectionLevel: effectiveErrorCorrection,
      margin: targetMargin,
      width: targetWidth,
      color: {
        dark: mergedStyle.foregroundColor,
        light: mergedStyle.backgroundColor,
      },
    });

    if (mergedStyle.logo.enabled && mergedStyle.logo.dataUrl) {
      return await overlayLogoOnCanvas(
        baseDataUrl,
        targetWidth,
        mergedStyle.logo.dataUrl,
        mergedStyle.logo.backingShape
      );
    }

    return baseDataUrl;
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown QR generation error';
    throw new Error(`Failed to generate QR code: ${message}`, { cause: error });
  }
}

/**
 * Generates an SVG string representing a scalable vector QR code.
 */
export async function generateQrSvgString(
  content: string,
  options?: QrGenerationOptions
): Promise<string> {
  const mergedStyle: QrStyleConfig = {
    ...DEFAULT_QR_STYLE,
    ...options,
    logo: {
      ...DEFAULT_QR_STYLE.logo,
      ...options?.logo,
    },
  };

  const effectiveErrorCorrection = mergedStyle.logo.enabled
    ? 'H'
    : mergedStyle.errorCorrectionLevel;

  const targetWidth = options?.width ?? mergedStyle.size ?? 512;
  const targetMargin = Math.max(4, mergedStyle.margin ?? 4);

  try {
    let svg = await QRCode.toString(content, {
      type: 'svg',
      errorCorrectionLevel: effectiveErrorCorrection,
      margin: targetMargin,
      width: targetWidth,
      color: {
        dark: mergedStyle.foregroundColor,
        light: mergedStyle.backgroundColor,
      },
    });

    // If logo enabled, inject center logo into SVG before closing tag
    if (mergedStyle.logo.enabled && mergedStyle.logo.dataUrl) {
      // Validate data URL protocol for security (PNG, JPEG, WebP base64 only)
      const isSafeLogo =
        /^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/i.test(
          mergedStyle.logo.dataUrl.trim()
        );

      if (isSafeLogo) {
        // Extract coordinate space from viewBox (e.g. viewBox="0 0 37 37")
        const viewBoxMatch = svg.match(
          /viewBox="0 0 (\d+(\.\d+)?) (\d+(\.\d+)?)"/
        );
        const moduleCount = viewBoxMatch ? parseFloat(viewBoxMatch[1]) : 37;

        const logoBoxSize = moduleCount * 0.16;
        const padding = Math.max(0.4, moduleCount * 0.025);
        const backingSize = logoBoxSize + padding * 2;
        const bx = (moduleCount - backingSize) / 2;
        const by = (moduleCount - backingSize) / 2;
        const center = moduleCount / 2;

        let backingSvg = '';
        if (mergedStyle.logo.backingShape === 'circle') {
          backingSvg = `<circle cx="${center.toFixed(3)}" cy="${center.toFixed(
            3
          )}" r="${(backingSize / 2).toFixed(
            3
          )}" fill="#FFFFFF" stroke="rgba(0,0,0,0.08)" stroke-width="${Math.max(
            0.1,
            moduleCount * 0.005
          ).toFixed(3)}" />`;
        } else {
          const radius = backingSize * 0.22;
          backingSvg = `<rect x="${bx.toFixed(3)}" y="${by.toFixed(
            3
          )}" width="${backingSize.toFixed(3)}" height="${backingSize.toFixed(
            3
          )}" rx="${radius.toFixed(
            3
          )}" fill="#FFFFFF" stroke="rgba(0,0,0,0.08)" stroke-width="${Math.max(
            0.1,
            moduleCount * 0.005
          ).toFixed(3)}" />`;
        }

        const lx = (moduleCount - logoBoxSize) / 2;
        const ly = (moduleCount - logoBoxSize) / 2;
        const logoSvg = `<g id="qr-center-logo">${backingSvg}<image href="${
          mergedStyle.logo.dataUrl
        }" xlink:href="${
          mergedStyle.logo.dataUrl
        }" x="${lx.toFixed(3)}" y="${ly.toFixed(
          3
        )}" width="${logoBoxSize.toFixed(3)}" height="${logoBoxSize.toFixed(
          3
        )}" preserveAspectRatio="xMidYMid meet" /></g>`;

        svg = svg.replace('</svg>', `${logoSvg}</svg>`);
      }
    }

    // Add standalone XML declaration & XLINK namespace if missing
    if (!svg.includes('xmlns:xlink=')) {
      svg = svg.replace(
        '<svg ',
        '<svg xmlns:xlink="http://www.w3.org/1999/xlink" '
      );
    }
    if (!svg.startsWith('<?xml')) {
      svg = `<?xml version="1.0" encoding="UTF-8"?>\n${svg}`;
    }

    return svg;
  } catch (error) {
    const message =
      error instanceof Error ? error.message : 'Unknown QR generation error';
    throw new Error(`Failed to generate QR SVG: ${message}`, { cause: error });
  }
}
