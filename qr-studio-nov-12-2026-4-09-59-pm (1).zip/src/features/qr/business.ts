import type {
  CallFormData,
  GoogleMapsFormData,
  GoogleReviewsFormData,
  WhatsAppFormData,
} from '@/types';
import { isValidHttpUrl } from '@/utils';
import type { QrValidationResult } from './validation';

export const WHATSAPP_MESSAGE_PRESETS = [
  "Hello! I'd like to know more about your services.",
  'Could you please send me a price quotation?',
  "I'm interested in your products.",
  "I'd like to make an inquiry.",
] as const;

/**
 * Normalizes phone number for WhatsApp wa.me links.
 * WhatsApp requires digits only without '+', '00', spaces, dashes, or parentheses.
 * Official spec: https://faq.whatsapp.com/5913398998672934
 */
export function normalizeWhatsAppPhoneNumber(raw: string): string {
  if (!raw) return '';
  // Remove spaces, hyphens, brackets, dots, plus signs
  let cleaned = raw.replace(/[+\s\-()./\\]/g, '');
  // Strip leading international access code 00 if present
  if (cleaned.startsWith('00')) {
    cleaned = cleaned.slice(2);
  }
  return cleaned;
}

/**
 * Normalizes phone number for tel: URIs (RFC 3966).
 * Produces format: tel:+48500123456
 */
export function normalizeTelPhoneNumber(raw: string): string {
  if (!raw) return '';
  const trimmed = raw.trim();
  const hasPlus = trimmed.startsWith('+');
  let digits = trimmed.replace(/\D/g, '');

  if (digits.startsWith('00')) {
    digits = digits.slice(2);
    return `+${digits}`;
  }

  if (hasPlus) {
    return `+${digits}`;
  }

  // If user entered full international number without plus (e.g. 48500123456)
  if (digits.length >= 10) {
    return `+${digits}`;
  }

  return `+${digits}`;
}

/**
 * Validates international phone number string.
 * Must contain between 7 and 15 digits (ITU-T E.164 recommendation).
 */
export function isValidPhoneNumber(raw: string): boolean {
  const digits = raw.replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

/**
 * Builds the official WhatsApp click-to-chat URL.
 * wa.me format: https://wa.me/PHONENUMBER?text=ENCODED_MESSAGE
 */
export function buildWhatsAppUrl(data: WhatsAppFormData): string {
  const cleanPhone = normalizeWhatsAppPhoneNumber(data.phone);
  if (!cleanPhone) return '';

  const baseUrl = `https://wa.me/${cleanPhone}`;
  const message = data.message.trim();

  if (!message) {
    return baseUrl;
  }

  return `${baseUrl}?text=${encodeURIComponent(message)}`;
}

/**
 * Validates WhatsApp input fields.
 */
export function validateWhatsAppInput(
  data: WhatsAppFormData
): QrValidationResult {
  const rawPhone = data.phone.trim();
  if (!rawPhone) {
    return {
      isValid: false,
      error: 'Please enter a valid international phone number with country code.',
      sanitized: '',
    };
  }

  const cleanPhone = normalizeWhatsAppPhoneNumber(rawPhone);
  if (!/^\d{7,15}$/.test(cleanPhone)) {
    return {
      isValid: false,
      error:
        'Please enter a valid international phone number (7–15 digits including country code).',
      sanitized: '',
    };
  }

  const payload = buildWhatsAppUrl(data);
  return {
    isValid: true,
    error: null,
    sanitized: payload,
  };
}

/**
 * Builds and normalizes Google Review URL.
 */
export function buildGoogleReviewUrl(data: GoogleReviewsFormData): string {
  return data.reviewUrl.trim();
}

/**
 * Validates Google Reviews input.
 * Requires HTTPS protocol and valid URL structure.
 */
export function validateGoogleReviewInput(
  data: GoogleReviewsFormData
): QrValidationResult {
  const url = data.reviewUrl.trim();
  if (!url) {
    return {
      isValid: false,
      error: 'Please enter your Google Business review link.',
      sanitized: '',
    };
  }

  if (!url.startsWith('https://')) {
    return {
      isValid: false,
      error: 'Google Review links must use secure HTTPS protocol (https://).',
      sanitized: '',
    };
  }

  if (!isValidHttpUrl(url)) {
    return {
      isValid: false,
      error: 'Please enter a valid Google review web URL.',
      sanitized: '',
    };
  }

  return {
    isValid: true,
    error: null,
    sanitized: url,
  };
}

/**
 * Builds tel: URI for direct calling.
 */
export function buildPhoneUrl(data: CallFormData): string {
  const cleanTel = normalizeTelPhoneNumber(data.phone);
  return `tel:${cleanTel}`;
}

/**
 * Validates Call Us input fields.
 */
export function validatePhoneInput(data: CallFormData): QrValidationResult {
  const rawPhone = data.phone.trim();
  if (!rawPhone) {
    return {
      isValid: false,
      error: 'Please enter a telephone number for customers to call.',
      sanitized: '',
    };
  }

  if (!isValidPhoneNumber(rawPhone)) {
    return {
      isValid: false,
      error:
        'Please enter a valid phone number (7–15 digits, e.g. +48 500 123 456).',
      sanitized: '',
    };
  }

  const telUri = buildPhoneUrl(data);
  return {
    isValid: true,
    error: null,
    sanitized: telUri,
  };
}

/**
 * Builds and normalizes Google Maps share URL.
 */
export function buildGoogleMapsUrl(data: GoogleMapsFormData): string {
  return data.mapsUrl.trim();
}

/**
 * Validates Google Maps input fields.
 */
export function validateGoogleMapsInput(
  data: GoogleMapsFormData
): QrValidationResult {
  const url = data.mapsUrl.trim();
  if (!url) {
    return {
      isValid: false,
      error: 'Please enter or paste your Google Maps location link.',
      sanitized: '',
    };
  }

  if (!url.startsWith('https://')) {
    return {
      isValid: false,
      error: 'Google Maps links must start with https://.',
      sanitized: '',
    };
  }

  if (!isValidHttpUrl(url)) {
    return {
      isValid: false,
      error: 'Please enter a valid Google Maps URL.',
      sanitized: '',
    };
  }

  return {
    isValid: true,
    error: null,
    sanitized: url,
  };
}
