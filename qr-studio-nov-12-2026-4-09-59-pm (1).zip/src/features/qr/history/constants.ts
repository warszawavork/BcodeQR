import type { QrCodeType } from '@/types';

export const DB_NAME = 'qr-studio-db';
export const STORE_NAME = 'qr-history';
export const DB_VERSION = 1;
export const MAX_HISTORY_ITEMS = 50;

export const SENSITIVE_QR_TYPES: ReadonlyArray<QrCodeType> = [
  'wifi',
  'vcard',
  'whatsapp',
  'call',
  'text',
];

/**
 * Checks whether a given QR code type is considered sensitive.
 * Sensitive types trigger additional privacy disclosures prior to persistence.
 */
export function isSensitiveQrType(type: QrCodeType): boolean {
  return SENSITIVE_QR_TYPES.includes(type);
}
