import { useCallback, useEffect, useMemo, useState } from 'react';
import type { QrHistoryItem } from '@/types';
import {
  clearHistory,
  deleteHistoryItem,
  getHistoryItems,
  saveHistoryItem,
  updateHistoryItem,
} from './storage';
import { duplicateHistoryItem } from './utils';

export function useQrHistory() {
  const [items, setItems] = useState<QrHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isCancelled = false;

    getHistoryItems()
      .then((records) => {
        if (!isCancelled) {
          setItems(records);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        if (!isCancelled) {
          setError(
            err instanceof Error
              ? err.message
              : 'Unable to load saved QR codes from local storage.'
          );
          setIsLoading(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, []);

  const fetchItems = useCallback(async () => {
    try {
      const records = await getHistoryItems();
      setItems(records);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to load saved QR codes from local storage.'
      );
    }
  }, []);

  const handleSave = useCallback(
    async (item: QrHistoryItem) => {
      setError(null);
      await saveHistoryItem(item);
      await fetchItems();
    },
    [fetchItems]
  );

  const handleUpdate = useCallback(
    async (item: QrHistoryItem) => {
      setError(null);
      await updateHistoryItem(item);
      await fetchItems();
    },
    [fetchItems]
  );

  const handleDelete = useCallback(
    async (id: string) => {
      setError(null);
      await deleteHistoryItem(id);
      await fetchItems();
    },
    [fetchItems]
  );

  const handleDuplicate = useCallback(
    async (original: QrHistoryItem) => {
      setError(null);
      const duplicate = duplicateHistoryItem(original);
      await saveHistoryItem(duplicate);
      await fetchItems();
    },
    [fetchItems]
  );

  const handleClearAll = useCallback(async () => {
    setError(null);
    await clearHistory();
    await fetchItems();
  }, [fetchItems]);

  const counts = useMemo(() => {
    const total = items.length;
    const standard = items.filter((i) => i.category === 'standard').length;
    const business = items.filter((i) => i.category === 'business').length;
    return { total, standard, business };
  }, [items]);

  return {
    items,
    isLoading,
    error,
    totalCount: counts.total,
    standardCount: counts.standard,
    businessCount: counts.business,
    saveItem: handleSave,
    updateItem: handleUpdate,
    deleteItem: handleDelete,
    duplicateItem: handleDuplicate,
    clearAll: handleClearAll,
    refresh: fetchItems,
  };
}
