import type { QrCodeCategory, QrCodeType, QrHistoryItem } from '@/types';

export type HistorySortOption =
  | 'newest'
  | 'oldest'
  | 'recently-updated'
  | 'name-asc';

export interface HistoryFilterOptions {
  searchQuery?: string;
  category?: 'all' | QrCodeCategory;
  type?: 'all' | QrCodeType;
  sortBy?: HistorySortOption;
}

/**
 * Filters and sorts an array of QR history items according to search, category, type, and sort criteria.
 */
export function filterAndSortHistory(
  items: QrHistoryItem[],
  options: HistoryFilterOptions = {}
): QrHistoryItem[] {
  const {
    searchQuery = '',
    category = 'all',
    type = 'all',
    sortBy = 'newest',
  } = options;

  const normalizedQuery = searchQuery.trim().toLowerCase();

  const filtered = items.filter((item) => {
    // 1. Category Filter
    if (category !== 'all' && item.category !== category) {
      return false;
    }

    // 2. Type Filter
    if (type !== 'all' && item.type !== type) {
      return false;
    }

    // 3. Search Query Filter (Searches Title, Type name, Category)
    if (normalizedQuery) {
      const matchTitle = item.title.toLowerCase().includes(normalizedQuery);
      const matchType = item.type.toLowerCase().includes(normalizedQuery);
      const matchCategory = item.category.toLowerCase().includes(normalizedQuery);

      if (!matchTitle && !matchType && !matchCategory) {
        return false;
      }
    }

    return true;
  });

  // 4. Sort
  return filtered.sort((a, b) => {
    switch (sortBy) {
      case 'newest':
        return b.createdAt - a.createdAt;
      case 'oldest':
        return a.createdAt - b.createdAt;
      case 'recently-updated':
        return b.updatedAt - a.updatedAt;
      case 'name-asc':
        return a.title.localeCompare(b.title, undefined, { sensitivity: 'base' });
      default:
        return b.createdAt - a.createdAt;
    }
  });
}

/**
 * Validates and sanitizes a history item title (maximum 60 characters, non-empty).
 */
export function validateHistoryTitle(title: string): {
  isValid: boolean;
  sanitized: string;
  error?: string;
} {
  const trimmed = title.trim();

  if (!trimmed) {
    return {
      isValid: false,
      sanitized: '',
      error: 'Title cannot be empty.',
    };
  }

  if (trimmed.length > 60) {
    return {
      isValid: false,
      sanitized: trimmed.slice(0, 60),
      error: 'Title must not exceed 60 characters.',
    };
  }

  return {
    isValid: true,
    sanitized: trimmed,
  };
}

/**
 * Generates a clean duplicate of an existing QR history item with fresh ID and timestamps.
 */
export function duplicateHistoryItem(original: QrHistoryItem): QrHistoryItem {
  const now = Date.now();
  const title = `Copy of ${original.title}`.slice(0, 60);

  return {
    ...original,
    id: typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `qr_${now}_${Math.random().toString(36).slice(2, 9)}`,
    title,
    createdAt: now,
    updatedAt: now,
  };
}
