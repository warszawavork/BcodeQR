import type { QrHistoryItem } from '@/types';
import {
  DB_NAME,
  DB_VERSION,
  MAX_HISTORY_ITEMS,
  STORE_NAME,
} from './constants';

/**
 * In-memory fallback map for environments without IndexedDB (e.g., node test runner).
 */
const inMemoryStore = new Map<string, QrHistoryItem>();

/**
 * Determines if native IndexedDB is supported in the current environment.
 */
export function isIndexedDbSupported(): boolean {
  return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
}

/**
 * Validates the schema of an item retrieved from persistent storage.
 */
export function validateHistoryItem(item: unknown): item is QrHistoryItem {
  if (!item || typeof item !== 'object') return false;
  const candidate = item as Partial<QrHistoryItem>;

  if (typeof candidate.id !== 'string' || !candidate.id) return false;
  if (typeof candidate.title !== 'string') return false;
  if (typeof candidate.type !== 'string') return false;
  if (typeof candidate.category !== 'string') return false;
  if (typeof candidate.payload !== 'string') return false;
  if (!candidate.formData || typeof candidate.formData !== 'object') return false;
  if (!candidate.styleConfig || typeof candidate.styleConfig !== 'object') return false;
  if (typeof candidate.createdAt !== 'number') return false;
  if (typeof candidate.updatedAt !== 'number') return false;

  return true;
}

/**
 * Opens or upgrades the IndexedDB database.
 */
export function openHistoryDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!isIndexedDbSupported()) {
      reject(new Error('IndexedDB is not available in this environment.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('category', 'category', { unique: false });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(
        new Error(
          `Failed to open IndexedDB database: ${request.error?.message || 'Unknown error'}`
        )
      );
    };

    request.onblocked = () => {
      reject(new Error('IndexedDB open request was blocked by another open tab.'));
    };
  });
}

/**
 * Returns total number of stored QR history items.
 */
export async function countHistoryItems(): Promise<number> {
  if (!isIndexedDbSupported()) {
    return inMemoryStore.size;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const countReq = store.count();

    countReq.onsuccess = () => resolve(countReq.result);
    countReq.onerror = () =>
      reject(new Error(`Failed to count records: ${countReq.error?.message}`));
  });
}

/**
 * Retrieves all saved QR history items, sorted newest first.
 */
export async function getHistoryItems(): Promise<QrHistoryItem[]> {
  if (!isIndexedDbSupported()) {
    return Array.from(inMemoryStore.values()).sort(
      (a, b) => b.createdAt - a.createdAt
    );
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const getAllReq = store.getAll();

    getAllReq.onsuccess = () => {
      const records = (getAllReq.result || [])
        .filter(validateHistoryItem)
        .sort((a, b) => b.createdAt - a.createdAt);
      resolve(records);
    };

    getAllReq.onerror = () => {
      reject(
        new Error(`Failed to retrieve history items: ${getAllReq.error?.message}`)
      );
    };
  });
}

/**
 * Retrieves a single history item by its ID.
 */
export async function getHistoryItemById(
  id: string
): Promise<QrHistoryItem | null> {
  if (!id) return null;

  if (!isIndexedDbSupported()) {
    return inMemoryStore.get(id) || null;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(id);

    getReq.onsuccess = () => {
      const result = getReq.result;
      if (result && validateHistoryItem(result)) {
        resolve(result);
      } else {
        resolve(null);
      }
    };

    getReq.onerror = () => {
      reject(new Error(`Failed to fetch record by ID: ${getReq.error?.message}`));
    };
  });
}

/**
 * Saves a new QR history record. Enforces maximum capacity of 50 items.
 */
export async function saveHistoryItem(item: QrHistoryItem): Promise<void> {
  if (!validateHistoryItem(item)) {
    throw new Error('Invalid history item schema. Record cannot be saved.');
  }

  const currentCount = await countHistoryItems();
  const existing = await getHistoryItemById(item.id);

  if (!existing && currentCount >= MAX_HISTORY_ITEMS) {
    throw new Error(
      'Your history is full. Delete an existing QR code before saving another one.'
    );
  }

  if (!isIndexedDbSupported()) {
    inMemoryStore.set(item.id, item);
    return;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const putReq = store.put(item);

    putReq.onsuccess = () => resolve();
    putReq.onerror = () => {
      reject(new Error(`Failed to save record: ${putReq.error?.message}`));
    };
  });
}

/**
 * Updates an existing history item.
 */
export async function updateHistoryItem(item: QrHistoryItem): Promise<void> {
  if (!validateHistoryItem(item)) {
    throw new Error('Invalid history item schema. Record cannot be updated.');
  }

  if (!isIndexedDbSupported()) {
    if (!inMemoryStore.has(item.id)) {
      throw new Error(`Record with ID "${item.id}" not found.`);
    }
    inMemoryStore.set(item.id, {
      ...item,
      updatedAt: Date.now(),
    });
    return;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const updated = {
      ...item,
      updatedAt: Date.now(),
    };
    const putReq = store.put(updated);

    putReq.onsuccess = () => resolve();
    putReq.onerror = () => {
      reject(new Error(`Failed to update record: ${putReq.error?.message}`));
    };
  });
}

/**
 * Deletes a single history record by ID.
 */
export async function deleteHistoryItem(id: string): Promise<void> {
  if (!id) return;

  if (!isIndexedDbSupported()) {
    inMemoryStore.delete(id);
    return;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const delReq = store.delete(id);

    delReq.onsuccess = () => resolve();
    delReq.onerror = () => {
      reject(new Error(`Failed to delete record: ${delReq.error?.message}`));
    };
  });
}

/**
 * Permanently removes all records from history.
 */
export async function clearHistory(): Promise<void> {
  if (!isIndexedDbSupported()) {
    inMemoryStore.clear();
    return;
  }

  const db = await openHistoryDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const clearReq = store.clear();

    clearReq.onsuccess = () => resolve();
    clearReq.onerror = () => {
      reject(new Error(`Failed to clear history store: ${clearReq.error?.message}`));
    };
  });
}
