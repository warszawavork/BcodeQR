import test from 'node:test';
import assert from 'node:assert/strict';
import QRCode from 'qrcode';
import { generateQrDataUrl } from './generator';
import {
  createQrFilename,
  dataUrlToBlob,
  exportQrAsPng,
  exportQrAsSvg,
} from './export';
import {
  clearHistory,
  countHistoryItems,
  deleteHistoryItem,
  duplicateHistoryItem,
  filterAndSortHistory,
  getHistoryItemById,
  getHistoryItems,
  isSensitiveQrType,
  MAX_HISTORY_ITEMS,
  saveHistoryItem,
  updateHistoryItem,
  validateHistoryItem,
  validateHistoryTitle,
} from './history';
import {
  MAX_QR_BYTE_LENGTH,
  getUtf8ByteLength,
  validateQrInput,
} from './validation';

import {
  buildWifiPayload,
  escapeWifiField,
  validateWifiInput,
} from './wifi';
import {
  buildVCardPayload,
  escapeVCardValue,
  foldVCardLine,
  validateVCardInput,
} from './vcard';
import {
  buildPhoneUrl,
  buildWhatsAppUrl,
  normalizeTelPhoneNumber,
  normalizeWhatsAppPhoneNumber,
  validateGoogleMapsInput,
  validateGoogleReviewInput,
  validatePhoneInput,
  validateWhatsAppInput,
} from './business';
import {
  DEFAULT_QR_STYLE,
  QR_COLOR_PRESETS,
  QR_ERROR_CORRECTION_LEVELS,
  QR_SIZES,
} from '@/lib/constants';
import { getContrastRatio, isValidHexColor, isValidHttpUrl } from '@/utils';

// ---------------------------------------------------------------------------
// 1. URL & Text Tests
// ---------------------------------------------------------------------------

test('URL validation accepts valid HTTP and HTTPS URLs with paths and query params', () => {
  assert.equal(isValidHttpUrl('https://example.com'), true);
  assert.equal(isValidHttpUrl('http://subdomain.domain.org/path?query=1&b=2#hash'), true);
  assert.equal(isValidHttpUrl('https://qrstudio.dev/preview/qr-code'), true);
  assert.equal(isValidHttpUrl('http://localhost:3000'), true);
});

test('URL validation rejects invalid URLs or unsupported protocols', () => {
  assert.equal(isValidHttpUrl('ftp://example.com'), false);
  assert.equal(isValidHttpUrl('mailto:user@example.com'), false);
  assert.equal(isValidHttpUrl('not-a-valid-url'), false);
  assert.equal(isValidHttpUrl('https://'), false);
  assert.equal(isValidHttpUrl('   '), false);
  assert.equal(isValidHttpUrl('javascript:alert(1)'), false);
});

test('validateQrInput handles URL validation and error messages', () => {
  const emptyRes = validateQrInput('url', '   ');
  assert.equal(emptyRes.isValid, false);
  assert.equal(emptyRes.error, 'Enter some content to generate your QR code.');

  const invalidRes = validateQrInput('url', 'invalid-web-link');
  assert.equal(invalidRes.isValid, false);
  assert.equal(invalidRes.error, 'Please enter a valid HTTP or HTTPS URL.');

  const validRes = validateQrInput('url', '   https://example.com/test?a=1   ');
  assert.equal(validRes.isValid, true);
  assert.equal(validRes.error, null);
  assert.equal(validRes.sanitized, 'https://example.com/test?a=1');
});

test('validateQrInput handles Plain Text including Polish characters, newlines, and emoji', () => {
  const samplePolishText =
    'Hello from QR Studio!\nTo jest test polskich znaków:\nZażółć gęślą jaźń. 🚀✨';

  const res = validateQrInput('text', samplePolishText);
  assert.equal(res.isValid, true);
  assert.equal(res.error, null);
  assert.equal(res.sanitized, samplePolishText);
});

test('validateQrInput handles content exceeding maximum byte limits', () => {
  const hugeText = 'A'.repeat(MAX_QR_BYTE_LENGTH + 50);
  const res = validateQrInput('text', hugeText);
  assert.equal(res.isValid, false);
  assert.equal(res.error, 'This content is too long for a standard QR code.');
});

test('getUtf8ByteLength correctly measures ASCII, multi-byte Polish characters and emoji', () => {
  assert.equal(getUtf8ByteLength('abc'), 3);
  assert.equal(getUtf8ByteLength('ą'), 2);
  assert.equal(getUtf8ByteLength('🚀'), 4);
});

// ---------------------------------------------------------------------------
// 2. Wi-Fi Tests
// ---------------------------------------------------------------------------

test('escapeWifiField correctly escapes backslash, semicolon, comma, quote, and colon', () => {
  const unescaped = 'Test\\Name;With,Special"Chars:Here';
  const escaped = escapeWifiField(unescaped);
  assert.equal(escaped, 'Test\\\\Name\\;With\\,Special\\"Chars\\:Here');
});

test('buildWifiPayload produces standard ZXing Wi-Fi format for WPA network', () => {
  const payload = buildWifiPayload({
    ssid: 'Office_Studio_5G',
    encryption: 'WPA',
    password: 'SuperSecretPassword123',
    hidden: false,
  });
  assert.equal(payload, 'WIFI:T:WPA;S:Office_Studio_5G;P:SuperSecretPassword123;;');
});

test('buildWifiPayload produces standard ZXing Wi-Fi format for hidden WPA network', () => {
  const payload = buildWifiPayload({
    ssid: 'HomeNetwork',
    encryption: 'WPA',
    password: 'MyPassword123',
    hidden: true,
  });
  assert.equal(payload, 'WIFI:T:WPA;S:HomeNetwork;P:MyPassword123;H:true;;');
});

test('buildWifiPayload produces standard format for WEP network', () => {
  const payload = buildWifiPayload({
    ssid: 'Legacy_WEP_Net',
    encryption: 'WEP',
    password: 'abcde',
    hidden: false,
  });
  assert.equal(payload, 'WIFI:T:WEP;S:Legacy_WEP_Net;P:abcde;;');
});

test('buildWifiPayload produces standard format for open network without password field', () => {
  const payload = buildWifiPayload({
    ssid: 'Public_Guest_WiFi',
    encryption: 'nopass',
    password: 'ignored',
    hidden: false,
  });
  assert.equal(payload, 'WIFI:T:nopass;S:Public_Guest_WiFi;;');
});

test('validateWifiInput rejects empty SSID and SSID exceeding 32 UTF-8 bytes', () => {
  const emptyRes = validateWifiInput({
    ssid: '   ',
    encryption: 'WPA',
    password: 'password123',
    hidden: false,
  });
  assert.equal(emptyRes.isValid, false);
  assert.equal(emptyRes.error, 'Please enter a Wi-Fi network name (SSID).');

  // 33 ASCII bytes > 32 bytes max limit
  const tooLongSsid = 'A'.repeat(33);
  const longRes = validateWifiInput({
    ssid: tooLongSsid,
    encryption: 'WPA',
    password: 'password123',
    hidden: false,
  });
  assert.equal(longRes.isValid, false);
  assert.equal(longRes.error, 'Wi-Fi network name (SSID) cannot exceed 32 bytes.');
});

test('validateWifiInput validates WPA password requirements', () => {
  // Missing password
  const missingPwd = validateWifiInput({
    ssid: 'MyNetwork',
    encryption: 'WPA',
    password: '',
    hidden: false,
  });
  assert.equal(missingPwd.isValid, false);
  assert.equal(missingPwd.error, 'Please enter a password for WPA/WPA2 security.');

  // Too short (< 8 chars)
  const shortPwd = validateWifiInput({
    ssid: 'MyNetwork',
    encryption: 'WPA',
    password: 'short',
    hidden: false,
  });
  assert.equal(shortPwd.isValid, false);
  assert.ok(shortPwd.error?.includes('between 8 and 63 characters'));

  // Valid 64-hexadecimal key
  const hex64 = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  const hexRes = validateWifiInput({
    ssid: 'MyNetwork',
    encryption: 'WPA',
    password: hex64,
    hidden: false,
  });
  assert.equal(hexRes.isValid, true);
});

test('validateWifiInput validates WEP password requirements (ASCII 5/13 or Hex 10/26)', () => {
  // Valid 5 ASCII
  const ascii5 = validateWifiInput({
    ssid: 'WepNet',
    encryption: 'WEP',
    password: '12345',
    hidden: false,
  });
  assert.equal(ascii5.isValid, true);

  // Valid 10 Hex
  const hex10 = validateWifiInput({
    ssid: 'WepNet',
    encryption: 'WEP',
    password: '0123456789',
    hidden: false,
  });
  assert.equal(hex10.isValid, true);

  // Invalid length (7 characters)
  const invalidWep = validateWifiInput({
    ssid: 'WepNet',
    encryption: 'WEP',
    password: 'invalid',
    hidden: false,
  });
  assert.equal(invalidWep.isValid, false);
  assert.ok(invalidWep.error?.includes('5 or 13 ASCII characters'));
});

// ---------------------------------------------------------------------------
// 3. vCard 3.0 Tests
// ---------------------------------------------------------------------------

test('escapeVCardValue escapes backslashes, semicolons, commas, and newlines', () => {
  const raw = 'Smith; John, Senior\\Lead\nNew Line';
  const escaped = escapeVCardValue(raw);
  assert.equal(escaped, 'Smith\\; John\\, Senior\\\\Lead\\nNew Line');
});

test('buildVCardPayload generates standard vCard 3.0 structure with CRLF line endings', () => {
  const vcard = buildVCardPayload({
    firstName: 'John',
    lastName: 'Smith',
    organization: 'Example Company',
    jobTitle: 'Manager',
    phone: '+48 123 456 789',
    email: 'john@example.com',
    website: 'https://example.com',
  });

  assert.ok(vcard.startsWith('BEGIN:VCARD\r\nVERSION:3.0\r\n'));
  assert.ok(vcard.includes('N:Smith;John;;;\r\n'));
  assert.ok(vcard.includes('FN:John Smith\r\n'));
  assert.ok(vcard.includes('ORG:Example Company\r\n'));
  assert.ok(vcard.includes('TITLE:Manager\r\n'));
  assert.ok(vcard.includes('TEL;TYPE=CELL:+48 123 456 789\r\n'));
  assert.ok(vcard.includes('EMAIL:john@example.com\r\n'));
  assert.ok(vcard.includes('URL:https://example.com\r\n'));
  assert.ok(vcard.endsWith('END:VCARD\r\n'));
});

test('buildVCardPayload omits optional fields that are empty', () => {
  const vcard = buildVCardPayload({
    firstName: 'Anna',
    lastName: 'Nowak',
  });

  assert.ok(vcard.includes('N:Nowak;Anna;;;\r\n'));
  assert.ok(vcard.includes('FN:Anna Nowak\r\n'));
  assert.equal(vcard.includes('ORG:'), false);
  assert.equal(vcard.includes('TITLE:'), false);
  assert.equal(vcard.includes('TEL:'), false);
  assert.equal(vcard.includes('EMAIL:'), false);
  assert.equal(vcard.includes('URL:'), false);
});

test('buildVCardPayload supports first name only or last name only', () => {
  const firstOnly = buildVCardPayload({ firstName: 'Alex', lastName: '' });
  assert.ok(firstOnly.includes('N:;Alex;;;\r\n'));
  assert.ok(firstOnly.includes('FN:Alex\r\n'));

  const lastOnly = buildVCardPayload({ firstName: '', lastName: 'Taylor' });
  assert.ok(lastOnly.includes('N:Taylor;;;;\r\n'));
  assert.ok(lastOnly.includes('FN:Taylor\r\n'));
});

test('foldVCardLine folds lines exceeding 75 octets with CRLF space continuation', () => {
  const longOrg = 'ORG:' + 'A'.repeat(85);
  const folded = foldVCardLine(longOrg);
  assert.ok(folded.includes('\r\n '));
  const lines = folded.split('\r\n ');
  assert.equal(new TextEncoder().encode(lines[0]).length, 75);
});

test('validateVCardInput requires at least first or last name', () => {
  const res = validateVCardInput({
    firstName: '   ',
    lastName: '',
    organization: 'Acme',
  });
  assert.equal(res.isValid, false);
  assert.equal(res.error, 'Please enter at least a first or last name.');
});

test('validateVCardInput validates optional email address format', () => {
  const invalidEmail = validateVCardInput({
    firstName: 'John',
    lastName: 'Doe',
    email: 'not-an-email',
  });
  assert.equal(invalidEmail.isValid, false);
  assert.equal(invalidEmail.error, 'Please enter a valid email address.');

  const validEmail = validateVCardInput({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
  });
  assert.equal(validEmail.isValid, true);
});

test('validateVCardInput validates optional website URL format', () => {
  const invalidUrl = validateVCardInput({
    firstName: 'John',
    lastName: 'Doe',
    website: 'ftp://invalidscheme.com',
  });
  assert.equal(invalidUrl.isValid, false);
  assert.equal(invalidUrl.error, 'Please enter a valid website URL.');

  const validUrl = validateVCardInput({
    firstName: 'John',
    lastName: 'Doe',
    website: 'https://johndoe.dev',
  });
  assert.equal(validUrl.isValid, true);
});

// ---------------------------------------------------------------------------
// 4. Quality & Generator Integration Tests
// ---------------------------------------------------------------------------

test('DEFAULT_QR_STYLE enforces standard quiet zone margin of 4', () => {
  assert.equal(DEFAULT_QR_STYLE.margin, 4);
});

test('generateQrDataUrl generates valid QR for Wi-Fi and vCard payloads', async () => {
  const wifiPayload = buildWifiPayload({
    ssid: 'TestWiFi',
    encryption: 'WPA',
    password: 'password123',
    hidden: false,
  });
  const wifiDataUrl = await generateQrDataUrl(wifiPayload);
  assert.ok(wifiDataUrl.startsWith('data:image/png;base64,'));

  const vcardPayload = buildVCardPayload({
    firstName: 'Jan',
    lastName: 'Brzęczyszczykiewicz',
    organization: 'Chrząszczyżewoszyce Sp. z o.o.',
    jobTitle: 'Inżynier Oprogramowania',
  });
  const vcardDataUrl = await generateQrDataUrl(vcardPayload);
  assert.ok(vcardDataUrl.startsWith('data:image/png;base64,'));
});

test('QRCode matrix creation confirms exact payload encoding for Wi-Fi and vCard', () => {
  const wifi = 'WIFI:T:WPA;S:Studio\\;Net;P:P@ss\\:123;H:true;;';
  const qrWifi = QRCode.create(wifi, { errorCorrectionLevel: 'M' });
  assert.ok(qrWifi.modules.size >= 21);

  const vcard = 'BEGIN:VCARD\r\nVERSION:3.0\r\nN:Kowalski;Jan;;;\r\nFN:Jan Kowalski\r\nEND:VCARD\r\n';
  const qrVcard = QRCode.create(vcard, { errorCorrectionLevel: 'M' });
  assert.ok(qrVcard.modules.size >= 21);
});

// ---------------------------------------------------------------------------
// 5. Business & Social QR Tests
// ---------------------------------------------------------------------------

test('normalizeWhatsAppPhoneNumber cleans +, spaces, dashes, brackets, and leading 00', () => {
  assert.equal(normalizeWhatsAppPhoneNumber('+48 500 123 456'), '48500123456');
  assert.equal(normalizeWhatsAppPhoneNumber('+1 (555) 234-5678'), '15552345678');
  assert.equal(normalizeWhatsAppPhoneNumber('0048 500 123 456'), '48500123456');
  assert.equal(normalizeWhatsAppPhoneNumber('+44-20-7946-0958'), '442079460958');
  assert.equal(normalizeWhatsAppPhoneNumber(''), '');
});

test('buildWhatsAppUrl builds official wa.me URL without message', () => {
  const url = buildWhatsAppUrl({
    phone: '+48 500 123 456',
    message: '',
  });
  assert.equal(url, 'https://wa.me/48500123456');
});

test('buildWhatsAppUrl properly encodes messages with spaces, Polish chars, and emoji', () => {
  const url = buildWhatsAppUrl({
    phone: '+48 500 123 456',
    message: 'Dzień dobry! Chciałbym zapytać o ofertę 🚀',
  });
  assert.equal(
    url,
    'https://wa.me/48500123456?text=Dzie%C5%84%20dobry!%20Chcia%C5%82bym%20zapyta%C4%87%20o%20ofert%C4%99%20%F0%9F%9A%80'
  );

  // Verify decoded URL query parameter matches original text exactly (no double encoding)
  const parsed = new URL(url);
  assert.equal(
    parsed.searchParams.get('text'),
    'Dzień dobry! Chciałbym zapytać o ofertę 🚀'
  );
});

test('validateWhatsAppInput validates international phone number format', () => {
  // Empty phone
  const empty = validateWhatsAppInput({ phone: '   ', message: 'Hello' });
  assert.equal(empty.isValid, false);
  assert.ok(empty.error?.includes('valid international phone number'));

  // Too short (< 7 digits)
  const tooShort = validateWhatsAppInput({ phone: '+12345', message: '' });
  assert.equal(tooShort.isValid, false);
  assert.ok(tooShort.error?.includes('7–15 digits'));

  // Invalid letters
  const letters = validateWhatsAppInput({ phone: 'abcdefg', message: '' });
  assert.equal(letters.isValid, false);

  // Valid number
  const valid = validateWhatsAppInput({
    phone: '+48 500 123 456',
    message: 'Hello QR Studio',
  });
  assert.equal(valid.isValid, true);
  assert.equal(valid.sanitized, 'https://wa.me/48500123456?text=Hello%20QR%20Studio');
});

test('validateGoogleReviewInput requires HTTPS and validates valid review link', () => {
  // Empty
  const empty = validateGoogleReviewInput({
    businessName: 'My Business',
    reviewUrl: '   ',
  });
  assert.equal(empty.isValid, false);
  assert.ok(empty.error?.includes('Google Business review link'));

  // HTTP rejected (HTTPS required)
  const httpLink = validateGoogleReviewInput({
    businessName: 'My Business',
    reviewUrl: 'http://g.page/r/sample-review',
  });
  assert.equal(httpLink.isValid, false);
  assert.ok(httpLink.error?.includes('HTTPS'));

  // Invalid URL
  const invalid = validateGoogleReviewInput({
    businessName: '',
    reviewUrl: 'not a valid url',
  });
  assert.equal(invalid.isValid, false);

  // Valid HTTPS Google Review link
  const valid = validateGoogleReviewInput({
    businessName: 'My Business',
    reviewUrl: 'https://g.page/r/sample-business-review/review',
  });
  assert.equal(valid.isValid, true);
  assert.equal(valid.sanitized, 'https://g.page/r/sample-business-review/review');
});

test('normalizeTelPhoneNumber and buildPhoneUrl produce standard tel: URI', () => {
  assert.equal(normalizeTelPhoneNumber('+48 500 123 456'), '+48500123456');
  assert.equal(normalizeTelPhoneNumber('0048 500 123 456'), '+48500123456');

  const tel1 = buildPhoneUrl({
    phone: '+48 500 123 456',
    businessName: 'ROB-STAL',
  });
  assert.equal(tel1, 'tel:+48500123456');

  const tel2 = buildPhoneUrl({
    phone: '0048 500 123 456',
    businessName: '',
  });
  assert.equal(tel2, 'tel:+48500123456');
});

test('validatePhoneInput validates phone number format for Call Us', () => {
  // Empty
  const empty = validatePhoneInput({ phone: '', businessName: '' });
  assert.equal(empty.isValid, false);

  // Too short
  const short = validatePhoneInput({ phone: '123', businessName: '' });
  assert.equal(short.isValid, false);

  // Valid
  const valid = validatePhoneInput({
    phone: '+48 500 123 456',
    businessName: 'Company',
  });
  assert.equal(valid.isValid, true);
  assert.equal(valid.sanitized, 'tel:+48500123456');
});

test('validateGoogleMapsInput requires HTTPS and validates Maps share URL', () => {
  // Empty
  const empty = validateGoogleMapsInput({
    locationName: 'Warehouse',
    mapsUrl: '',
  });
  assert.equal(empty.isValid, false);

  // HTTP rejected
  const httpLink = validateGoogleMapsInput({
    locationName: '',
    mapsUrl: 'http://maps.google.com/?q=warehouse',
  });
  assert.equal(httpLink.isValid, false);
  assert.ok(httpLink.error?.includes('https://'));

  // Valid Maps link with query parameters
  const valid = validateGoogleMapsInput({
    locationName: 'ROB-STAL Warehouse',
    mapsUrl: 'https://maps.app.goo.gl/9bSDF8923h?entry=share',
  });
  assert.equal(valid.isValid, true);
  assert.equal(valid.sanitized, 'https://maps.app.goo.gl/9bSDF8923h?entry=share');
});

test('generateQrDataUrl generates valid QR for all 4 Business & Social payloads', async () => {
  const whatsappUrl = buildWhatsAppUrl({
    phone: '+48 500 123 456',
    message: 'Hello!',
  });
  const waDataUrl = await generateQrDataUrl(whatsappUrl);
  assert.ok(waDataUrl.startsWith('data:image/png;base64,'));

  const reviewUrl = 'https://g.page/r/sample-business-review/review';
  const reviewDataUrl = await generateQrDataUrl(reviewUrl);
  assert.ok(reviewDataUrl.startsWith('data:image/png;base64,'));

  const telUri = 'tel:+48500123456';
  const telDataUrl = await generateQrDataUrl(telUri);
  assert.ok(telDataUrl.startsWith('data:image/png;base64,'));

  const mapsUrl = 'https://maps.app.goo.gl/sample-location';
  const mapsDataUrl = await generateQrDataUrl(mapsUrl);
  assert.ok(mapsDataUrl.startsWith('data:image/png;base64,'));
});

// ---------------------------------------------------------------------------
// 6. Customization & Brand Identity Tests
// ---------------------------------------------------------------------------

test('DEFAULT_QR_STYLE has default size 512, margin 4, EC level M, and logo disabled', () => {
  assert.equal(DEFAULT_QR_STYLE.size, 512);
  assert.equal(DEFAULT_QR_STYLE.margin, 4);
  assert.equal(DEFAULT_QR_STYLE.errorCorrectionLevel, 'M');
  assert.equal(DEFAULT_QR_STYLE.foregroundColor, '#0F172A');
  assert.equal(DEFAULT_QR_STYLE.backgroundColor, '#FFFFFF');
  assert.equal(DEFAULT_QR_STYLE.logo.enabled, false);
});

test('QR_SIZES defines the 4 predefined resolutions', () => {
  assert.deepEqual([...QR_SIZES], [256, 512, 1024, 2048]);
});

test('QR_COLOR_PRESETS defines all 6 official presets with high contrast', () => {
  assert.equal(QR_COLOR_PRESETS.length, 6);
  const ids = QR_COLOR_PRESETS.map((p) => p.id);
  assert.deepEqual(ids, [
    'classic',
    'midnight',
    'ocean',
    'emerald',
    'royal-violet',
    'crimson',
  ]);

  // Verify all 6 presets pass contrast requirements (> 4.5:1 WCAG AA)
  for (const preset of QR_COLOR_PRESETS) {
    const ratio = getContrastRatio(preset.foregroundColor, preset.backgroundColor);
    assert.ok(ratio !== null && ratio >= 7.0, `${preset.name} has ratio ${ratio}`);
  }
});

test('isValidHexColor validates 3-digit and 6-digit hex colors strictly', () => {
  assert.equal(isValidHexColor('#0F172A'), true);
  assert.equal(isValidHexColor('#FFF'), true);
  assert.equal(isValidHexColor('#ffffff'), true);
  assert.equal(isValidHexColor('123456'), false);
  assert.equal(isValidHexColor('#gggggg'), false);
  assert.equal(isValidHexColor('#1234'), false);
});

test('getContrastRatio correctly calculates WCAG luminance contrast', () => {
  // Black on White: ~21:1
  const blackOnWhite = getContrastRatio('#000000', '#ffffff');
  assert.ok(blackOnWhite !== null && blackOnWhite > 20);

  // Classic #0F172A on #FFFFFF: ~17:1
  const classic = getContrastRatio('#0F172A', '#FFFFFF');
  assert.ok(classic !== null && classic > 15);

  // Low contrast: #777777 on #888888 (< 2:1)
  const lowContrast = getContrastRatio('#777777', '#888888');
  assert.ok(lowContrast !== null && lowContrast < 2.0);

  // Identical colors: 1:1
  const identical = getContrastRatio('#123456', '#123456');
  assert.equal(identical, 1.0);
});

test('QR_ERROR_CORRECTION_LEVELS includes L, M, Q, H with recovery percentages', () => {
  const levels = QR_ERROR_CORRECTION_LEVELS.map((e) => e.level);
  assert.deepEqual(levels, ['L', 'M', 'Q', 'H']);
});

test('generateQrDataUrl generates valid QR for customized color presets and high resolution', async () => {
  const sampleUrl = 'https://qrstudio.dev/preview/demo';

  // 1. Ocean Preset
  const ocean = await generateQrDataUrl(sampleUrl, {
    foregroundColor: '#075985',
    backgroundColor: '#F0F9FF',
    size: 512,
  });
  assert.ok(ocean.startsWith('data:image/png;base64,'));

  // 2. Emerald Preset
  const emerald = await generateQrDataUrl(sampleUrl, {
    foregroundColor: '#065F46',
    backgroundColor: '#ECFDF5',
    size: 512,
  });
  assert.ok(emerald.startsWith('data:image/png;base64,'));

  // 3. Royal Violet Preset
  const violet = await generateQrDataUrl(sampleUrl, {
    foregroundColor: '#5B21B6',
    backgroundColor: '#F5F3FF',
    size: 1024,
  });
  assert.ok(violet.startsWith('data:image/png;base64,'));

  // 4. High Error Correction
  const highEc = await generateQrDataUrl(sampleUrl, {
    errorCorrectionLevel: 'H',
    size: 512,
  });
  assert.ok(highEc.startsWith('data:image/png;base64,'));
});

// ---------------------------------------------------------------------------
// 5. Professional Export Engine Tests (PNG, SVG, Filenames & Privacy)
// ---------------------------------------------------------------------------

test('createQrFilename generates privacy-safe, standardized filenames for all 8 types', () => {
  // Test PNG format
  assert.equal(createQrFilename('url', 'png'), 'qr-studio-url.png');
  assert.equal(createQrFilename('text', 'png'), 'qr-studio-text.png');
  assert.equal(createQrFilename('wifi', 'png'), 'qr-studio-wifi.png');
  assert.equal(createQrFilename('vcard', 'png'), 'qr-studio-vcard.png');
  assert.equal(createQrFilename('whatsapp', 'png'), 'qr-studio-whatsapp.png');
  assert.equal(createQrFilename('reviews', 'png'), 'qr-studio-google-reviews.png');
  assert.equal(createQrFilename('call', 'png'), 'qr-studio-call.png');
  assert.equal(createQrFilename('maps', 'png'), 'qr-studio-google-maps.png');

  // Test SVG format
  assert.equal(createQrFilename('url', 'svg'), 'qr-studio-url.svg');
  assert.equal(createQrFilename('whatsapp', 'svg'), 'qr-studio-whatsapp.svg');
  assert.equal(createQrFilename('wifi', 'svg'), 'qr-studio-wifi.svg');

  // Privacy verification: ensures no payload data leaks into the filename
  const filename = createQrFilename('wifi', 'png');
  assert.ok(!filename.includes('password'));
  assert.ok(!filename.includes('ssid'));
  assert.ok(!filename.includes('secret'));
});

test('dataUrlToBlob accurately converts base64 Data URL to binary Blob', () => {
  const sampleDataUrl =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
  const blob = dataUrlToBlob(sampleDataUrl);

  assert.equal(blob.type, 'image/png');
  assert.ok(blob.size > 0);
});

test('exportQrAsPng generates valid PNG Blob with correct MIME type image/png across all 4 resolutions', async () => {
  const payload = 'https://qrstudio.dev/portfolio';

  for (const resolution of [256, 512, 1024, 2048] as const) {
    const blob = await exportQrAsPng(payload, {
      ...DEFAULT_QR_STYLE,
      size: resolution,
    });

    assert.equal(blob.type, 'image/png');
    assert.ok(blob.size > 0);
  }
});

test('exportQrAsPng generates valid PNG Blob for all 8 QR code types', async () => {
  const payloads: Record<string, string> = {
    url: 'https://qrstudio.dev/product',
    text: 'Hello from QR Studio export engine',
    wifi: 'WIFI:T:WPA;S:StudioWifi;P:StrongPass123;;',
    vcard: 'BEGIN:VCARD\r\nVERSION:3.0\r\nN:Smith;John;;;\r\nFN:John Smith\r\nEND:VCARD',
    whatsapp: 'https://wa.me/48123456789?text=Hello',
    reviews: 'https://g.page/r/sample/review',
    call: 'tel:+48123456789',
    maps: 'https://maps.app.goo.gl/sample',
  };

  for (const [key, payload] of Object.entries(payloads)) {
    const blob = await exportQrAsPng(payload, DEFAULT_QR_STYLE);
    assert.equal(blob.type, 'image/png', `Failed for QR type ${key}`);
    assert.ok(blob.size > 0, `Empty blob for QR type ${key}`);
  }
});

test('exportQrAsPng rejects empty payloads with descriptive error', async () => {
  await assert.rejects(
    async () => {
      await exportQrAsPng('', DEFAULT_QR_STYLE);
    },
    { message: /empty payload/i }
  );
});

test('exportQrAsSvg generates valid standalone SVG XML with correct MIME type', async () => {
  const payload = 'https://qrstudio.dev/vector';
  const blob = await exportQrAsSvg(payload, DEFAULT_QR_STYLE);

  assert.equal(blob.type, 'image/svg+xml;charset=utf-8');
  assert.ok(blob.size > 0);

  const text = await blob.text();
  assert.ok(text.includes('xmlns="http://www.w3.org/2000/svg"'));
  assert.ok(text.includes('xmlns:xlink="http://www.w3.org/1999/xlink"'));
  assert.ok(text.includes('viewBox="0 0 '));
  assert.ok(text.includes('<path fill="#FFFFFF"'));
  assert.ok(text.includes('stroke="#0F172A"'));
});

test('exportQrAsSvg reflects custom preset colors accurately', async () => {
  const payload = 'https://qrstudio.dev/presets';
  const blob = await exportQrAsSvg(payload, {
    ...DEFAULT_QR_STYLE,
    foregroundColor: '#075985',
    backgroundColor: '#F0F9FF',
  });

  const text = await blob.text();
  assert.ok(text.includes('fill="#F0F9FF"'));
  assert.ok(text.includes('stroke="#075985"'));
});

test('exportQrAsSvg embeds center logo and backing shape safely as self-contained data URI', async () => {
  const payload = 'https://qrstudio.dev/branded';
  const dummyLogo =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';

  // 1. Circle Backing
  const circleBlob = await exportQrAsSvg(payload, {
    ...DEFAULT_QR_STYLE,
    logo: {
      enabled: true,
      dataUrl: dummyLogo,
      backingShape: 'circle',
    },
  });
  const circleSvg = await circleBlob.text();
  assert.ok(circleSvg.includes('<g id="qr-center-logo">'));
  assert.ok(circleSvg.includes('<circle '));
  assert.ok(circleSvg.includes('<image href="data:image/png;base64,'));
  assert.ok(circleSvg.includes('xlink:href="data:image/png;base64,'));
  assert.ok(!circleSvg.includes('http://external-untrusted-site.com'));

  // 2. Rounded Backing
  const roundedBlob = await exportQrAsSvg(payload, {
    ...DEFAULT_QR_STYLE,
    logo: {
      enabled: true,
      dataUrl: dummyLogo,
      backingShape: 'rounded',
    },
  });
  const roundedSvg = await roundedBlob.text();
  assert.ok(roundedSvg.includes('<g id="qr-center-logo">'));
  assert.ok(roundedSvg.includes('<rect '));
});

test('exportQrAsSvg generates valid vector output for all 8 QR code types', async () => {
  const payloads: Record<string, string> = {
    url: 'https://qrstudio.dev/product',
    text: 'Hello from QR Studio vector SVG',
    wifi: 'WIFI:T:WPA;S:VectorWifi;P:StrongPass123;;',
    vcard: 'BEGIN:VCARD\r\nVERSION:3.0\r\nN:Taylor;Alex;;;\r\nFN:Alex Taylor\r\nEND:VCARD',
    whatsapp: 'https://wa.me/48123456789?text=Vector',
    reviews: 'https://g.page/r/sample/review',
    call: 'tel:+48123456789',
    maps: 'https://maps.app.goo.gl/sample',
  };

  for (const [key, payload] of Object.entries(payloads)) {
    const blob = await exportQrAsSvg(payload, DEFAULT_QR_STYLE);
    assert.equal(blob.type, 'image/svg+xml;charset=utf-8', `Failed for ${key}`);
    const text = await blob.text();
    assert.ok(text.includes('</svg>'), `Incomplete SVG for ${key}`);
  }
});

// ---------------------------------------------------------------------------
// 6. QR History & Local Data Management Tests (IndexedDB, Limits, Privacy)
// ---------------------------------------------------------------------------

test('isSensitiveQrType flags Wi-Fi, vCard, WhatsApp, Call Us, and custom Text as sensitive', () => {
  assert.equal(isSensitiveQrType('wifi'), true);
  assert.equal(isSensitiveQrType('vcard'), true);
  assert.equal(isSensitiveQrType('whatsapp'), true);
  assert.equal(isSensitiveQrType('call'), true);
  assert.equal(isSensitiveQrType('text'), true);

  // Standard non-sensitive types
  assert.equal(isSensitiveQrType('url'), false);
  assert.equal(isSensitiveQrType('reviews'), false);
  assert.equal(isSensitiveQrType('maps'), false);
});

test('validateHistoryTitle enforces max 60 characters and rejects empty strings', () => {
  assert.equal(validateHistoryTitle('My Website').isValid, true);
  assert.equal(validateHistoryTitle('   ').isValid, false);
  assert.equal(validateHistoryTitle('').isValid, false);

  const longTitle = 'A'.repeat(61);
  const result = validateHistoryTitle(longTitle);
  assert.equal(result.isValid, false);
  assert.equal(result.sanitized.length, 60);
});

test('validateHistoryItem validates record schema and rejects corrupted objects', () => {
  const validRecord = {
    id: 'test-1',
    title: 'Valid QR',
    type: 'url' as const,
    category: 'standard' as const,
    payload: 'https://example.com',
    formData: { type: 'url' as const, url: 'https://example.com' },
    styleConfig: DEFAULT_QR_STYLE,
    createdAt: 1000,
    updatedAt: 1000,
    containsSensitiveData: false,
  };

  assert.equal(validateHistoryItem(validRecord), true);

  // Missing fields
  assert.equal(validateHistoryItem(null), false);
  assert.equal(validateHistoryItem({}), false);
  assert.equal(validateHistoryItem({ ...validRecord, id: '' }), false);
  assert.equal(validateHistoryItem({ ...validRecord, payload: undefined }), false);
});

test('duplicateHistoryItem creates an independent copy with a new ID and updated timestamp', () => {
  const original = {
    id: 'orig-1',
    title: 'Original QR',
    type: 'url' as const,
    category: 'standard' as const,
    payload: 'https://example.com',
    formData: { type: 'url' as const, url: 'https://example.com' },
    styleConfig: DEFAULT_QR_STYLE,
    createdAt: 1000,
    updatedAt: 1000,
    containsSensitiveData: false,
  };

  const copy = duplicateHistoryItem(original);
  assert.notEqual(copy.id, original.id);
  assert.equal(copy.title, 'Copy of Original QR');
  assert.equal(copy.payload, original.payload);
  assert.ok(copy.createdAt >= 1000);
});

test('filterAndSortHistory filters by category, type, and search query', () => {
  const sampleItems = [
    {
      id: '1',
      title: 'Company Landing Page',
      type: 'url' as const,
      category: 'standard' as const,
      payload: 'https://acme.org',
      formData: { type: 'url' as const, url: 'https://acme.org' },
      styleConfig: DEFAULT_QR_STYLE,
      createdAt: 100,
      updatedAt: 100,
      containsSensitiveData: false,
    },
    {
      id: '2',
      title: 'Office Guest Wi-Fi',
      type: 'wifi' as const,
      category: 'standard' as const,
      payload: 'WIFI:S:Guest;P:Pass123;;',
      formData: { type: 'wifi' as const, ssid: 'Guest', password: 'Pass123', encryption: 'WPA' as const, hidden: false },
      styleConfig: DEFAULT_QR_STYLE,
      createdAt: 200,
      updatedAt: 200,
      containsSensitiveData: true,
    },
    {
      id: '3',
      title: 'Customer WhatsApp Support',
      type: 'whatsapp' as const,
      category: 'business' as const,
      payload: 'https://wa.me/48123456789',
      formData: { type: 'whatsapp' as const, phone: '48123456789', message: '' },
      styleConfig: DEFAULT_QR_STYLE,
      createdAt: 300,
      updatedAt: 400,
      containsSensitiveData: true,
    },
  ];

  // 1. Filter by category
  const standardOnly = filterAndSortHistory(sampleItems, { category: 'standard' });
  assert.equal(standardOnly.length, 2);

  const businessOnly = filterAndSortHistory(sampleItems, { category: 'business' });
  assert.equal(businessOnly.length, 1);
  assert.equal(businessOnly[0].id, '3');

  // 2. Filter by type
  const wifiOnly = filterAndSortHistory(sampleItems, { type: 'wifi' });
  assert.equal(wifiOnly.length, 1);
  assert.equal(wifiOnly[0].id, '2');

  // 3. Search query
  const searchAcme = filterAndSortHistory(sampleItems, { searchQuery: 'Landing' });
  assert.equal(searchAcme.length, 1);
  assert.equal(searchAcme[0].id, '1');

  // 4. Sort
  const oldestFirst = filterAndSortHistory(sampleItems, { sortBy: 'oldest' });
  assert.equal(oldestFirst[0].id, '1');

  const newestFirst = filterAndSortHistory(sampleItems, { sortBy: 'newest' });
  assert.equal(newestFirst[0].id, '3');

  const nameAsc = filterAndSortHistory(sampleItems, { sortBy: 'name-asc' });
  assert.equal(nameAsc[0].title, 'Company Landing Page');
});

test('storage repository manages CRUD lifecycle and enforces 50-record limit', async () => {
  // Clear any existing items first
  await clearHistory();
  assert.equal(await countHistoryItems(), 0);

  // Save record 1
  const item1 = {
    id: 'item-1',
    title: 'Item One',
    type: 'url' as const,
    category: 'standard' as const,
    payload: 'https://example1.com',
    formData: { type: 'url' as const, url: 'https://example1.com' },
    styleConfig: DEFAULT_QR_STYLE,
    createdAt: 1000,
    updatedAt: 1000,
    containsSensitiveData: false,
  };
  await saveHistoryItem(item1);
  assert.equal(await countHistoryItems(), 1);
  const allRecords = await getHistoryItems();
  assert.equal(allRecords.length, 1);
  assert.equal(allRecords[0].id, 'item-1');

  // Read record 1
  const fetched = await getHistoryItemById('item-1');
  assert.ok(fetched !== null);
  assert.equal(fetched.title, 'Item One');

  // Update record 1
  await updateHistoryItem({
    ...item1,
    title: 'Item One Renamed',
  });
  const updated = await getHistoryItemById('item-1');
  assert.equal(updated?.title, 'Item One Renamed');

  // Delete record 1
  await deleteHistoryItem('item-1');
  assert.equal(await countHistoryItems(), 0);
  assert.equal(await getHistoryItemById('item-1'), null);

  // Enforce 50-item limit test
  for (let i = 0; i < MAX_HISTORY_ITEMS; i++) {
    await saveHistoryItem({
      id: `limit-test-${i}`,
      title: `Item ${i}`,
      type: 'url',
      category: 'standard',
      payload: `https://test-${i}.com`,
      formData: { type: 'url', url: `https://test-${i}.com` },
      styleConfig: DEFAULT_QR_STYLE,
      createdAt: i,
      updatedAt: i,
      containsSensitiveData: false,
    });
  }
  assert.equal(await countHistoryItems(), 50);

  // Attempting to add 51st item should throw capacity error
  await assert.rejects(
    async () => {
      await saveHistoryItem({
        id: 'limit-test-overflow',
        title: 'Overflow Item',
        type: 'url',
        category: 'standard',
        payload: 'https://overflow.com',
        formData: { type: 'url', url: 'https://overflow.com' },
        styleConfig: DEFAULT_QR_STYLE,
        createdAt: 9999,
        updatedAt: 9999,
        containsSensitiveData: false,
      });
    },
    { message: /history is full/i }
  );

  // Clean up
  await clearHistory();
  assert.equal(await countHistoryItems(), 0);
});



