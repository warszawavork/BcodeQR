import type { QrCodeType, QrExportFormat, QrStyleConfig } from '@/types';
import { generateQrDataUrl, generateQrSvgString } from './generator';

export interface QrExportParams {
  payload: string;
  type: QrCodeType;
  format: QrExportFormat;
  style: QrStyleConfig;
}

export interface QrExportResult {
  blob: Blob;
  filename: string;
  format: QrExportFormat;
  sizeBytes: number;
}

/**
 * Privacy-safe type slugs for professional export file naming.
 * Crucial: Never includes user data (passwords, phone numbers, SSIDs, names, URLs).
 */
const TYPE_SLUG_MAP: Record<QrCodeType, string> = {
  url: 'url',
  text: 'text',
  wifi: 'wifi',
  vcard: 'vcard',
  whatsapp: 'whatsapp',
  reviews: 'google-reviews',
  call: 'call',
  maps: 'google-maps',
};

/**
 * Generates a clean, privacy-safe, lowercase filename for the exported QR code.
 * Follows official naming specifications: e.g. qr-studio-url.png, qr-studio-whatsapp.svg
 */
export function createQrFilename(
  type: QrCodeType,
  format: QrExportFormat,
  options?: { timestamp?: boolean }
): string {
  const slug = TYPE_SLUG_MAP[type] ?? 'code';
  const cleanFormat = format === 'svg' ? 'svg' : 'png';

  if (options?.timestamp) {
    const ts = new Date().toISOString().slice(0, 10);
    return `qr-studio-${slug}-${ts}.${cleanFormat}`.toLowerCase();
  }

  return `qr-studio-${slug}.${cleanFormat}`.toLowerCase();
}

/**
 * Converts a base64 Data URL to a native binary Blob with the correct MIME type.
 * Runs in memory without network requests.
 */
export function dataUrlToBlob(dataUrl: string): Blob {
  const match = dataUrl.match(/^data:([^;]+);base64,(.*)$/);
  if (!match) {
    throw new Error('Invalid Data URL format for Blob conversion');
  }

  const mimeType = match[1] || 'image/png';
  const binaryString = typeof atob !== 'undefined'
    ? atob(match[2])
    : Buffer.from(match[2], 'base64').toString('binary');

  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  return new Blob([bytes], { type: mimeType });
}

/**
 * Generates a high-resolution PNG Blob at the exact requested canvas resolution
 * (256, 512, 1024, or 2048 px) preserving colors, margin, EC level, and optional center logo.
 */
export async function exportQrAsPng(
  payload: string,
  style: QrStyleConfig
): Promise<Blob> {
  if (!payload || !payload.trim()) {
    throw new Error('Cannot export QR code with empty payload');
  }

  const targetWidth = style.size || 512;
  const dataUrl = await generateQrDataUrl(payload, {
    ...style,
    width: targetWidth,
  });

  return dataUrlToBlob(dataUrl);
}

/**
 * Generates a standalone, vector-based SVG Blob containing scalable vector paths
 * and an embedded logo (if enabled) in self-contained data URI format.
 */
export async function exportQrAsSvg(
  payload: string,
  style: QrStyleConfig
): Promise<Blob> {
  if (!payload || !payload.trim()) {
    throw new Error('Cannot export QR code with empty payload');
  }

  const svgString = await generateQrSvgString(payload, {
    ...style,
    width: style.size || 512,
  });

  return new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
}

/**
 * Triggers a browser download of the supplied Blob with the specified filename
 * and reliably cleans up temporary object URLs.
 */
export function downloadQrFile(blob: Blob, filename: string): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return;
  }

  const objectUrl = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = filename;
  anchor.style.display = 'none';

  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  // Revoke object URL after a short delay to allow browser download handling
  setTimeout(() => {
    window.URL.revokeObjectURL(objectUrl);
  }, 1500);
}

/**
 * Unified export pipeline function executing the full export flow:
 * 1. Validates inputs
 * 2. Generates PNG or SVG at configured settings
 * 3. Builds a privacy-safe filename
 * 4. Triggers client-side browser download
 */
export async function exportAndDownloadQr({
  payload,
  type,
  format,
  style,
}: QrExportParams): Promise<QrExportResult> {
  if (!payload || !payload.trim()) {
    throw new Error('Cannot export QR code: No valid payload provided');
  }

  const filename = createQrFilename(type, format);
  let blob: Blob;

  if (format === 'png') {
    blob = await exportQrAsPng(payload, style);
  } else if (format === 'svg') {
    blob = await exportQrAsSvg(payload, style);
  } else {
    throw new Error(`Unsupported export format: "${format}"`);
  }

  downloadQrFile(blob, filename);

  return {
    blob,
    filename,
    format,
    sizeBytes: blob.size,
  };
}
