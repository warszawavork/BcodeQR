import type { VCardFormData } from '@/types';
import { isValidHttpUrl } from '@/utils';
import {
  MAX_QR_BYTE_LENGTH,
  getUtf8ByteLength,
  type QrValidationResult,
} from './validation';

/**
 * Escapes characters for vCard 3.0 property values (RFC 2426).
 * Backslashes, semicolons, commas, and newlines must be escaped.
 */
export function escapeVCardValue(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r?\n/g, '\\n');
}

/**
 * Folds a single vCard logical line into physical lines of at most 75 octets,
 * breaking cleanly on Unicode character boundaries and prefixing continuation
 * lines with a single space as specified in RFC 2426.
 */
export function foldVCardLine(line: string, maxOctets = 75): string {
  const encoder = new TextEncoder();
  const encoded = encoder.encode(line);

  if (encoded.length <= maxOctets) {
    return line;
  }

  const chunks: string[] = [];
  let currentChunk = '';
  let currentByteLength = 0;
  // Continuation lines start with a space (1 byte), so subsequent lines have maxOctets - 1
  let limit = maxOctets;

  for (const char of line) {
    const charBytes = encoder.encode(char).length;

    if (currentByteLength + charBytes > limit && currentChunk.length > 0) {
      chunks.push(currentChunk);
      currentChunk = char;
      currentByteLength = charBytes;
      limit = maxOctets - 1; // 1 byte reserved for leading space
    } else {
      currentChunk += char;
      currentByteLength += charBytes;
    }
  }

  if (currentChunk.length > 0) {
    chunks.push(currentChunk);
  }

  return chunks.join('\r\n ');
}

/**
 * Builds a valid vCard 3.0 string formatted with CRLF line delimiters.
 */
export function buildVCardPayload(data: VCardFormData): string {
  const lines: string[] = ['BEGIN:VCARD', 'VERSION:3.0'];

  const firstName = data.firstName.trim();
  const lastName = data.lastName.trim();

  // Structured name: N:Family;Given;Additional;Prefix;Suffix
  lines.push(`N:${escapeVCardValue(lastName)};${escapeVCardValue(firstName)};;;`);

  // Formatted display name: FN:First Last
  const fullName = [firstName, lastName].filter(Boolean).join(' ');
  lines.push(`FN:${escapeVCardValue(fullName)}`);

  if (data.organization?.trim()) {
    lines.push(`ORG:${escapeVCardValue(data.organization.trim())}`);
  }

  if (data.jobTitle?.trim()) {
    lines.push(`TITLE:${escapeVCardValue(data.jobTitle.trim())}`);
  }

  if (data.phone?.trim()) {
    // Standard cellular telephone number
    lines.push(`TEL;TYPE=CELL:${data.phone.trim()}`);
  }

  if (data.email?.trim()) {
    lines.push(`EMAIL:${data.email.trim()}`);
  }

  if (data.website?.trim()) {
    lines.push(`URL:${data.website.trim()}`);
  }

  lines.push('END:VCARD');

  // Fold each line according to RFC 2426 line folding rules
  const foldedLines = lines.map((line) => foldVCardLine(line));

  // CRLF line endings required by vCard specification
  return `${foldedLines.join('\r\n')}\r\n`;
}

/**
 * Validates vCard form data before generating QR code payload.
 */
export function validateVCardInput(data: VCardFormData): QrValidationResult {
  const firstName = data.firstName.trim();
  const lastName = data.lastName.trim();

  // At least first or last name required
  if (!firstName && !lastName) {
    return {
      isValid: false,
      error: 'Please enter at least a first or last name.',
      sanitized: '',
    };
  }

  // Validate email if present
  if (data.email?.trim()) {
    const email = data.email.trim();
    const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!isValidEmail) {
      return {
        isValid: false,
        error: 'Please enter a valid email address.',
        sanitized: '',
      };
    }
  }

  // Validate website URL if present
  if (data.website?.trim()) {
    const website = data.website.trim();
    if (!isValidHttpUrl(website)) {
      return {
        isValid: false,
        error: 'Please enter a valid website URL.',
        sanitized: '',
      };
    }
  }

  const payload = buildVCardPayload(data);
  const byteLength = getUtf8ByteLength(payload);

  if (byteLength > MAX_QR_BYTE_LENGTH) {
    return {
      isValid: false,
      error: 'This content is too long for a standard QR code.',
      sanitized: '',
    };
  }

  return {
    isValid: true,
    error: null,
    sanitized: payload,
  };
}
