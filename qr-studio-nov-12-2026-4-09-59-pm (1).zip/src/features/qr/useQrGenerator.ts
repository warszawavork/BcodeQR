import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type {
  CallFormData,
  GoogleMapsFormData,
  GoogleReviewsFormData,
  QrCodeType,
  QrStyleConfig,
  VCardFormData,
  WhatsAppFormData,
  WifiFormData,
} from '@/types';
import { DEFAULT_QR_STYLE, QR_COLOR_PRESETS } from '@/lib/constants';
import {
  validateGoogleMapsInput,
  validateGoogleReviewInput,
  validatePhoneInput,
  validateWhatsAppInput,
} from './business';
import { generateQrDataUrl, generateQrSvgString } from './generator';
import { validateQrInput } from './validation';
import { validateVCardInput } from './vcard';
import { validateWifiInput } from './wifi';

export interface UseQrGeneratorOptions {
  initialType?: QrCodeType;
  initialStyle?: Partial<QrStyleConfig>;
  debounceMs?: number;
}

export type QrGeneratorStatus = 'idle' | 'generating' | 'success' | 'error';

const INITIAL_WIFI_DATA: WifiFormData = {
  ssid: '',
  encryption: 'WPA',
  password: '',
  hidden: false,
};

const INITIAL_VCARD_DATA: VCardFormData = {
  firstName: '',
  lastName: '',
  organization: '',
  jobTitle: '',
  phone: '',
  email: '',
  website: '',
};

const INITIAL_WHATSAPP_DATA: WhatsAppFormData = {
  phone: '',
  message: '',
};

const INITIAL_REVIEWS_DATA: GoogleReviewsFormData = {
  businessName: '',
  reviewUrl: '',
};

const INITIAL_CALL_DATA: CallFormData = {
  phone: '',
  businessName: '',
};

const INITIAL_MAPS_DATA: GoogleMapsFormData = {
  locationName: '',
  mapsUrl: '',
};

export function useQrGenerator({
  initialType = 'url',
  initialStyle,
  debounceMs = 280,
}: UseQrGeneratorOptions = {}) {
  const [type, setType] = useState<QrCodeType>(initialType);

  // Independent state per QR type to prevent data loss when switching tabs or categories
  const [urlValue, setUrlValue] = useState<string>('');
  const [textValue, setTextValue] = useState<string>('');
  const [wifiData, setWifiData] = useState<WifiFormData>(INITIAL_WIFI_DATA);
  const [vcardData, setVcardData] = useState<VCardFormData>(INITIAL_VCARD_DATA);
  const [whatsappData, setWhatsappData] =
    useState<WhatsAppFormData>(INITIAL_WHATSAPP_DATA);
  const [reviewsData, setReviewsData] =
    useState<GoogleReviewsFormData>(INITIAL_REVIEWS_DATA);
  const [callData, setCallData] = useState<CallFormData>(INITIAL_CALL_DATA);
  const [mapsData, setMapsData] = useState<GoogleMapsFormData>(INITIAL_MAPS_DATA);
  const [labelNote, setLabelNote] = useState<string>('');

  // Design customization state (preserved across tab and category switches)
  const [styleConfig, setStyleConfig] = useState<QrStyleConfig>(() => ({
    ...DEFAULT_QR_STYLE,
    ...initialStyle,
    logo: {
      ...DEFAULT_QR_STYLE.logo,
      ...initialStyle?.logo,
    },
  }));

  const [generatedDataUrl, setGeneratedDataUrl] = useState<string | null>(null);
  const [generatedSvg, setGeneratedSvg] = useState<string | null>(null);
  const [status, setStatus] = useState<QrGeneratorStatus>('idle');
  const [generationError, setGenerationError] = useState<string | null>(null);

  const requestIdRef = useRef<number>(0);

  // Compute validation and serialized QR payload synchronously during render
  const validation = useMemo(() => {
    switch (type) {
      case 'url': {
        const raw = urlValue.trim();
        if (!raw) return null;
        return validateQrInput('url', urlValue);
      }
      case 'text': {
        const raw = textValue.trim();
        if (!raw) return null;
        return validateQrInput('text', textValue);
      }
      case 'wifi': {
        const rawSsid = wifiData.ssid.trim();
        if (!rawSsid && !wifiData.password) return null;
        return validateWifiInput(wifiData);
      }
      case 'vcard': {
        const hasAnyContent = Boolean(
          vcardData.firstName.trim() ||
            vcardData.lastName.trim() ||
            vcardData.organization?.trim() ||
            vcardData.jobTitle?.trim() ||
            vcardData.phone?.trim() ||
            vcardData.email?.trim() ||
            vcardData.website?.trim()
        );
        if (!hasAnyContent) return null;
        return validateVCardInput(vcardData);
      }
      case 'whatsapp': {
        if (!whatsappData.phone.trim() && !whatsappData.message.trim()) {
          return null;
        }
        return validateWhatsAppInput(whatsappData);
      }
      case 'reviews': {
        if (!reviewsData.reviewUrl.trim() && !reviewsData.businessName.trim()) {
          return null;
        }
        return validateGoogleReviewInput(reviewsData);
      }
      case 'call': {
        if (!callData.phone.trim() && !callData.businessName.trim()) {
          return null;
        }
        return validatePhoneInput(callData);
      }
      case 'maps': {
        if (!mapsData.mapsUrl.trim() && !mapsData.locationName.trim()) {
          return null;
        }
        return validateGoogleMapsInput(mapsData);
      }
    }
  }, [
    type,
    urlValue,
    textValue,
    wifiData,
    vcardData,
    whatsappData,
    reviewsData,
    callData,
    mapsData,
  ]);

  const validationError =
    validation && !validation.isValid ? validation.error : null;
  const isInputValid = Boolean(validation?.isValid);
  const sanitizedPayload = validation?.sanitized ?? '';

  // Clear handler clears form fields without resetting design customizations
  const handleClear = useCallback(() => {
    requestIdRef.current += 1;
    setUrlValue('');
    setTextValue('');
    setWifiData(INITIAL_WIFI_DATA);
    setVcardData(INITIAL_VCARD_DATA);
    setWhatsappData(INITIAL_WHATSAPP_DATA);
    setReviewsData(INITIAL_REVIEWS_DATA);
    setCallData(INITIAL_CALL_DATA);
    setMapsData(INITIAL_MAPS_DATA);
    setLabelNote('');
    setGeneratedDataUrl(null);
    setGeneratedSvg(null);
    setGenerationError(null);
    setStatus('idle');
  }, []);

  // Design reset handler resets styling defaults without touching form input
  const handleResetStyle = useCallback(() => {
    setStyleConfig(DEFAULT_QR_STYLE);
  }, []);

  const handleApplyPreset = useCallback((presetId: string) => {
    const preset = QR_COLOR_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    setStyleConfig((prev) => ({
      ...prev,
      foregroundColor: preset.foregroundColor,
      backgroundColor: preset.backgroundColor,
      selectedPreset: preset.id,
    }));
  }, []);

  const handleUpdateStyle = useCallback(
    (updater: (prev: QrStyleConfig) => QrStyleConfig) => {
      setStyleConfig(updater);
    },
    []
  );

  const handleTypeChange = useCallback((newType: QrCodeType) => {
    setType(newType);
    setGenerationError(null);
  }, []);

  useEffect(() => {
    // If invalid or empty, discard ongoing requests
    if (!isInputValid || !sanitizedPayload) {
      requestIdRef.current += 1;
      return;
    }

    const thisRequestId = ++requestIdRef.current;

    const timer = setTimeout(async () => {
      setStatus('generating');
      try {
        const [dataUrl, svgString] = await Promise.all([
          generateQrDataUrl(sanitizedPayload, styleConfig),
          generateQrSvgString(sanitizedPayload, styleConfig),
        ]);

        // Discard if a newer request has started
        if (requestIdRef.current !== thisRequestId) {
          return;
        }

        setGeneratedDataUrl(dataUrl);
        setGeneratedSvg(svgString);
        setGenerationError(null);
        setStatus('success');
      } catch {
        if (requestIdRef.current !== thisRequestId) {
          return;
        }
        setGeneratedDataUrl(null);
        setGeneratedSvg(null);
        setGenerationError(
          'Something went wrong while generating your QR code. Please try again.'
        );
        setStatus('error');
      }
    }, debounceMs);

    return () => {
      clearTimeout(timer);
    };
  }, [isInputValid, sanitizedPayload, debounceMs, styleConfig]);

  // Active QR data URL is only exposed when the active type's input remains valid
  const activeQrDataUrl = isInputValid ? generatedDataUrl : null;
  const activeQrSvg = isInputValid ? generatedSvg : null;
  const activeStatus = isInputValid ? status : 'idle';

  return {
    type,
    setType: handleTypeChange,
    urlValue,
    setUrlValue,
    textValue,
    setTextValue,
    wifiData,
    setWifiData,
    vcardData,
    setVcardData,
    whatsappData,
    setWhatsappData,
    reviewsData,
    setReviewsData,
    callData,
    setCallData,
    mapsData,
    setMapsData,
    labelNote,
    setLabelNote,
    styleConfig,
    setStyleConfig: handleUpdateStyle,
    applyColorPreset: handleApplyPreset,
    resetStyle: handleResetStyle,
    qrDataUrl: activeQrDataUrl,
    qrSvg: activeQrSvg,
    rawPayload: isInputValid ? sanitizedPayload : '',
    status: activeStatus,
    isLoading: activeStatus === 'generating',
    validationError,
    generationError,
    activeError: validationError || generationError,
    clear: handleClear,
  };
}
