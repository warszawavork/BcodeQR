import type { WifiFormData } from '@/types';
import { getUtf8ByteLength, type QrValidationResult } from './validation';

/**
 * Escapes special characters for Wi-Fi QR code strings according to the ZXing specification.
 * Characters: \ ; , " : must be escaped with a backslash.
 */
export function escapeWifiField(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/"/g, '\\"')
    .replace(/:/g, '\\:');
}

/**
 * Builds a standardized Wi-Fi network configuration payload:
 * WIFI:T:WPA;S:NETWORK;P:PASSWORD;H:true;;
 */
export function buildWifiPayload(data: WifiFormData): string {
  const parts: string[] = ['WIFI:'];

  parts.push(`T:${data.encryption};`);
  parts.push(`S:${escapeWifiField(data.ssid)};`);

  if (data.encryption !== 'nopass' && data.password) {
    parts.push(`P:${escapeWifiField(data.password)};`);
  }

  if (data.hidden) {
    parts.push('H:true;');
  }

  parts.push(';');
  return parts.join('');
}

/**
 * Validates Wi-Fi form inputs according to network security standards.
 */
export function validateWifiInput(data: WifiFormData): QrValidationResult {
  const ssid = data.ssid.trim();

  if (!ssid) {
    return {
      isValid: false,
      error: 'Please enter a Wi-Fi network name (SSID).',
      sanitized: '',
    };
  }

  const ssidByteLength = getUtf8ByteLength(ssid);
  if (ssidByteLength > 32) {
    return {
      isValid: false,
      error: 'Wi-Fi network name (SSID) cannot exceed 32 bytes.',
      sanitized: '',
    };
  }

  if (data.encryption === 'WPA') {
    const password = data.password ?? '';
    if (!password) {
      return {
        isValid: false,
        error: 'Please enter a password for WPA/WPA2 security.',
        sanitized: '',
      };
    }

    const isHex64 = /^[0-9a-fA-F]{64}$/.test(password);
    const pwdBytes = getUtf8ByteLength(password);
    const isValidPassphrase = pwdBytes >= 8 && pwdBytes <= 63;

    if (!isValidPassphrase && !isHex64) {
      return {
        isValid: false,
        error:
          'WPA/WPA2 password must be between 8 and 63 characters (or 64 hexadecimal characters).',
        sanitized: '',
      };
    }
  } else if (data.encryption === 'WEP') {
    const password = data.password ?? '';
    if (!password) {
      return {
        isValid: false,
        error: 'Please enter a password for WEP security.',
        sanitized: '',
      };
    }

    const isAscii5or13 =
      (password.length === 5 || password.length === 13) &&
      /^[\x20-\x7E]+$/.test(password);
    const isHex10or26 =
      /^[0-9a-fA-F]{10}$/.test(password) || /^[0-9a-fA-F]{26}$/.test(password);

    if (!isAscii5or13 && !isHex10or26) {
      return {
        isValid: false,
        error:
          'WEP password must be 5 or 13 ASCII characters (or 10/26 hexadecimal characters).',
        sanitized: '',
      };
    }
  }

  const payload = buildWifiPayload({
    ...data,
    ssid,
  });

  return {
    isValid: true,
    error: null,
    sanitized: payload,
  };
}
