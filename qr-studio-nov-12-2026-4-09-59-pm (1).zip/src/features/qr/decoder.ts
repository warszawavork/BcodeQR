import jsQR from 'jsqr';

/**
 * Decodes QR code content from RGBA image data.
 * Useful for automated verification and test pipelines.
 */
export function decodeQrImageData(
  data: Uint8ClampedArray,
  width: number,
  height: number
): string | null {
  const result = jsQR(data, width, height);
  return result ? result.data : null;
}
