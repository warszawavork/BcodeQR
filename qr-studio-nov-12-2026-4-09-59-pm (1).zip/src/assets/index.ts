/**
 * Static assets registry for QR Studio.
 * Brand marks, SVG templates, and static presets live in src/assets/.
 */
export const BRAND_MARK = {
  title: 'QR Studio',
  tagline: 'Client-Side QR Code Engineering & Customization Suite',
} as const;
