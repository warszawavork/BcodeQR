import { useCallback, useState } from 'react';
import { ArrowLeft, CheckCircle2, Sparkles } from 'lucide-react';
import {
  AppHeader,
  AppShell,
  ConfigurationCard,
  FeatureHighlights,
  QRPreviewCard,
  QrCustomizationPanel,
} from '@/components';
import { SaveToHistoryModal } from '@/components/history/SaveToHistoryModal';
import {
  isSensitiveQrType,
  useQrGenerator,
  useQrHistory,
} from '@/features/qr';
import { SIDEBAR_NAV_ITEMS, type SidebarNavId } from '@/lib';
import type {
  QrCodeCategory,
  QrExportFormat,
  QrHistoryFormData,
  QrHistoryItem,
} from '@/types';
import { HistoryPage } from './HistoryPage';

const BREADCRUMB_LABELS: Record<SidebarNavId, string> = {
  create: 'Create',
  saved: 'My QR Codes',
  templates: 'Templates',
  settings: 'Settings',
};

export function HomePage() {
  const [activeNav, setActiveNav] = useState<SidebarNavId>('create');
  const [selectedFormat, setSelectedFormat] = useState<QrExportFormat>('png');
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [editorNotice, setEditorNotice] = useState<string | null>(null);

  const { saveItem, totalCount } = useQrHistory();

  const {
    type,
    setType,
    urlValue,
    setUrlValue,
    textValue,
    setTextValue,
    wifiData,
    setWifiData,
    vcardData,
    setVcardData,
    whatsappData,
    setWhatsappData,
    reviewsData,
    setReviewsData,
    callData,
    setCallData,
    mapsData,
    setMapsData,
    labelNote,
    setLabelNote,
    styleConfig,
    setStyleConfig,
    applyColorPreset,
    resetStyle,
    qrDataUrl,
    rawPayload,
    isLoading,
    validationError,
    activeError,
    clear,
  } = useQrGenerator({
    initialType: 'url',
    debounceMs: 280,
  });

  const activeNavMeta = SIDEBAR_NAV_ITEMS.find((item) => item.id === activeNav);

  const handleOpenInEditor = useCallback(
    (item: QrHistoryItem) => {
      setType(item.type);

      switch (item.formData.type) {
        case 'url':
          setUrlValue(item.formData.url || '');
          setLabelNote(item.formData.labelNote || '');
          break;
        case 'text':
          setTextValue(item.formData.text || '');
          setLabelNote(item.formData.labelNote || '');
          break;
        case 'wifi':
          setWifiData({
            ssid: item.formData.ssid || '',
            encryption: item.formData.encryption || 'WPA',
            password: item.formData.password || '',
            hidden: Boolean(item.formData.hidden),
          });
          break;
        case 'vcard':
          setVcardData({
            firstName: item.formData.firstName || '',
            lastName: item.formData.lastName || '',
            organization: item.formData.organization || '',
            jobTitle: item.formData.jobTitle || '',
            phone: item.formData.phone || '',
            email: item.formData.email || '',
            website: item.formData.website || '',
          });
          break;
        case 'whatsapp':
          setWhatsappData({
            phone: item.formData.phone || '',
            message: item.formData.message || '',
          });
          break;
        case 'reviews':
          setReviewsData({
            businessName: item.formData.businessName || '',
            reviewUrl: item.formData.reviewUrl || '',
          });
          break;
        case 'call':
          setCallData({
            phone: item.formData.phone || '',
            businessName: item.formData.businessName || '',
          });
          break;
        case 'maps':
          setMapsData({
            locationName: item.formData.locationName || '',
            mapsUrl: item.formData.mapsUrl || '',
          });
          break;
      }

      if (item.styleConfig) {
        setStyleConfig(() => item.styleConfig);
      }

      setActiveNav('create');
      setEditorNotice(`Loaded "${item.title}" into the QR editor.`);
      setTimeout(() => setEditorNotice(null), 4000);
    },
    [
      setType,
      setUrlValue,
      setTextValue,
      setWifiData,
      setVcardData,
      setWhatsappData,
      setReviewsData,
      setCallData,
      setMapsData,
      setLabelNote,
      setStyleConfig,
    ]
  );

  const handleConfirmSave = async (customTitle: string) => {
    if (!rawPayload) return;

    const category: QrCodeCategory = [
      'url',
      'text',
      'wifi',
      'vcard',
    ].includes(type)
      ? 'standard'
      : 'business';

    let formData: QrHistoryFormData;
    switch (type) {
      case 'url':
        formData = { type: 'url', url: urlValue, labelNote };
        break;
      case 'text':
        formData = { type: 'text', text: textValue, labelNote };
        break;
      case 'wifi':
        formData = { type: 'wifi', ...wifiData };
        break;
      case 'vcard':
        formData = { type: 'vcard', ...vcardData };
        break;
      case 'whatsapp':
        formData = { type: 'whatsapp', ...whatsappData };
        break;
      case 'reviews':
        formData = { type: 'reviews', ...reviewsData };
        break;
      case 'call':
        formData = { type: 'call', ...callData };
        break;
      case 'maps':
        formData = { type: 'maps', ...mapsData };
        break;
    }

    const newItem: QrHistoryItem = {
      id:
        typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `qr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      title: customTitle,
      type,
      category,
      payload: rawPayload,
      formData,
      styleConfig,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      containsSensitiveData: isSensitiveQrType(type),
      logoData: styleConfig.logo.enabled ? styleConfig.logo.dataUrl : null,
    };

    await saveItem(newItem);
    setEditorNotice(`Saved "${customTitle}" to your local QR history.`);
    setTimeout(() => setEditorNotice(null), 4000);
  };

  return (
    <AppShell activeNav={activeNav} onSelectNav={setActiveNav}>
      <AppHeader breadcrumbSection={BREADCRUMB_LABELS[activeNav]} />

      {/* Temporary Toast / Notice Banner */}
      {editorNotice && (
        <div
          role="status"
          className="mb-6 flex items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-950 animate-in fade-in"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>{editorNotice}</span>
          </div>
          <button
            type="button"
            onClick={() => setEditorNotice(null)}
            className="text-emerald-700 hover:text-emerald-900 font-semibold text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Active Navigation Views */}
      {activeNav === 'saved' ? (
        <HistoryPage
          onOpenInEditor={handleOpenInEditor}
          onNavigateCreate={() => setActiveNav('create')}
        />
      ) : activeNav !== 'create' && activeNavMeta ? (
        /* Roadmap Notice for Templates and Settings */
        <div
          role="status"
          className="mb-6 flex flex-col justify-between gap-3 rounded-xl border border-indigo-200/80 bg-indigo-50/60 px-4 py-3 text-xs text-indigo-950 sm:flex-row sm:items-center"
        >
          <div className="flex items-center gap-2.5">
            <Sparkles
              className="h-4 w-4 shrink-0 text-indigo-600"
              aria-hidden="true"
            />
            <span>
              <strong>{activeNavMeta.label}</strong> is part of the upcoming
              roadmap. You can continue configuring your QR code below.
            </span>
          </div>
          <button
            type="button"
            onClick={() => setActiveNav('create')}
            className="inline-flex items-center gap-1.5 self-start rounded-lg bg-white px-2.5 py-1 text-xs font-semibold text-indigo-700 shadow-2xs ring-1 ring-indigo-200 transition-colors hover:bg-indigo-50 sm:self-auto"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
            <span className="whitespace-nowrap">Back to Create</span>
          </button>
        </div>
      ) : (
        /* Standard QR Generator Workspace */
        <>
          <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-12 lg:gap-8">
            {/* Left Column: QR Configuration & Customization */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              <ConfigurationCard
                selectedType={type}
                onSelectType={setType}
                urlValue={urlValue}
                onUrlChange={setUrlValue}
                textValue={textValue}
                onTextChange={setTextValue}
                wifiData={wifiData}
                onWifiChange={setWifiData}
                vcardData={vcardData}
                onVCardChange={setVcardData}
                whatsappData={whatsappData}
                onWhatsAppChange={setWhatsappData}
                reviewsData={reviewsData}
                onReviewsChange={setReviewsData}
                callData={callData}
                onCallChange={setCallData}
                mapsData={mapsData}
                onMapsChange={setMapsData}
                labelNote={labelNote}
                onLabelNoteChange={setLabelNote}
                validationError={validationError}
                onClear={clear}
              />

              <section
                aria-label="Design Customization"
                className="rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs sm:p-8"
              >
                <QrCustomizationPanel
                  styleConfig={styleConfig}
                  onUpdateStyle={setStyleConfig}
                  onApplyPreset={applyColorPreset}
                  onResetStyle={resetStyle}
                />
              </section>
            </div>

            {/* Right Column: Sticky QR Preview */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="lg:sticky lg:top-6">
                <QRPreviewCard
                  selectedFormat={selectedFormat}
                  onSelectFormat={setSelectedFormat}
                  selectedType={type}
                  qrDataUrl={qrDataUrl}
                  isLoading={isLoading}
                  activeError={activeError}
                  content={rawPayload || type}
                  styleConfig={styleConfig}
                  onSaveToHistory={() => setIsSaveModalOpen(true)}
                />
              </div>
            </div>
          </div>

          <FeatureHighlights />
        </>
      )}

      {/* Save to History Confirmation Dialog */}
      <SaveToHistoryModal
        isOpen={isSaveModalOpen}
        qrType={type}
        initialTitle={labelNote}
        currentCount={totalCount}
        onClose={() => setIsSaveModalOpen(false)}
        onConfirmSave={handleConfirmSave}
      />
    </AppShell>
  );
}
