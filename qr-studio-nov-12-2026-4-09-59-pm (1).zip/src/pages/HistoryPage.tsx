import { useMemo, useState } from 'react';
import {
  Briefcase,
  Filter,
  Layers,
  Plus,
  QrCode,
  RotateCcw,
  Search,
  Trash2,
} from 'lucide-react';
import type { QrCodeCategory, QrCodeType, QrHistoryItem } from '@/types';
import {
  filterAndSortHistory,
  type HistorySortOption,
  useQrHistory,
} from '@/features/qr';
import { ClearAllModal } from '@/components/history/ClearAllModal';
import { DeleteConfirmModal } from '@/components/history/DeleteConfirmModal';
import { HistoryCard } from '@/components/history/HistoryCard';
import { RenameModal } from '@/components/history/RenameModal';

interface HistoryPageProps {
  onOpenInEditor: (item: QrHistoryItem) => void;
  onNavigateCreate: () => void;
}

export function HistoryPage({
  onOpenInEditor,
  onNavigateCreate,
}: HistoryPageProps) {
  const {
    items,
    isLoading,
    totalCount,
    standardCount,
    businessCount,
    deleteItem,
    updateItem,
    duplicateItem,
    clearAll,
  } = useQrHistory();

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | QrCodeCategory>('all');
  const [selectedType, setSelectedType] = useState<'all' | QrCodeType>('all');
  const [sortBy, setSortBy] = useState<HistorySortOption>('newest');

  // Modal states
  const [renamingItem, setRenamingItem] = useState<QrHistoryItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<QrHistoryItem | null>(null);
  const [isClearAllOpen, setIsClearAllOpen] = useState(false);

  // Filtered and sorted items
  const filteredItems = useMemo(() => {
    return filterAndSortHistory(items, {
      searchQuery,
      category: selectedCategory,
      type: selectedType,
      sortBy,
    });
  }, [items, searchQuery, selectedCategory, selectedType, sortBy]);

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedType('all');
    setSortBy('newest');
  };

  const handleConfirmRename = async (newTitle: string) => {
    if (!renamingItem) return;
    await updateItem({
      ...renamingItem,
      title: newTitle,
    });
    setRenamingItem(null);
  };

  const handleConfirmDelete = async () => {
    if (!deletingItem) return;
    await deleteItem(deletingItem.id);
    setDeletingItem(null);
  };

  const handleConfirmClearAll = async () => {
    await clearAll();
    setIsClearAllOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Clear All Action */}
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
            My QR Codes
          </h2>
          <p className="mt-1 text-xs text-slate-500 sm:text-sm">
            Manage, organize and reuse your saved QR codes.
          </p>
        </div>

        {totalCount > 0 && (
          <button
            type="button"
            onClick={() => setIsClearAllOpen(true)}
            className="inline-flex items-center gap-1.5 self-start rounded-xl border border-rose-200 bg-white px-3 py-2 text-xs font-semibold text-rose-600 shadow-2xs hover:bg-rose-50 transition sm:self-auto"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear All History</span>
          </button>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">Total QR Codes</p>
            <p className="mt-1 text-2xl font-bold tracking-tight text-slate-900 font-mono">
              {totalCount}
            </p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
            <QrCode className="h-5 w-5" />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">Standard QR</p>
            <p className="mt-1 text-2xl font-bold tracking-tight text-slate-900 font-mono">
              {standardCount}
            </p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600">
            <Layers className="h-5 w-5" />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500">Business & Social</p>
            <p className="mt-1 text-2xl font-bold tracking-tight text-slate-900 font-mono">
              {businessCount}
            </p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
            <Briefcase className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      {totalCount > 0 && (
        <div className="rounded-2xl border border-slate-200/90 bg-white p-4 shadow-xs space-y-3">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search your QR codes..."
                className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3.5 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-hidden transition"
              />
            </div>

            {/* Filter Controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Category */}
              <select
                value={selectedCategory}
                onChange={(e) =>
                  setSelectedCategory(e.target.value as 'all' | QrCodeCategory)
                }
                aria-label="Filter by Category"
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-indigo-600 outline-hidden transition cursor-pointer"
              >
                <option value="all">All Categories</option>
                <option value="standard">Standard QR</option>
                <option value="business">Business & Social</option>
              </select>

              {/* Type */}
              <select
                value={selectedType}
                onChange={(e) =>
                  setSelectedType(e.target.value as 'all' | QrCodeType)
                }
                aria-label="Filter by Type"
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-indigo-600 outline-hidden transition cursor-pointer"
              >
                <option value="all">All Types</option>
                <option value="url">URL</option>
                <option value="text">Text</option>
                <option value="wifi">Wi-Fi</option>
                <option value="vcard">vCard</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="reviews">Google Reviews</option>
                <option value="call">Call Us</option>
                <option value="maps">Google Maps</option>
              </select>

              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as HistorySortOption)}
                aria-label="Sort order"
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-indigo-600 outline-hidden transition cursor-pointer"
              >
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="recently-updated">Recently Updated</option>
                <option value="name-asc">Name A–Z</option>
              </select>

              {(searchQuery || selectedCategory !== 'all' || selectedType !== 'all') && (
                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-200 transition"
                  title="Reset filters"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      {isLoading ? (
        <div className="py-16 text-center">
          <p className="text-xs text-slate-500">Loading your saved QR codes...</p>
        </div>
      ) : totalCount === 0 ? (
        /* Empty State */
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white px-6 py-16 text-center shadow-xs">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 shadow-2xs">
            <QrCode className="h-8 w-8" />
          </div>
          <h3 className="mt-4 text-base font-semibold text-slate-900">
            No QR codes saved yet.
          </h3>
          <p className="mt-1.5 max-w-sm text-xs text-slate-500 leading-relaxed">
            Create your first QR code and save it here for quick access later.
          </p>
          <button
            type="button"
            onClick={onNavigateCreate}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 transition"
          >
            <Plus className="h-4 w-4" />
            <span>Create Your First QR Code</span>
          </button>
        </div>
      ) : filteredItems.length === 0 ? (
        /* No Matching Search Results */
        <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200/80 bg-white px-6 py-12 text-center shadow-xs">
          <Filter className="h-8 w-8 text-slate-400" />
          <h4 className="mt-3 text-sm font-semibold text-slate-900">
            No matching QR codes found
          </h4>
          <p className="mt-1 text-xs text-slate-500">
            Try adjusting your search query or clear the active category filters.
          </p>
          <button
            type="button"
            onClick={handleClearFilters}
            className="mt-4 inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset filters</span>
          </button>
        </div>
      ) : (
        /* Grid of History Cards */
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredItems.map((item) => (
            <HistoryCard
              key={item.id}
              item={item}
              onOpenInEditor={onOpenInEditor}
              onRename={setRenamingItem}
              onDuplicate={duplicateItem}
              onDelete={setDeletingItem}
            />
          ))}
        </div>
      )}

      {/* Modals */}
      <RenameModal
        isOpen={Boolean(renamingItem)}
        currentTitle={renamingItem?.title || ''}
        onClose={() => setRenamingItem(null)}
        onConfirmRename={handleConfirmRename}
      />

      <DeleteConfirmModal
        isOpen={Boolean(deletingItem)}
        itemTitle={deletingItem?.title || ''}
        onClose={() => setDeletingItem(null)}
        onConfirmDelete={handleConfirmDelete}
      />

      <ClearAllModal
        isOpen={isClearAllOpen}
        totalCount={totalCount}
        onClose={() => setIsClearAllOpen(false)}
        onConfirmClear={handleConfirmClearAll}
      />
    </div>
  );
}
