import { Layers, ShieldCheck, Zap } from 'lucide-react';

const HIGHLIGHTS = [
  {
    id: 'fast',
    title: 'Fast & Simple',
    description:
      'Create and customize structured QR codes in seconds with a clean, distraction-free workflow.',
    Icon: Zap,
  },
  {
    id: 'privacy',
    title: 'Privacy First',
    description:
      'All QR payloads are processed directly in your browser without sending data to external servers.',
    Icon: ShieldCheck,
  },
  {
    id: 'quality',
    title: 'High Quality Export',
    description:
      'Download crisp raster PNG files or scalable vector SVG graphics ready for digital and print media.',
    Icon: Layers,
  },
] as const;

export function FeatureHighlights() {
  return (
    <section
      aria-labelledby="why-qr-studio-heading"
      className="mt-12 border-t border-slate-200/80 pt-10"
    >
      <h2
        id="why-qr-studio-heading"
        className="text-sm font-semibold tracking-tight text-slate-900"
      >
        Why QR Studio?
      </h2>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        {HIGHLIGHTS.map(({ id, title, description, Icon }) => (
          <div
            key={id}
            className="rounded-xl border border-slate-200/80 bg-white/80 p-5"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
                <Icon className="h-4 w-4" aria-hidden="true" />
              </div>
              <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
            </div>
            <p className="mt-2.5 text-xs leading-relaxed text-slate-600">
              {description}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
