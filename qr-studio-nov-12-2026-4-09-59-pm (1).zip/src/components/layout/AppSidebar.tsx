import {
  FolderKanban,
  LayoutTemplate,
  QrCode,
  Settings,
  ShieldCheck,
  X,
} from 'lucide-react';
import { APP_CONFIG, SIDEBAR_NAV_ITEMS, type SidebarNavId } from '@/lib';
import { cn } from '@/utils';

interface AppSidebarProps {
  activeNav: SidebarNavId;
  onSelectNav: (nav: SidebarNavId) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ICONS: Record<SidebarNavId, typeof QrCode> = {
  create: QrCode,
  saved: FolderKanban,
  templates: LayoutTemplate,
  settings: Settings,
};

export function AppSidebar({
  activeNav,
  onSelectNav,
  isMobileOpen,
  onCloseMobile,
}: AppSidebarProps) {
  const handleItemClick = (id: SidebarNavId) => {
    onSelectNav(id);
    onCloseMobile();
  };

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-[#0B1120] text-slate-200 select-none">
      {/* Brand Header */}
      <div>
        <div className="flex items-center justify-between border-b border-slate-800/80 px-5 py-5 lg:px-6">
          <div className="flex items-center gap-3">
            <img
              src="/assets/brand-logo.png"
              alt="QR Studio Logo"
              className="h-9 w-9 shrink-0 object-contain drop-shadow-md rounded-lg"
            />
            <div className="min-w-0">
              <p className="text-base font-bold tracking-tight text-white whitespace-nowrap">
                {APP_CONFIG.name}
              </p>
              <p className="mt-0.5 font-mono text-[10px] font-medium tracking-widest text-slate-400 whitespace-nowrap">
                {APP_CONFIG.subtitle}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-800/70 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 md:hidden"
            aria-label="Close navigation menu"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* Navigation Menu */}
        <nav aria-label="Primary Sidebar Navigation" className="px-3 py-5 lg:px-4">
          <ul className="space-y-1">
            {SIDEBAR_NAV_ITEMS.map((item) => {
              const Icon = NAV_ICONS[item.id];
              const isActive = activeNav === item.id;

              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => handleItemClick(item.id)}
                    aria-current={isActive ? 'page' : undefined}
                    className={cn(
                      'group flex w-full items-center justify-between gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500',
                      isActive
                        ? 'bg-indigo-600/15 text-white ring-1 ring-indigo-500/30'
                        : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-100'
                    )}
                  >
                    <span className="flex items-center gap-3 min-w-0">
                      <Icon
                        className={cn(
                          'h-4 w-4 shrink-0 transition-colors duration-150',
                          isActive
                            ? 'text-indigo-400'
                            : 'text-slate-400 group-hover:text-slate-200'
                        )}
                        aria-hidden="true"
                      />
                      <span className="truncate whitespace-nowrap">{item.label}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>

      {/* Bottom Privacy Assurance */}
      <div className="border-t border-slate-800/80 p-4 lg:p-5">
        <div className="rounded-xl border border-slate-800/90 bg-slate-900/70 p-3.5">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-indigo-500/10 text-indigo-400">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-200">
                Local-First Privacy
              </p>
              <p className="mt-0.5 text-xs leading-relaxed text-slate-400">
                Your data stays on your device.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop & Tablet Fixed Sidebar */}
      <aside
        aria-label="Sidebar"
        className="hidden md:fixed md:inset-y-0 md:left-0 md:z-30 md:flex md:w-52 lg:w-64 md:flex-col md:border-r md:border-slate-800"
      >
        {sidebarContent}
      </aside>

      {/* Mobile Slide-Over Sidebar */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-50 flex md:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation menu"
        >
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 flex w-72 max-w-[85vw] flex-1 flex-col shadow-2xl">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
