import { useState, type ReactNode } from 'react';
import { Menu } from 'lucide-react';
import { APP_CONFIG, type SidebarNavId } from '@/lib';
import { AppSidebar } from './AppSidebar';

interface AppShellProps {
  children: ReactNode;
  activeNav?: SidebarNavId;
  onSelectNav?: (nav: SidebarNavId) => void;
}

export function AppShell({
  children,
  activeNav = 'create',
  onSelectNav,
}: AppShellProps) {
  const [internalNav, setInternalNav] = useState<SidebarNavId>('create');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const currentNav = onSelectNav ? activeNav : internalNav;
  const handleSelectNav = onSelectNav ?? setInternalNav;

  return (
    <div className="min-h-screen bg-[#F7F8FA] text-slate-900">
      <AppSidebar
        activeNav={currentNav}
        onSelectNav={handleSelectNav}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Mobile Top Bar (< 768px) */}
      <div className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-slate-800 bg-[#0B1120] px-4 text-white md:hidden">
        <div className="flex items-center gap-2.5">
          <img
            src="/assets/brand-logo.png"
            alt="QR Studio Logo"
            className="h-7 w-7 shrink-0 object-contain drop-shadow-sm rounded-md"
          />
          <span className="text-sm font-bold tracking-tight whitespace-nowrap">
            {APP_CONFIG.name}
          </span>
        </div>

        <button
          type="button"
          onClick={() => setIsMobileMenuOpen(true)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-300 transition-colors hover:bg-slate-800 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500"
          aria-label="Open navigation menu"
          aria-expanded={isMobileMenuOpen}
        >
          <Menu className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      {/* Main Content Area offset by Sidebar on Desktop/Tablet */}
      <div className="md:pl-52 lg:pl-64 flex min-h-screen flex-col">
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 sm:py-8 lg:px-10 lg:py-10">
          {children}
        </main>

        {/* Minimalist Footer */}
        <footer className="border-t border-slate-200/80 bg-white/60">
          <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-slate-500 sm:flex-row sm:px-6 lg:px-10">
            <p className="font-medium text-slate-600">QR Studio © 2026</p>
            <p className="text-slate-500">Made with care.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
