import { PrivacyBadge } from '@/components/ui/PrivacyBadge';

interface AppHeaderProps {
  breadcrumbSection?: string;
  title?: string;
  description?: string;
}

export function AppHeader({
  breadcrumbSection = 'Create',
  title = 'Create your QR code',
  description = 'Create, customize and download beautiful QR codes in seconds.',
}: AppHeaderProps) {
  return (
    <header className="mb-8 border-b border-slate-200/80 pb-6">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="mb-2">
        <ol className="flex items-center gap-2 text-xs font-medium text-slate-500">
          <li>QR Studio</li>
          <li aria-hidden="true" className="text-slate-300">
            /
          </li>
          <li className="font-semibold text-indigo-600" aria-current="page">
            {breadcrumbSection}
          </li>
        </ol>
      </nav>

      {/* Title, Description & Right-aligned Privacy Label */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="space-y-1.5">
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            {title}
          </h1>
          <p className="text-sm text-slate-600 sm:text-base">{description}</p>
        </div>

        <div className="shrink-0 sm:pt-1">
          <PrivacyBadge />
        </div>
      </div>
    </header>
  );
}
