import { ShieldCheck } from 'lucide-react';
import { cn } from '@/utils';

interface PrivacyBadgeProps {
  className?: string;
}

export function PrivacyBadge({ className }: PrivacyBadgeProps) {
  return (
    <div
      className={cn(
        'inline-flex items-center gap-2 rounded-lg border border-slate-200/90 bg-white px-3 py-1.5 text-[11px] font-semibold tracking-wider text-slate-700 shadow-2xs select-none',
        className
      )}
      aria-label="Privacy guarantee: Private by design"
    >
      <ShieldCheck
        className="h-3.5 w-3.5 shrink-0 text-indigo-600"
        aria-hidden="true"
      />
      <span className="whitespace-nowrap">PRIVATE BY DESIGN</span>
    </div>
  );
}
