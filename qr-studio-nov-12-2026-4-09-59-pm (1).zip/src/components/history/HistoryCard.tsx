import { useEffect, useRef, useState } from 'react';
import {
  Calendar,
  Clock,
  Copy,
  Download,
  Edit,
  ExternalLink,
  FileCode2,
  Image,
  Lock,
  MoreVertical,
  QrCode,
  ShieldAlert,
  Trash2,
} from 'lucide-react';
import type { QrExportFormat, QrHistoryItem } from '@/types';
import { exportAndDownloadQr, generateQrDataUrl } from '@/features/qr';

interface HistoryCardProps {
  item: QrHistoryItem;
  onOpenInEditor: (item: QrHistoryItem) => void;
  onRename: (item: QrHistoryItem) => void;
  onDuplicate: (item: QrHistoryItem) => void;
  onDelete: (item: QrHistoryItem) => void;
}

export function HistoryCard({
  item,
  onOpenInEditor,
  onRename,
  onDuplicate,
  onDelete,
}: HistoryCardProps) {
  const [thumbUrl, setThumbUrl] = useState<string | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isExporting, setIsExporting] = useState<QrExportFormat | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Generate lightweight thumbnail on-demand without storing bulky images in IDB
  useEffect(() => {
    let isCancelled = false;

    async function loadThumb() {
      try {
        const url = await generateQrDataUrl(item.payload, {
          ...item.styleConfig,
          size: 140,
          margin: 4,
        });
        if (!isCancelled) {
          setThumbUrl(url);
        }
      } catch {
        if (!isCancelled) {
          setThumbUrl(null);
        }
      }
    }

    loadThumb();

    return () => {
      isCancelled = true;
    };
  }, [item.payload, item.styleConfig]);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsMenuOpen(false);
      }
    }
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  const handleDownload = async (format: QrExportFormat) => {
    setIsExporting(format);
    setIsMenuOpen(false);
    try {
      await exportAndDownloadQr({
        payload: item.payload,
        type: item.type,
        format,
        style: item.styleConfig,
      });
    } catch {
      // Export handled gracefully
    } finally {
      setIsExporting(null);
    }
  };

  const formattedCreated = new Date(item.createdAt).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const formattedUpdated = new Date(item.updatedAt).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
  });

  return (
    <article
      aria-label={`Saved QR code: ${item.title}`}
      className="group relative flex flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs transition-all duration-200 hover:border-slate-300 hover:shadow-md"
    >
      <div>
        {/* Top Badges & Actions Menu */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1 rounded-md bg-indigo-50 px-2 py-0.5 text-[11px] font-semibold text-indigo-700 uppercase tracking-wider">
              {item.type}
            </span>
            <span className="inline-flex rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-600 capitalize">
              {item.category}
            </span>
            {item.containsSensitiveData && (
              <span
                title="Contains private information. Sensitive credentials are hidden from preview."
                className="inline-flex items-center gap-1 rounded-md bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-800 border border-amber-200/80"
              >
                <Lock className="h-2.5 w-2.5 shrink-0" />
                <span>Private</span>
              </span>
            )}
          </div>

          {/* Action Menu Dropdown */}
          <div className="relative" ref={menuRef}>
            <button
              type="button"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
              aria-label="Actions menu"
              aria-expanded={isMenuOpen}
            >
              <MoreVertical className="h-4 w-4" />
            </button>

            {isMenuOpen && (
              <div
                role="menu"
                className="absolute right-0 z-20 mt-1 w-44 rounded-xl border border-slate-200 bg-white py-1.5 shadow-lg ring-1 ring-black/5 animate-in fade-in zoom-in-95"
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setIsMenuOpen(false);
                    onOpenInEditor(item);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 transition"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  <span>Open in Editor</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => handleDownload('png')}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 transition"
                >
                  <Image className="h-3.5 w-3.5 text-slate-400" />
                  <span>Download PNG</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => handleDownload('svg')}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 transition"
                >
                  <FileCode2 className="h-3.5 w-3.5 text-slate-400" />
                  <span>Download SVG</span>
                </button>
                <div className="my-1 border-t border-slate-100" />
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setIsMenuOpen(false);
                    onRename(item);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 transition"
                >
                  <Edit className="h-3.5 w-3.5 text-slate-400" />
                  <span>Rename</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setIsMenuOpen(false);
                    onDuplicate(item);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 transition"
                >
                  <Copy className="h-3.5 w-3.5 text-slate-400" />
                  <span>Duplicate</span>
                </button>
                <div className="my-1 border-t border-slate-100" />
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => {
                    setIsMenuOpen(false);
                    onDelete(item);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 transition"
                >
                  <Trash2 className="h-3.5 w-3.5 text-rose-500" />
                  <span>Delete</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Thumbnail Preview Area */}
        <div className="mt-4 flex flex-col items-center justify-center rounded-xl border border-slate-100 bg-[#F7F8FA] p-4">
          <div className="h-28 w-28 overflow-hidden rounded-xl border border-slate-200/80 bg-white p-2 shadow-2xs flex items-center justify-center">
            {thumbUrl ? (
              <img
                src={thumbUrl}
                alt={`QR code for ${item.title}`}
                className="h-full w-full object-contain"
                loading="lazy"
              />
            ) : (
              <QrCode className="h-10 w-10 text-slate-300" />
            )}
          </div>
        </div>

        {/* Title & Metadata */}
        <div className="mt-4">
          <h4
            title={item.title}
            className="truncate text-sm font-semibold text-slate-900"
          >
            {item.title}
          </h4>

          {item.containsSensitiveData ? (
            <p className="mt-1 flex items-center gap-1 text-[11px] text-amber-700">
              <ShieldAlert className="h-3 w-3 shrink-0" />
              <span>Contains private information</span>
            </p>
          ) : (
            <p className="mt-1 truncate font-mono text-[11px] text-slate-500">
              {item.payload}
            </p>
          )}

          {/* Technical Badges */}
          <div className="mt-2.5 flex flex-wrap items-center gap-1.5 text-[10px] font-mono text-slate-500">
            <span className="rounded bg-slate-100 px-1.5 py-0.5">
              {item.styleConfig.size}×{item.styleConfig.size}px
            </span>
            <span className="rounded bg-slate-100 px-1.5 py-0.5">
              EC: {item.styleConfig.logo.enabled ? 'H' : item.styleConfig.errorCorrectionLevel}
            </span>
            {item.styleConfig.logo.enabled && (
              <span className="rounded bg-indigo-50 px-1.5 py-0.5 font-semibold text-indigo-700">
                Logo
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Footer Dates & Quick Open Button */}
      <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1" title={`Created: ${formattedCreated}`}>
            <Calendar className="h-3 w-3 text-slate-400" />
            <span>{formattedCreated}</span>
          </span>
          {item.updatedAt > item.createdAt && (
            <span className="flex items-center gap-1" title={`Updated: ${formattedUpdated}`}>
              <Clock className="h-3 w-3 text-slate-400" />
              <span>Updated</span>
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => onOpenInEditor(item)}
          className="inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition"
        >
          <span>Open</span>
          <ExternalLink className="h-3 w-3" />
        </button>
      </div>

      {/* Background Exporting Indicator */}
      {isExporting && (
        <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-white/80 backdrop-blur-2xs">
          <div className="flex items-center gap-2 rounded-xl bg-slate-900 px-3 py-1.5 text-xs text-white shadow-md">
            <Download className="h-3.5 w-3.5 animate-bounce" />
            <span>Downloading {isExporting.toUpperCase()}...</span>
          </div>
        </div>
      )}
    </article>
  );
}
