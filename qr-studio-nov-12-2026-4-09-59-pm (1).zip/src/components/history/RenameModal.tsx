import { useState } from 'react';
import { Edit3, X } from 'lucide-react';
import { validateHistoryTitle } from '@/features/qr/history/utils';

interface RenameModalProps {
  isOpen: boolean;
  currentTitle: string;
  onClose: () => void;
  onConfirmRename: (newTitle: string) => Promise<void>;
}

export function RenameModal({
  isOpen,
  currentTitle,
  onClose,
  onConfirmRename,
}: RenameModalProps) {
  const [title, setTitle] = useState(currentTitle);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateHistoryTitle(title);
    if (!validation.isValid) {
      setError(validation.error || 'Invalid title');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmRename(validation.sanitized);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to rename record'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="rename-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-150 animate-in fade-in"
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
              <Edit3 className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h3
                id="rename-modal-title"
                className="text-base font-semibold text-slate-900"
              >
                Rename QR code
              </h3>
              <p className="text-xs text-slate-500">
                Update the descriptive label for this code.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label
              htmlFor="rename-input"
              className="block text-xs font-semibold text-slate-700"
            >
              Title (max 60 characters)
            </label>
            <input
              id="rename-input"
              type="text"
              maxLength={60}
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError(null);
              }}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs text-slate-900 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-hidden transition"
              required
              autoFocus
            />
            <div className="mt-1 text-right text-[11px] text-slate-400">
              {title.length}/60
            </div>
          </div>

          {error && (
            <p className="text-xs font-medium text-rose-600">{error}</p>
          )}

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 disabled:bg-slate-300 transition"
            >
              {isSubmitting ? 'Saving...' : 'Save Title'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
