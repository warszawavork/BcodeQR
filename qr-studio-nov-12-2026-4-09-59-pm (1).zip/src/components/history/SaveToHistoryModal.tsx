import { useState } from 'react';
import {
  AlertTriangle,
  BookmarkPlus,
  HardDrive,
  Info,
  Loader2,
  ShieldAlert,
  X,
} from 'lucide-react';
import type { QrCodeType } from '@/types';
import { isSensitiveQrType, MAX_HISTORY_ITEMS } from '@/features/qr';
import { validateHistoryTitle } from '@/features/qr/history/utils';

interface SaveToHistoryModalProps {
  isOpen: boolean;
  qrType: QrCodeType;
  initialTitle?: string;
  currentCount: number;
  onClose: () => void;
  onConfirmSave: (title: string) => Promise<void>;
}

export function SaveToHistoryModal({
  isOpen,
  qrType,
  initialTitle = '',
  currentCount,
  onClose,
  onConfirmSave,
}: SaveToHistoryModalProps) {
  const isFull = currentCount >= MAX_HISTORY_ITEMS;
  const isSensitive = isSensitiveQrType(qrType);

  const [title, setTitle] = useState(
    initialTitle || `${qrType.toUpperCase()} QR Code`
  );
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isFull) return;

    const validation = validateHistoryTitle(title);
    if (!validation.isValid) {
      setError(validation.error || 'Invalid title');
      return;
    }

    setIsSaving(true);
    setError(null);
    try {
      await onConfirmSave(validation.sanitized);
      onClose();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to save QR code. Please try again.'
      );
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="save-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-150 animate-in fade-in"
    >
      <div
        className="w-full max-w-md rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
              <BookmarkPlus className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h3
                id="save-modal-title"
                className="text-base font-semibold text-slate-900"
              >
                Save QR code to your history?
              </h3>
              <p className="text-xs text-slate-500">
                This QR code will be saved locally in your browser on this device.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isSaving}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-5 space-y-4">
          {/* Title Input */}
          <div>
            <label
              htmlFor="history-entry-title"
              className="block text-xs font-semibold text-slate-700"
            >
              Entry Title
            </label>
            <input
              id="history-entry-title"
              type="text"
              maxLength={60}
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError(null);
              }}
              placeholder="e.g. My Website QR"
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-400 focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-hidden transition"
              required
            />
            <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
              <span>Short identifiable name</span>
              <span>{title.length}/60</span>
            </div>
          </div>

          {/* Sensitive Type Warning */}
          {isSensitive && (
            <div
              role="alert"
              className="rounded-xl border border-amber-200 bg-amber-50/80 p-3 text-xs text-amber-900 flex items-start gap-2.5"
            >
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
              <div>
                <p className="font-semibold text-amber-950">
                  This QR code may contain sensitive information.
                </p>
                <p className="mt-0.5 text-[11px] text-amber-800">
                  Codes of type <strong>{qrType.toUpperCase()}</strong> often store private credentials, phone numbers, or passwords.
                </p>
              </div>
            </div>
          )}

          {/* Important Privacy Notice */}
          <div className="rounded-xl border border-slate-200/80 bg-slate-50 p-3 text-xs text-slate-600 space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-slate-800 text-[11px]">
              <ShieldAlert className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
              <span>Important privacy notice</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Saved QR codes may contain private information, including Wi-Fi passwords or personal contact details. <strong>Only save codes on devices you trust.</strong>
            </p>
            <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-200/60 flex items-center gap-1">
              <HardDrive className="h-3 w-3 shrink-0 text-slate-400" />
              <span>IndexedDB is local browser storage, not encrypted storage. Anyone with access to this browser profile may inspect saved codes.</span>
            </p>
          </div>

          {/* Storage Capacity Status */}
          <div className="flex items-center justify-between rounded-lg bg-slate-100/80 px-3 py-2 text-xs text-slate-600">
            <span className="flex items-center gap-1.5">
              <Info className="h-3.5 w-3.5 text-slate-400" />
              <span>Storage capacity:</span>
            </span>
            <span
              className={`font-mono text-[11px] font-semibold ${
                isFull ? 'text-rose-600' : 'text-slate-700'
              }`}
            >
              {currentCount} / {MAX_HISTORY_ITEMS} saved
            </span>
          </div>

          {isFull && (
            <p className="text-xs font-semibold text-rose-600 text-center">
              Your history is full. Delete an existing QR code before saving another one.
            </p>
          )}

          {error && (
            <p className="text-xs font-medium text-rose-600 text-center">
              {error}
            </p>
          )}

          {/* Buttons */}
          <div className="mt-5 flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving || isFull}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save to History</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
