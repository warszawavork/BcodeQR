import { AlertOctagon, X } from 'lucide-react';

interface ClearAllModalProps {
  isOpen: boolean;
  totalCount: number;
  onClose: () => void;
  onConfirmClear: () => Promise<void>;
}

export function ClearAllModal({
  isOpen,
  totalCount,
  onClose,
  onConfirmClear,
}: ClearAllModalProps) {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="clear-all-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-150 animate-in fade-in"
    >
      <div
        className="w-full max-w-sm rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
              <AlertOctagon className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h3
                id="clear-all-modal-title"
                className="text-base font-semibold text-slate-900"
              >
                Delete all saved QR codes?
              </h3>
              <p className="text-xs text-slate-500">
                This will permanently remove all locally saved QR entries from this browser.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
            aria-label="Close dialog"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-4 text-xs text-slate-600 leading-relaxed">
          You have <strong>{totalCount} saved QR {totalCount === 1 ? 'code' : 'codes'}</strong>. Clearing your history will erase them completely from IndexedDB. This action cannot be reversed.
        </p>

        <div className="mt-6 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirmClear}
            className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-rose-700 transition"
          >
            Delete All
          </button>
        </div>
      </div>
    </div>
  );
}
