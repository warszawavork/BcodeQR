import { useMemo, useState } from 'react';
import {
  Briefcase,
  Contact,
  FileText,
  Globe,
  Layers,
  MapPin,
  MessageCircle,
  PhoneCall,
  Star,
  Wifi,
} from 'lucide-react';
import { QR_CATEGORIES, SUPPORTED_QR_TYPES } from '@/lib';
import type { QrCodeCategory, QrCodeType } from '@/types';
import { cn } from '@/utils';

interface ContentTypeSelectorProps {
  selectedType: QrCodeType;
  onSelectType: (type: QrCodeType) => void;
}

const TYPE_ICONS: Record<QrCodeType, typeof Globe> = {
  url: Globe,
  text: FileText,
  wifi: Wifi,
  vcard: Contact,
  whatsapp: MessageCircle,
  reviews: Star,
  call: PhoneCall,
  maps: MapPin,
};

export function ContentTypeSelector({
  selectedType,
  onSelectType,
}: ContentTypeSelectorProps) {
  // Determine initial category based on currently selected type
  const selectedTypeDefinition = useMemo(
    () => SUPPORTED_QR_TYPES.find((t) => t.id === selectedType),
    [selectedType]
  );

  const initialCategory: QrCodeCategory =
    selectedTypeDefinition?.category ?? 'standard';

  const [activeCategory, setActiveCategory] =
    useState<QrCodeCategory>(initialCategory);

  // If selectedType changes externally and doesn't match activeCategory, keep in sync
  const currentCategory = selectedTypeDefinition?.category ?? activeCategory;

  const handleCategorySwitch = (category: QrCodeCategory) => {
    setActiveCategory(category);
    // If current type doesn't belong to the new category, switch to the category's primary type
    const categoryTypes = SUPPORTED_QR_TYPES.filter(
      (t) => t.category === category
    );
    if (!categoryTypes.some((t) => t.id === selectedType)) {
      onSelectType(categoryTypes[0].id);
    }
  };

  const visibleTypes = useMemo(
    () => SUPPORTED_QR_TYPES.filter((t) => t.category === currentCategory),
    [currentCategory]
  );

  return (
    <div className="space-y-3.5">
      {/* Category Segmented Pill Bar */}
      <div
        role="tablist"
        aria-label="QR Code Categories"
        className="flex p-1 rounded-xl bg-slate-100/90 border border-slate-200/80 gap-1"
      >
        {QR_CATEGORIES.map((cat) => {
          const isCatActive = currentCategory === cat.id;
          const CatIcon = cat.id === 'standard' ? Layers : Briefcase;

          return (
            <button
              key={cat.id}
              type="button"
              role="tab"
              aria-selected={isCatActive}
              onClick={() => handleCategorySwitch(cat.id)}
              className={cn(
                'flex flex-1 items-center justify-center gap-2 rounded-lg py-2 px-3 text-xs font-semibold tracking-tight transition-all duration-150 focus-visible:outline-2 focus-visible:outline-indigo-600',
                isCatActive
                  ? 'bg-white text-indigo-950 shadow-xs ring-1 ring-slate-900/5'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              )}
            >
              <CatIcon
                className={cn(
                  'h-3.5 w-3.5 shrink-0',
                  isCatActive ? 'text-indigo-600' : 'text-slate-400'
                )}
                aria-hidden="true"
              />
              <span className="whitespace-nowrap">{cat.label}</span>
              {cat.id === 'business' && (
                <span className="hidden sm:inline-block rounded-full bg-emerald-100 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-800 leading-none">
                  New
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Grid of 4 QR Types for the Active Category */}
      <div
        role="radiogroup"
        aria-label="Select QR code type"
        className="grid grid-cols-2 gap-2.5 sm:grid-cols-2 xl:grid-cols-4"
      >
        {visibleTypes.map((typeDef) => {
          const Icon = TYPE_ICONS[typeDef.id];
          const isSelected = selectedType === typeDef.id;

          return (
            <button
              key={typeDef.id}
              type="button"
              role="radio"
              aria-checked={isSelected}
              onClick={() => onSelectType(typeDef.id)}
              className={cn(
                'group flex flex-col items-center justify-between text-center gap-1.5 rounded-xl border p-3 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 min-h-[96px]',
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 shadow-xs ring-1 ring-indigo-600/20'
                  : 'border-slate-200/90 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50/80 hover:text-slate-900'
              )}
            >
              <div
                className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-lg transition-colors duration-150',
                  isSelected
                    ? typeDef.id === 'whatsapp'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200/70 group-hover:text-slate-700'
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
              </div>
              <div className="w-full">
                <span className="block text-xs font-semibold tracking-tight text-slate-900 leading-tight">
                  {typeDef.label}
                </span>
                <span className="block text-[10px] leading-tight text-slate-400 line-clamp-1 mt-0.5">
                  {typeDef.description}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
