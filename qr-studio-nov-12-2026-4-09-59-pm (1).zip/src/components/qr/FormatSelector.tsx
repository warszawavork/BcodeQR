import { Check, FileCode2, Image } from 'lucide-react';
import type { QrExportFormat } from '@/types';
import { cn } from '@/utils';

interface FormatSelectorProps {
  selectedFormat: QrExportFormat;
  onSelectFormat: (format: QrExportFormat) => void;
}

const EXPORT_FORMATS: ReadonlyArray<{
  id: QrExportFormat;
  label: string;
  hint: string;
  Icon: typeof Image;
}> = [
  {
    id: 'png',
    label: 'PNG',
    hint: 'High-quality image for digital use and sharing',
    Icon: Image,
  },
  {
    id: 'svg',
    label: 'SVG',
    hint: 'Scalable vector file for printing and design',
    Icon: FileCode2,
  },
];

export function FormatSelector({
  selectedFormat,
  onSelectFormat,
}: FormatSelectorProps) {
  return (
    <div>
      <span
        id="format-selector-label"
        className="block text-xs font-semibold tracking-wider text-slate-500 uppercase"
      >
        Format
      </span>
      <div
        role="radiogroup"
        aria-labelledby="format-selector-label"
        className="mt-2.5 grid grid-cols-2 gap-2.5"
      >
        {EXPORT_FORMATS.map(({ id, label, hint, Icon }) => {
          const isSelected = selectedFormat === id;

          return (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={isSelected}
              onClick={() => onSelectFormat(id)}
              className={cn(
                'flex items-center justify-between gap-2 rounded-xl border px-3.5 py-2.5 text-left transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600',
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-1 ring-indigo-600/20'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
              )}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={cn(
                    'h-4 w-4 shrink-0',
                    isSelected ? 'text-indigo-600' : 'text-slate-400'
                  )}
                  aria-hidden="true"
                />
                <div className="min-w-0">
                  <p className="font-mono text-xs font-semibold tracking-tight whitespace-nowrap">
                    {label}
                  </p>
                  <p className="truncate text-[11px] text-slate-500">{hint}</p>
                </div>
              </div>
              {isSelected && (
                <Check
                  className="h-3.5 w-3.5 shrink-0 text-indigo-600"
                  aria-hidden="true"
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
