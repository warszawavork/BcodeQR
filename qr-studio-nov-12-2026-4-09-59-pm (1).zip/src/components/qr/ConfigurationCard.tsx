import { useState } from 'react';
import {
  AlertCircle,
  Building2,
  ExternalLink,
  Eye,
  EyeOff,
  Globe,
  Info,
  Lock,
  MapPin,
  MessageCircle,
  Phone,
  PhoneCall,
  RotateCcw,
  Sparkles,
  Star,
  Wifi,
} from 'lucide-react';
import { WHATSAPP_MESSAGE_PRESETS } from '@/features/qr/business';
import type {
  CallFormData,
  GoogleMapsFormData,
  GoogleReviewsFormData,
  QrCodeType,
  VCardFormData,
  WhatsAppFormData,
  WifiEncryptionType,
  WifiFormData,
} from '@/types';
import { ContentTypeSelector } from './ContentTypeSelector';

interface ConfigurationCardProps {
  selectedType: QrCodeType;
  onSelectType: (type: QrCodeType) => void;
  urlValue: string;
  onUrlChange: (value: string) => void;
  textValue: string;
  onTextChange: (value: string) => void;
  wifiData: WifiFormData;
  onWifiChange: (updater: (prev: WifiFormData) => WifiFormData) => void;
  vcardData: VCardFormData;
  onVCardChange: (updater: (prev: VCardFormData) => VCardFormData) => void;
  whatsappData: WhatsAppFormData;
  onWhatsAppChange: (
    updater: (prev: WhatsAppFormData) => WhatsAppFormData
  ) => void;
  reviewsData: GoogleReviewsFormData;
  onReviewsChange: (
    updater: (prev: GoogleReviewsFormData) => GoogleReviewsFormData
  ) => void;
  callData: CallFormData;
  onCallChange: (updater: (prev: CallFormData) => CallFormData) => void;
  mapsData: GoogleMapsFormData;
  onMapsChange: (
    updater: (prev: GoogleMapsFormData) => GoogleMapsFormData
  ) => void;
  labelNote: string;
  onLabelNoteChange: (value: string) => void;
  validationError?: string | null;
  onClear: () => void;
}

export function ConfigurationCard({
  selectedType,
  onSelectType,
  urlValue,
  onUrlChange,
  textValue,
  onTextChange,
  wifiData,
  onWifiChange,
  vcardData,
  onVCardChange,
  whatsappData,
  onWhatsAppChange,
  reviewsData,
  onReviewsChange,
  callData,
  onCallChange,
  mapsData,
  onMapsChange,
  labelNote,
  onLabelNoteChange,
  validationError,
  onClear,
}: ConfigurationCardProps) {
  const [showWifiPassword, setShowWifiPassword] = useState(false);

  return (
    <section
      aria-labelledby="config-card-heading"
      className="flex h-full flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs sm:p-8"
    >
      <div>
        {/* Content Type Section */}
        <div>
          <h2
            id="config-card-heading"
            className="text-base font-semibold tracking-tight text-slate-900 sm:text-lg"
          >
            Content type
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Choose what your QR code should contain.
          </p>

          <div className="mt-4">
            <ContentTypeSelector
              selectedType={selectedType}
              onSelectType={onSelectType}
            />
          </div>
        </div>

        {/* Subtle Separator */}
        <hr className="my-6 border-slate-200/80" />

        {/* Input Content Header with Clear Action */}
        <div className="space-y-5">
          <div className="flex items-center justify-between gap-4">
            <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
              Input content
            </span>

            <button
              type="button"
              onClick={onClear}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              aria-label="Clear input fields"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Clear</span>
            </button>
          </div>

          {/* Validation Banner if Error Present */}
          {validationError && (
            <div
              role="alert"
              aria-live="polite"
              className="flex items-center gap-2 rounded-xl border border-red-200/80 bg-red-50/70 px-3.5 py-2.5 text-xs font-medium text-red-700"
            >
              <AlertCircle
                className="h-4 w-4 shrink-0 text-red-600"
                aria-hidden="true"
              />
              <span>{validationError}</span>
            </div>
          )}

          {/* ==================== 1. URL FORM ==================== */}
          {selectedType === 'url' && (
            <div className="space-y-5">
              <div>
                <label
                  htmlFor="qr-website-url"
                  className="block text-sm font-medium text-slate-800"
                >
                  Website URL
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Globe className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-website-url"
                    type="url"
                    value={urlValue}
                    onChange={(e) => onUrlChange(e.target.value)}
                    placeholder="https://example.com"
                    aria-invalid={Boolean(validationError)}
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>
                <p className="mt-2 text-xs text-slate-500">
                  Your QR code will open this website when scanned.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-reference-note"
                  className="block text-sm font-medium text-slate-800"
                >
                  QR label or note{' '}
                  <span className="font-normal text-slate-400">(optional)</span>
                </label>
                <input
                  id="qr-reference-note"
                  type="text"
                  value={labelNote}
                  onChange={(e) => onLabelNoteChange(e.target.value)}
                  placeholder="e.g., Main landing page campaign"
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                />
              </div>
            </div>
          )}

          {/* ==================== 2. TEXT FORM ==================== */}
          {selectedType === 'text' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="qr-plain-text"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Plain text message
                  </label>
                  <span className="text-[11px] font-mono text-slate-400">
                    UTF-8 supported
                  </span>
                </div>
                <textarea
                  id="qr-plain-text"
                  rows={4}
                  value={textValue}
                  onChange={(e) => onTextChange(e.target.value)}
                  placeholder="Enter any text, note, or serial code to encode..."
                  aria-invalid={Boolean(validationError)}
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                />
                <p className="mt-2 text-xs text-slate-500">
                  Displays your text directly on the user&apos;s screen when
                  scanned.
                </p>
              </div>
            </div>
          )}

          {/* ==================== 3. WI-FI FORM ==================== */}
          {selectedType === 'wifi' && (
            <div className="space-y-4">
              <div>
                <label
                  htmlFor="qr-wifi-ssid"
                  className="block text-sm font-medium text-slate-800"
                >
                  Network name (SSID){' '}
                  <span className="text-red-500" title="Required">
                    *
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Wifi className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-wifi-ssid"
                    type="text"
                    value={wifiData.ssid}
                    onChange={(e) =>
                      onWifiChange((prev) => ({ ...prev, ssid: e.target.value }))
                    }
                    placeholder="Enter Wi-Fi network name"
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-500">
                  Maximum 32 bytes UTF-8 length.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-wifi-encryption"
                  className="block text-sm font-medium text-slate-800"
                >
                  Security type
                </label>
                <select
                  id="qr-wifi-encryption"
                  value={wifiData.encryption}
                  onChange={(e) =>
                    onWifiChange((prev) => ({
                      ...prev,
                      encryption: e.target.value as WifiEncryptionType,
                    }))
                  }
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                >
                  <option value="WPA">WPA/WPA2</option>
                  <option value="WEP">WEP</option>
                  <option value="nopass">None (Open Network)</option>
                </select>
              </div>

              {wifiData.encryption !== 'nopass' && (
                <div>
                  <label
                    htmlFor="qr-wifi-password"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Password{' '}
                    <span className="text-red-500" title="Required">
                      *
                    </span>
                  </label>
                  <div className="relative mt-2">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                      <Lock className="h-4 w-4" aria-hidden="true" />
                    </div>
                    <input
                      id="qr-wifi-password"
                      type={showWifiPassword ? 'text' : 'password'}
                      value={wifiData.password ?? ''}
                      onChange={(e) =>
                        onWifiChange((prev) => ({
                          ...prev,
                          password: e.target.value,
                        }))
                      }
                      placeholder="Enter Wi-Fi password"
                      className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-10 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                    />
                    <button
                      type="button"
                      onClick={() => setShowWifiPassword((prev) => !prev)}
                      className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 hover:text-slate-600 focus-visible:outline-2 focus-visible:outline-indigo-600"
                      aria-label={
                        showWifiPassword
                          ? 'Hide Wi-Fi password'
                          : 'Show Wi-Fi password'
                      }
                    >
                      {showWifiPassword ? (
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Eye className="h-4 w-4" aria-hidden="true" />
                      )}
                    </button>
                  </div>
                  <p className="mt-1.5 text-xs text-slate-500">
                    {wifiData.encryption === 'WPA'
                      ? '8–63 characters (or 64 hexadecimal characters).'
                      : '5 or 13 characters (or 10/26 hexadecimal characters).'}
                  </p>
                </div>
              )}

              <div className="pt-1">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={wifiData.hidden}
                    onChange={(e) =>
                      onWifiChange((prev) => ({
                        ...prev,
                        hidden: e.target.checked,
                      }))
                    }
                    className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm font-medium text-slate-700">
                    This network is hidden
                  </span>
                </label>
                <p className="mt-1 text-xs text-slate-500 ml-6.5">
                  Appends hidden network flag (H:true) for non-broadcasting SSIDs.
                </p>
              </div>
            </div>
          )}

          {/* ==================== 4. VCARD FORM ==================== */}
          {selectedType === 'vcard' && (
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="qr-vcard-firstname"
                    className="block text-sm font-medium text-slate-800"
                  >
                    First Name{' '}
                    <span className="text-xs font-normal text-slate-500">
                      (or Last Name required)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-firstname"
                    type="text"
                    value={vcardData.firstName}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        firstName: e.target.value,
                      }))
                    }
                    placeholder="John"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>

                <div>
                  <label
                    htmlFor="qr-vcard-lastname"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Last Name{' '}
                    <span className="text-xs font-normal text-slate-500">
                      (or First Name required)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-lastname"
                    type="text"
                    value={vcardData.lastName}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        lastName: e.target.value,
                      }))
                    }
                    placeholder="Smith"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="qr-vcard-org"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Organization{' '}
                    <span className="text-xs font-normal text-slate-400">
                      (optional)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-org"
                    type="text"
                    value={vcardData.organization ?? ''}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        organization: e.target.value,
                      }))
                    }
                    placeholder="Company name"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>

                <div>
                  <label
                    htmlFor="qr-vcard-jobtitle"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Job Title{' '}
                    <span className="text-xs font-normal text-slate-400">
                      (optional)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-jobtitle"
                    type="text"
                    value={vcardData.jobTitle ?? ''}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        jobTitle: e.target.value,
                      }))
                    }
                    placeholder="Position"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="qr-vcard-phone"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Phone{' '}
                    <span className="text-xs font-normal text-slate-400">
                      (optional)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-phone"
                    type="tel"
                    value={vcardData.phone ?? ''}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        phone: e.target.value,
                      }))
                    }
                    placeholder="+48 123 456 789"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>

                <div>
                  <label
                    htmlFor="qr-vcard-email"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Email{' '}
                    <span className="text-xs font-normal text-slate-400">
                      (optional)
                    </span>
                  </label>
                  <input
                    id="qr-vcard-email"
                    type="email"
                    value={vcardData.email ?? ''}
                    onChange={(e) =>
                      onVCardChange((prev) => ({
                        ...prev,
                        email: e.target.value,
                      }))
                    }
                    placeholder="john@example.com"
                    className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="qr-vcard-website"
                  className="block text-sm font-medium text-slate-800"
                >
                  Website{' '}
                  <span className="text-xs font-normal text-slate-400">
                    (optional)
                  </span>
                </label>
                <input
                  id="qr-vcard-website"
                  type="url"
                  value={vcardData.website ?? ''}
                  onChange={(e) =>
                    onVCardChange((prev) => ({
                      ...prev,
                      website: e.target.value,
                    }))
                  }
                  placeholder="https://example.com"
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-indigo-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-indigo-600/15"
                />
              </div>

              <p className="text-xs text-slate-500">
                Encodes vCard 3.0 digital business card format recognized by iOS
                and Android contacts.
              </p>
            </div>
          )}

          {/* ==================== 5. WHATSAPP CHAT FORM ==================== */}
          {selectedType === 'whatsapp' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex h-5 w-5 items-center justify-center rounded-md bg-emerald-600 text-white">
                    <MessageCircle className="h-3.5 w-3.5" aria-hidden="true" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    WhatsApp Chat QR
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Let customers contact you directly on WhatsApp by scanning
                  your QR code.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-whatsapp-phone"
                  className="block text-sm font-medium text-slate-800"
                >
                  Phone Number{' '}
                  <span className="text-red-500" title="Required">
                    *
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Phone className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-whatsapp-phone"
                    type="tel"
                    value={whatsappData.phone}
                    onChange={(e) =>
                      onWhatsAppChange((prev) => ({
                        ...prev,
                        phone: e.target.value,
                      }))
                    }
                    placeholder="+48 500 123 456"
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-emerald-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-emerald-600/15"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-500">
                  Enter your full international phone number, including country
                  code.
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="qr-whatsapp-message"
                    className="block text-sm font-medium text-slate-800"
                  >
                    Pre-filled Message{' '}
                    <span className="font-normal text-slate-400">
                      (Optional)
                    </span>
                  </label>
                  <span className="text-[11px] font-mono text-slate-400">
                    {whatsappData.message.length} chars
                  </span>
                </div>
                <textarea
                  id="qr-whatsapp-message"
                  rows={3}
                  value={whatsappData.message}
                  onChange={(e) =>
                    onWhatsAppChange((prev) => ({
                      ...prev,
                      message: e.target.value,
                    }))
                  }
                  placeholder="Hello! I'm interested in your offer. Could you provide more information?"
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-emerald-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-emerald-600/15"
                />
                <p className="mt-1.5 text-xs text-slate-500">
                  This message will appear automatically in the WhatsApp chat.
                </p>
              </div>

              {/* Message Presets */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="h-3 w-3 text-amber-500" /> Quick Message
                  Templates:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {WHATSAPP_MESSAGE_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() =>
                        onWhatsAppChange((prev) => ({
                          ...prev,
                          message: preset,
                        }))
                      }
                      className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 text-left text-xs text-slate-700 transition hover:border-emerald-300 hover:bg-emerald-50/60 hover:text-emerald-900"
                    >
                      &ldquo;{preset}&rdquo;
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-start gap-2 rounded-xl bg-slate-50 border border-slate-200/80 p-3 text-xs text-slate-600">
                <Info
                  className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <span>
                  Scanning this QR code opens a WhatsApp conversation with your
                  pre-filled text ready to review. The customer manually taps
                  send.
                </span>
              </div>
            </div>
          )}

          {/* ==================== 6. GOOGLE REVIEWS FORM ==================== */}
          {selectedType === 'reviews' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex h-5 w-5 items-center justify-center rounded-md bg-amber-500 text-white">
                    <Star className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Google Reviews QR
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Make it easy for your customers to share their honest feedback
                  on Google.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-review-business"
                  className="block text-sm font-medium text-slate-800"
                >
                  Business Name{' '}
                  <span className="text-xs font-normal text-slate-400">
                    (Optional)
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Building2 className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-review-business"
                    type="text"
                    value={reviewsData.businessName}
                    onChange={(e) =>
                      onReviewsChange((prev) => ({
                        ...prev,
                        businessName: e.target.value,
                      }))
                    }
                    placeholder="Your business name"
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-amber-500 focus:bg-white focus:outline-none focus:ring-3 focus:ring-amber-500/15"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="qr-review-link"
                  className="block text-sm font-medium text-slate-800"
                >
                  Google Review Link{' '}
                  <span className="text-red-500" title="Required">
                    *
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Globe className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-review-link"
                    type="url"
                    value={reviewsData.reviewUrl}
                    onChange={(e) =>
                      onReviewsChange((prev) => ({
                        ...prev,
                        reviewUrl: e.target.value,
                      }))
                    }
                    placeholder="https://g.page/r/your-business-review"
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-amber-500 focus:bg-white focus:outline-none focus:ring-3 focus:ring-amber-500/15"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-500">
                  Paste your Google review link to create a QR code that takes
                  customers directly to your review page.
                </p>
              </div>

              {/* Instructional Step-by-Step Block */}
              <div className="rounded-xl border border-amber-200/80 bg-amber-50/50 p-4 text-xs text-slate-700 space-y-2.5">
                <span className="font-semibold text-amber-900 block tracking-tight uppercase text-[11px]">
                  How to get your Google Review link:
                </span>
                <ol className="space-y-1.5 list-decimal list-inside text-slate-600">
                  <li>Open your Google Business Profile.</li>
                  <li>Select &ldquo;Read Reviews&rdquo;.</li>
                  <li>Click &ldquo;Get more reviews&rdquo;.</li>
                  <li>Copy your review link and paste it into QR Studio.</li>
                </ol>

                <div className="pt-1 border-t border-amber-200/60 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">
                    Official Google Help Guide
                  </span>
                  <a
                    href="https://support.google.com/business/answer/16816815"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-medium text-amber-900 hover:underline"
                  >
                    <span>Open Google Business Profile Help</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Info className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                <span>
                  Customers should always be encouraged to leave honest and
                  genuine feedback.
                </span>
              </div>
            </div>
          )}

          {/* ==================== 7. CALL US FORM ==================== */}
          {selectedType === 'call' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex h-5 w-5 items-center justify-center rounded-md bg-blue-600 text-white">
                    <PhoneCall className="h-3.5 w-3.5" aria-hidden="true" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Call Us QR
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Let customers call your business by scanning a QR code.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-call-phone"
                  className="block text-sm font-medium text-slate-800"
                >
                  Phone Number{' '}
                  <span className="text-red-500" title="Required">
                    *
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Phone className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-call-phone"
                    type="tel"
                    value={callData.phone}
                    onChange={(e) =>
                      onCallChange((prev) => ({
                        ...prev,
                        phone: e.target.value,
                      }))
                    }
                    placeholder="+48 500 123 456"
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-blue-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-blue-600/15"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-500">
                  Generates a standardized tel: protocol URL (e.g.,
                  tel:+48500123456).
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-call-company"
                  className="block text-sm font-medium text-slate-800"
                >
                  Business Name{' '}
                  <span className="text-xs font-normal text-slate-400">
                    (Optional)
                  </span>
                </label>
                <input
                  id="qr-call-company"
                  type="text"
                  value={callData.businessName}
                  onChange={(e) =>
                    onCallChange((prev) => ({
                      ...prev,
                      businessName: e.target.value,
                    }))
                  }
                  placeholder="Your company name"
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-blue-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-blue-600/15"
                />
              </div>

              <div className="flex items-start gap-2 rounded-xl bg-slate-50 border border-slate-200/80 p-3 text-xs text-slate-600">
                <Info
                  className="h-4 w-4 text-blue-600 shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <span>
                  Scanning this QR code opens the phone app with your number
                  ready to call. Devices may request user confirmation before
                  dialing.
                </span>
              </div>
            </div>
          )}

          {/* ==================== 8. GOOGLE MAPS FORM ==================== */}
          {selectedType === 'maps' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex h-5 w-5 items-center justify-center rounded-md bg-rose-600 text-white">
                    <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                  </div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    Google Maps QR
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  Help customers find your business with one quick scan.
                </p>
              </div>

              <div>
                <label
                  htmlFor="qr-maps-location"
                  className="block text-sm font-medium text-slate-800"
                >
                  Location Name{' '}
                  <span className="text-xs font-normal text-slate-400">
                    (Optional)
                  </span>
                </label>
                <input
                  id="qr-maps-location"
                  type="text"
                  value={mapsData.locationName}
                  onChange={(e) =>
                    onMapsChange((prev) => ({
                      ...prev,
                      locationName: e.target.value,
                    }))
                  }
                  placeholder="ROB-STAL Warehouse"
                  className="mt-2 block w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-rose-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-rose-600/15"
                />
              </div>

              <div>
                <label
                  htmlFor="qr-maps-link"
                  className="block text-sm font-medium text-slate-800"
                >
                  Google Maps Link{' '}
                  <span className="text-red-500" title="Required">
                    *
                  </span>
                </label>
                <div className="relative mt-2">
                  <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <MapPin className="h-4 w-4" aria-hidden="true" />
                  </div>
                  <input
                    id="qr-maps-link"
                    type="url"
                    value={mapsData.mapsUrl}
                    onChange={(e) =>
                      onMapsChange((prev) => ({
                        ...prev,
                        mapsUrl: e.target.value,
                      }))
                    }
                    placeholder="https://maps.app.goo.gl/..."
                    className="block w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pr-4 pl-10 text-sm text-slate-900 placeholder:text-slate-400 transition-colors focus:border-rose-600 focus:bg-white focus:outline-none focus:ring-3 focus:ring-rose-600/15"
                  />
                </div>
                <p className="mt-1.5 text-xs text-slate-500">
                  Copy the location link from Google Maps and paste it here.
                </p>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="rounded-xl border border-slate-200/80 bg-slate-50/70 p-3.5 text-xs text-slate-700 space-y-2">
                <span className="font-semibold text-slate-800 block text-[11px] uppercase tracking-tight">
                  How to get your Google Maps share link:
                </span>
                <ol className="space-y-1 list-decimal list-inside text-slate-600">
                  <li>Open Google Maps.</li>
                  <li>Find your business location.</li>
                  <li>Select Share.</li>
                  <li>Copy the link.</li>
                  <li>Paste it into QR Studio.</li>
                </ol>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8 flex items-center justify-between border-t border-slate-100 pt-4 text-xs text-slate-400">
        <span>All fields are validated and encoded client-side</span>
        <span className="font-mono uppercase">{selectedType} payload</span>
      </div>
    </section>
  );
}
