import { useState } from 'react';
import {
  AlertCircle,
  BookmarkPlus,
  Check,
  Contact,
  Copy,
  Download,
  FileText,
  Globe,
  Loader2,
  MapPin,
  MessageCircle,
  PhoneCall,
  Shield,
  Star,
  Wifi,
} from 'lucide-react';
import type { QrCodeType, QrExportFormat, QrStyleConfig } from '@/types';
import { exportAndDownloadQr } from '@/features/qr';
import { cn } from '@/utils';
import { FormatSelector } from './FormatSelector';

interface QRPreviewCardProps {
  selectedFormat: QrExportFormat;
  onSelectFormat: (format: QrExportFormat) => void;
  selectedType: QrCodeType;
  qrDataUrl: string | null;
  isLoading: boolean;
  activeError?: string | null;
  content: string;
  styleConfig?: QrStyleConfig;
  onSaveToHistory?: () => void;
}

const SERVICE_META: Record<
  QrCodeType,
  {
    label: string;
    icon: typeof Globe;
    accentBg: string;
    accentText: string;
    successMessage: string;
    description: string;
  }
> = {
  url: {
    label: 'Website URL',
    icon: Globe,
    accentBg: 'bg-indigo-50',
    accentText: 'text-indigo-600',
    successMessage: 'Ready to open your website link.',
    description: 'Directs users to your specified URL when scanned.',
  },
  text: {
    label: 'Plain Text',
    icon: FileText,
    accentBg: 'bg-slate-100',
    accentText: 'text-slate-600',
    successMessage: 'Ready to display your text note.',
    description: 'Shows plain text directly on the screen.',
  },
  wifi: {
    label: 'Wi-Fi Network',
    icon: Wifi,
    accentBg: 'bg-indigo-50',
    accentText: 'text-indigo-600',
    successMessage: 'Ready to connect to Wi-Fi automatically.',
    description: 'Allows one-tap connection to wireless network.',
  },
  vcard: {
    label: 'vCard Contact',
    icon: Contact,
    accentBg: 'bg-indigo-50',
    accentText: 'text-indigo-600',
    successMessage: 'Ready to import digital business card.',
    description: 'Saves full contact details directly to address book.',
  },
  whatsapp: {
    label: 'WhatsApp Chat',
    icon: MessageCircle,
    accentBg: 'bg-emerald-50',
    accentText: 'text-emerald-600',
    successMessage: 'Ready to start a conversation.',
    description: 'Opens WhatsApp with your phone and pre-filled message.',
  },
  reviews: {
    label: 'Google Reviews',
    icon: Star,
    accentBg: 'bg-amber-50',
    accentText: 'text-amber-600',
    successMessage: 'Ready to collect genuine customer feedback.',
    description: 'Directs customers directly to your Google review page.',
  },
  call: {
    label: 'Call Us',
    icon: PhoneCall,
    accentBg: 'bg-blue-50',
    accentText: 'text-blue-600',
    successMessage: 'Ready to connect customers with your business.',
    description: 'Opens phone dialer with your company number ready.',
  },
  maps: {
    label: 'Google Maps',
    icon: MapPin,
    accentBg: 'bg-rose-50',
    accentText: 'text-rose-600',
    successMessage: 'Ready to help customers find your location.',
    description: 'Guides customers to your location using Google Maps.',
  },
};

/**
 * Architectural static QR code placeholder vector pattern.
 */
function StaticQrPlaceholder() {
  const dataCells: ReadonlyArray<readonly [number, number]> = [
    [8, 0],
    [10, 0],
    [12, 0],
    [8, 1],
    [11, 1],
    [9, 2],
    [10, 2],
    [12, 2],
    [8, 3],
    [11, 3],
    [12, 3],
    [9, 4],
    [10, 4],
    [8, 5],
    [12, 5],
    [8, 6],
    [10, 6],
    [12, 6],
    [0, 8],
    [2, 8],
    [4, 8],
    [6, 8],
    [8, 8],
    [9, 8],
    [11, 8],
    [13, 8],
    [15, 8],
    [17, 8],
    [19, 8],
    [1, 9],
    [3, 9],
    [5, 9],
    [8, 9],
    [12, 9],
    [14, 9],
    [16, 9],
    [20, 9],
    [0, 10],
    [2, 10],
    [6, 10],
    [7, 10],
    [10, 10],
    [11, 10],
    [13, 10],
    [15, 10],
    [18, 10],
    [19, 10],
    [1, 11],
    [4, 11],
    [5, 11],
    [9, 11],
    [12, 11],
    [14, 11],
    [17, 11],
    [20, 11],
    [0, 12],
    [2, 12],
    [3, 12],
    [6, 12],
    [8, 12],
    [10, 12],
    [11, 12],
    [13, 12],
    [16, 12],
    [18, 12],
    [20, 12],
    [8, 13],
    [9, 13],
    [12, 13],
    [14, 13],
    [15, 13],
    [17, 13],
    [19, 13],
    [8, 14],
    [11, 14],
    [13, 14],
    [16, 14],
    [18, 14],
    [20, 14],
    [9, 15],
    [10, 15],
    [12, 15],
    [14, 15],
    [15, 15],
    [17, 15],
    [19, 15],
    [8, 16],
    [11, 16],
    [12, 16],
    [13, 16],
    [16, 16],
    [18, 16],
    [20, 16],
    [9, 17],
    [10, 17],
    [14, 17],
    [15, 17],
    [17, 17],
    [19, 17],
    [8, 18],
    [11, 18],
    [12, 18],
    [13, 18],
    [16, 18],
    [18, 18],
    [20, 18],
    [9, 19],
    [10, 19],
    [14, 19],
    [15, 19],
    [17, 19],
    [19, 19],
    [8, 20],
    [10, 20],
    [12, 20],
    [13, 20],
    [16, 20],
    [18, 20],
    [20, 20],
  ];

  return (
    <svg
      viewBox="0 0 21 21"
      className="h-44 w-44 text-slate-900 sm:h-48 sm:w-48"
      role="img"
      aria-label="Static QR code preview pattern"
    >
      <path
        fill="currentColor"
        d="M0,0 h7 v7 h-7 z M1,1 v5 h5 v-5 z M2,2 h3 v3 h-3 z"
      />
      <path
        fill="currentColor"
        d="M14,0 h7 v7 h-7 z M15,1 v5 h5 v-5 z M16,2 h3 v3 h-3 z"
      />
      <path
        fill="currentColor"
        d="M0,14 h7 v7 h-7 z M1,15 v5 h5 v-5 z M2,16 h3 v3 h-3 z"
      />
      {dataCells.map(([x, y]) => (
        <rect
          key={`${x}-${y}`}
          x={x}
          y={y}
          width={0.9}
          height={0.9}
          rx={0.18}
          fill="currentColor"
        />
      ))}
    </svg>
  );
}

export function QRPreviewCard({
  selectedFormat,
  onSelectFormat,
  selectedType,
  qrDataUrl,
  isLoading,
  activeError,
  content,
  styleConfig,
  onSaveToHistory,
}: QRPreviewCardProps) {
  const hasValidQr = Boolean(qrDataUrl);
  const meta = SERVICE_META[selectedType];
  const ServiceIcon = meta.icon;

  const [copied, setCopied] = useState(false);
  const [exportState, setExportState] = useState<
    'idle' | 'exporting' | 'success' | 'error'
  >('idle');
  const [exportError, setExportError] = useState<string | null>(null);

  const handleCopyPayload = async () => {
    if (!content) return;
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard permission issues gracefully
    }
  };

  const handleDownload = async () => {
    if (
      !content ||
      !styleConfig ||
      !hasValidQr ||
      Boolean(activeError) ||
      exportState === 'exporting'
    ) {
      return;
    }

    setExportState('exporting');
    setExportError(null);

    try {
      await exportAndDownloadQr({
        payload: content,
        type: selectedType,
        format: selectedFormat,
        style: styleConfig,
      });

      setExportState('success');
      setTimeout(() => {
        setExportState('idle');
      }, 2500);
    } catch (error) {
      setExportState('error');
      setExportError(
        error instanceof Error
          ? error.message
          : 'Unable to export your QR code. Please try again.'
      );
      setTimeout(() => {
        setExportState('idle');
      }, 4000);
    }
  };

  return (
    <section
      aria-labelledby="preview-card-heading"
      className="flex h-full flex-col justify-between rounded-2xl border border-slate-200/90 bg-white p-6 shadow-xs sm:p-8"
    >
      <div>
        {/* Header with Type Badge */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2
              id="preview-card-heading"
              className="text-base font-semibold tracking-tight text-slate-900 sm:text-lg"
            >
              QR Preview
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              {hasValidQr
                ? 'Your design, ready to download.'
                : 'Live preview generated in your browser.'}
            </p>
          </div>

          <div
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold ${meta.accentBg} ${meta.accentText}`}
          >
            <ServiceIcon className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{meta.label}</span>
          </div>
        </div>

        {/* Center QR Canvas Viewport */}
        <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-slate-200/80 bg-[#F7F8FA] px-6 py-7">
          <div className="relative rounded-2xl border border-slate-200/90 bg-white p-5 shadow-xs overflow-hidden">
            {hasValidQr && qrDataUrl ? (
              <img
                src={qrDataUrl}
                alt={`Generated QR code for ${selectedType}: ${content}`}
                data-testid="qr-preview-image"
                className="h-44 w-44 object-contain sm:h-48 sm:w-48 transition-opacity duration-200"
              />
            ) : (
              <div className={activeError ? 'opacity-40' : 'opacity-100'}>
                <StaticQrPlaceholder />
              </div>
            )}

            {/* Subtle Loading Overlay */}
            {isLoading && (
              <div
                role="status"
                aria-label="Generating QR code"
                className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 backdrop-blur-[1px] transition-opacity duration-150"
              >
                <Loader2 className="h-7 w-7 animate-spin text-indigo-600" />
                <span className="mt-2 text-[11px] font-medium text-slate-600">
                  Rendering...
                </span>
              </div>
            )}
          </div>

          {/* Dynamic Status Label */}
          <div className="mt-4 text-center">
            <p className="text-xs font-semibold text-slate-800">
              {hasValidQr
                ? meta.successMessage
                : activeError
                ? 'Please correct input errors to generate code'
                : 'Waiting for content input'}
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {hasValidQr
                ? 'Generated locally in your browser.'
                : 'Fill in the form to generate your QR code.'}
            </p>
          </div>

          {/* Destination Link / Payload Copy Pill */}
          {hasValidQr && content && (
            <div className="mt-3 flex w-full max-w-[280px] items-center justify-between rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-600 shadow-2xs">
              <span className="truncate font-mono text-[11px] text-slate-500 max-w-[190px]">
                {content}
              </span>
              <button
                type="button"
                onClick={handleCopyPayload}
                className="inline-flex items-center gap-1 font-medium text-indigo-600 hover:text-indigo-800 transition"
                title="Copy generated destination"
                aria-label="Copy destination URL"
              >
                {copied ? (
                  <>
                    <Check className="h-3 w-3 text-emerald-600" />
                    <span className="text-[10px] text-emerald-600">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3 w-3" />
                    <span className="text-[10px]">Copy</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Technical Specifications Badge Strip */}
          {styleConfig && (
            <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5 text-[10px] font-mono text-slate-500">
              <span className="rounded-md border border-slate-200/90 bg-white px-2 py-0.5">
                {styleConfig.size}×{styleConfig.size}px
              </span>
              <span className="rounded-md border border-slate-200/90 bg-white px-2 py-0.5">
                EC: {styleConfig.logo.enabled ? 'H' : styleConfig.errorCorrectionLevel}
              </span>
              <span className="rounded-md border border-slate-200/90 bg-white px-2 py-0.5">
                Quiet: {styleConfig.margin} mod
              </span>
              {styleConfig.logo.enabled && (
                <span className="rounded-md border border-indigo-200 bg-indigo-50 px-2 py-0.5 text-indigo-700 font-semibold">
                  Logo Active
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Format & Download Section */}
      <div className="mt-6 space-y-4">
        <FormatSelector
          selectedFormat={selectedFormat}
          onSelectFormat={onSelectFormat}
        />

        {/* Small Technical Export Summary (Prompt Requirement) */}
        {styleConfig && (
          <div className="rounded-xl border border-slate-200/90 bg-[#F7F8FA] p-3 text-xs text-slate-600">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200/70">
              <span className="font-semibold text-slate-700">Export Specifications</span>
              <span className="font-mono text-[11px] font-bold text-indigo-700 bg-white border border-indigo-200 px-2 py-0.5 rounded shadow-2xs uppercase">
                {selectedFormat}
              </span>
            </div>
            <div className="mt-2.5 grid grid-cols-2 gap-y-1.5 gap-x-3 text-[11px]">
              <div>
                <span className="text-slate-400">Resolution:</span>{' '}
                <span className="font-mono font-medium text-slate-800">
                  {selectedFormat === 'svg'
                    ? `Vector (${styleConfig.size}×${styleConfig.size}px base)`
                    : `${styleConfig.size} × ${styleConfig.size} px`}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Error correction:</span>{' '}
                <span className="font-mono font-medium text-slate-800">
                  {styleConfig.logo.enabled
                    ? 'H (~30%)'
                    : styleConfig.errorCorrectionLevel}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Logo:</span>{' '}
                <span className="font-medium text-slate-800">
                  {styleConfig.logo.enabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Quiet zone:</span>{' '}
                <span className="font-mono font-medium text-slate-800">
                  4 modules
                </span>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2.5">
          <button
            type="button"
            data-testid="download-qr-button"
            disabled={
              !hasValidQr || Boolean(activeError) || exportState === 'exporting'
            }
            onClick={handleDownload}
            aria-live="polite"
            className={cn(
              'flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-white shadow-xs transition-all duration-150',
              !hasValidQr || Boolean(activeError)
                ? 'cursor-not-allowed bg-slate-200 text-slate-400 shadow-none'
                : exportState === 'exporting'
                ? 'cursor-wait bg-indigo-500 text-white'
                : exportState === 'success'
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
                : exportState === 'error'
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 shadow-indigo-600/20 cursor-pointer'
            )}
          >
            {exportState === 'exporting' && (
              <>
                <Loader2
                  className="h-4 w-4 animate-spin text-white"
                  aria-hidden="true"
                />
                <span className="whitespace-nowrap">
                  Preparing your QR code...
                </span>
              </>
            )}
            {exportState === 'success' && (
              <>
                <Check className="h-4 w-4 text-white" aria-hidden="true" />
                <span className="whitespace-nowrap">Download started</span>
              </>
            )}
            {exportState === 'error' && (
              <>
                <AlertCircle className="h-4 w-4 text-white" aria-hidden="true" />
                <span className="whitespace-nowrap truncate max-w-[260px]">
                  {exportError || 'Unable to export your QR code. Please try again.'}
                </span>
              </>
            )}
            {exportState === 'idle' && (
              <>
                <Download className="h-4 w-4" aria-hidden="true" />
                <span className="whitespace-nowrap">Download QR Code</span>
              </>
            )}
          </button>

          {/* Explicit Save to History Action */}
          {onSaveToHistory && (
            <button
              type="button"
              data-testid="save-history-button"
              disabled={!hasValidQr || Boolean(activeError)}
              onClick={onSaveToHistory}
              className={cn(
                'flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 shadow-2xs hover:bg-slate-50 active:bg-slate-100 transition-all cursor-pointer',
                (!hasValidQr || Boolean(activeError)) &&
                  'cursor-not-allowed opacity-50 bg-slate-50 text-slate-400 border-slate-100 shadow-none'
              )}
            >
              <BookmarkPlus
                className="h-4 w-4 text-indigo-600 shrink-0"
                aria-hidden="true"
              />
              <span>Save to History</span>
            </button>
          )}

          <p className="flex items-center justify-center gap-1.5 text-center text-xs text-slate-500">
            <Shield
              className="h-3.5 w-3.5 text-slate-400 shrink-0"
              aria-hidden="true"
            />
            <span>Generated locally in your browser. No data stored on servers.</span>
          </p>
        </div>
      </div>
    </section>
  );
}
