import { type ChangeEvent, useId, useMemo, useRef } from 'react';
import {
  AlertTriangle,
  Check,
  Image as ImageIcon,
  RotateCcw,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  QR_COLOR_PRESETS,
  QR_ERROR_CORRECTION_LEVELS,
  QR_SIZES,
  type QrSizeOption,
} from '@/lib/constants';
import type {
  QrBackingShape,
  QrErrorCorrectionLevel,
  QrStyleConfig,
} from '@/types';
import { cn, getContrastRatio, isValidHexColor } from '@/utils';

interface QrCustomizationPanelProps {
  styleConfig: QrStyleConfig;
  onUpdateStyle: (updater: (prev: QrStyleConfig) => QrStyleConfig) => void;
  onApplyPreset: (presetId: string) => void;
  onResetStyle: () => void;
}

const BRAND_LOGO_SRC = '/assets/brand-logo.png';
const MAX_LOGO_BYTES = 2 * 1024 * 1024; // 2 MB

export function QrCustomizationPanel({
  styleConfig,
  onUpdateStyle,
  onApplyPreset,
  onResetStyle,
}: QrCustomizationPanelProps) {
  const fgColorInputId = useId();
  const bgColorInputId = useId();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Contrast Ratio Calculation
  const contrastRatio = useMemo(() => {
    return getContrastRatio(
      styleConfig.foregroundColor,
      styleConfig.backgroundColor
    );
  }, [styleConfig.foregroundColor, styleConfig.backgroundColor]);

  const isLowContrast = contrastRatio !== null && contrastRatio < 3.5;
  const isIdenticalColor =
    styleConfig.foregroundColor.toLowerCase() ===
    styleConfig.backgroundColor.toLowerCase();

  const isFgValid = isValidHexColor(styleConfig.foregroundColor);
  const isBgValid = isValidHexColor(styleConfig.backgroundColor);

  // Handle Foreground Color Change
  const handleFgChange = (newHex: string) => {
    onUpdateStyle((prev) => ({
      ...prev,
      foregroundColor: newHex,
      selectedPreset: null,
    }));
  };

  // Handle Background Color Change
  const handleBgChange = (newHex: string) => {
    onUpdateStyle((prev) => ({
      ...prev,
      backgroundColor: newHex,
      selectedPreset: null,
    }));
  };

  // Handle Size Change
  const handleSizeChange = (newSize: QrSizeOption) => {
    onUpdateStyle((prev) => ({
      ...prev,
      size: newSize,
    }));
  };

  // Handle Error Correction Level Change
  const handleLevelChange = (level: QrErrorCorrectionLevel) => {
    onUpdateStyle((prev) => ({
      ...prev,
      errorCorrectionLevel: level,
    }));
  };

  // Handle Logo Toggle
  const handleToggleLogo = (enabled: boolean) => {
    onUpdateStyle((prev) => {
      // When enabling logo, default to brand logo if no dataUrl set, and force error correction to 'H'
      const updatedLogo = {
        ...prev.logo,
        enabled,
        dataUrl: prev.logo.dataUrl ?? BRAND_LOGO_SRC,
        name: prev.logo.name || 'QR Studio Brand Mark',
      };
      return {
        ...prev,
        errorCorrectionLevel: enabled ? 'H' : prev.errorCorrectionLevel,
        logo: updatedLogo,
      };
    });
  };

  // Handle Logo Backing Shape
  const handleBackingShapeChange = (shape: QrBackingShape) => {
    onUpdateStyle((prev) => ({
      ...prev,
      logo: {
        ...prev.logo,
        backingShape: shape,
      },
    }));
  };

  // Handle Logo Preset Click (Use Brand Logo)
  const handleSelectBrandLogo = () => {
    onUpdateStyle((prev) => ({
      ...prev,
      logo: {
        ...prev.logo,
        enabled: true,
        dataUrl: BRAND_LOGO_SRC,
        name: 'QR Studio Brand Mark',
      },
      errorCorrectionLevel: 'H',
    }));
  };

  // Handle Logo File Upload with strict mime, image decoding, and dimension validation
  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type.toLowerCase())) {
      alert('Security error: Only PNG, JPEG, and WebP image files are allowed. SVG and HTML uploads are forbidden.');
      e.target.value = '';
      return;
    }

    if (file.size > MAX_LOGO_BYTES) {
      alert('Logo file size must be under 2 MB.');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => {
      alert('Failed to read logo file.');
      if (e.target) e.target.value = '';
    };

    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();

      img.onerror = () => {
        alert('Invalid or corrupted image file. Please upload a valid PNG, JPEG, or WebP image.');
        if (e.target) e.target.value = '';
      };

      img.onload = () => {
        if (img.naturalWidth > 4096 || img.naturalHeight > 4096) {
          alert('Image resolution is too large (maximum 4096 × 4096 px allowed). Please upload a smaller logo.');
          if (e.target) e.target.value = '';
          return;
        }

        if (img.naturalWidth === 0 || img.naturalHeight === 0) {
          alert('Invalid image dimensions.');
          if (e.target) e.target.value = '';
          return;
        }

        onUpdateStyle((prev) => ({
          ...prev,
          logo: {
            ...prev.logo,
            enabled: true,
            dataUrl,
            name: file.name,
          },
          errorCorrectionLevel: 'H',
        }));
      };

      img.src = dataUrl;
    };

    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Handle Remove Logo
  const handleRemoveLogo = () => {
    onUpdateStyle((prev) => ({
      ...prev,
      logo: {
        ...prev.logo,
        enabled: false,
        dataUrl: null,
        name: '',
      },
    }));
  };

  return (
    <div className="space-y-6 pt-2">
      {/* Panel Header & Reset Action */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold tracking-tight text-slate-900">
            Customize your QR code
          </h3>
          <p className="mt-0.5 text-xs text-slate-500">
            Make your QR code match your brand and visual identity.
          </p>
        </div>

        <button
          type="button"
          onClick={onResetStyle}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-indigo-600"
          aria-label="Reset design to defaults"
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Reset Design</span>
        </button>
      </div>

      {/* ================= GROUP A: COLORS ================= */}
      <div className="space-y-4 rounded-xl border border-slate-200/80 bg-slate-50/50 p-4">
        <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase block">
          Colors & Contrast
        </span>

        <div className="grid gap-4 sm:grid-cols-2">
          {/* Foreground Color */}
          <div>
            <label
              htmlFor={fgColorInputId}
              className="block text-xs font-medium text-slate-700"
            >
              Foreground Color (Modules)
            </label>
            <div className="mt-1.5 flex items-center gap-2">
              <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white shadow-2xs overflow-hidden">
                <input
                  id={fgColorInputId}
                  type="color"
                  value={isFgValid ? styleConfig.foregroundColor : '#0F172A'}
                  onChange={(e) => handleFgChange(e.target.value)}
                  className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                  aria-label="Foreground color picker"
                />
                <div
                  className="h-6 w-6 rounded-md border border-black/10"
                  style={{
                    backgroundColor: isFgValid
                      ? styleConfig.foregroundColor
                      : '#0F172A',
                  }}
                />
              </div>
              <input
                type="text"
                value={styleConfig.foregroundColor}
                onChange={(e) => handleFgChange(e.target.value)}
                placeholder="#0F172A"
                maxLength={7}
                className={cn(
                  'block w-full rounded-lg border bg-white px-3 py-1.5 font-mono text-xs text-slate-900 uppercase transition focus:outline-none focus:ring-2',
                  isFgValid
                    ? 'border-slate-200 focus:border-indigo-600 focus:ring-indigo-600/15'
                    : 'border-red-300 bg-red-50/50 text-red-900 focus:border-red-500 focus:ring-red-500/15'
                )}
                aria-label="Foreground color hex code"
              />
            </div>
          </div>

          {/* Background Color */}
          <div>
            <label
              htmlFor={bgColorInputId}
              className="block text-xs font-medium text-slate-700"
            >
              Background Color
            </label>
            <div className="mt-1.5 flex items-center gap-2">
              <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white shadow-2xs overflow-hidden">
                <input
                  id={bgColorInputId}
                  type="color"
                  value={isBgValid ? styleConfig.backgroundColor : '#FFFFFF'}
                  onChange={(e) => handleBgChange(e.target.value)}
                  className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                  aria-label="Background color picker"
                />
                <div
                  className="h-6 w-6 rounded-md border border-black/10"
                  style={{
                    backgroundColor: isBgValid
                      ? styleConfig.backgroundColor
                      : '#FFFFFF',
                  }}
                />
              </div>
              <input
                type="text"
                value={styleConfig.backgroundColor}
                onChange={(e) => handleBgChange(e.target.value)}
                placeholder="#FFFFFF"
                maxLength={7}
                className={cn(
                  'block w-full rounded-lg border bg-white px-3 py-1.5 font-mono text-xs text-slate-900 uppercase transition focus:outline-none focus:ring-2',
                  isBgValid
                    ? 'border-slate-200 focus:border-indigo-600 focus:ring-indigo-600/15'
                    : 'border-red-300 bg-red-50/50 text-red-900 focus:border-red-500 focus:ring-red-500/15'
                )}
                aria-label="Background color hex code"
              />
            </div>
          </div>
        </div>

        {/* Visual Swatch & Contrast Indicator */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-500">Live Palette:</span>
            <div
              className="flex h-5 items-center rounded-md px-2 border shadow-2xs text-[11px] font-semibold"
              style={{
                backgroundColor: isBgValid
                  ? styleConfig.backgroundColor
                  : '#FFFFFF',
                color: isFgValid ? styleConfig.foregroundColor : '#0F172A',
                borderColor: 'rgba(0,0,0,0.1)',
              }}
            >
              QR Pattern Sample
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {contrastRatio !== null && (
              <span
                className={cn(
                  'inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-medium',
                  isLowContrast || isIdenticalColor
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-emerald-100 text-emerald-800'
                )}
              >
                {isLowContrast || isIdenticalColor ? (
                  <AlertTriangle className="h-3 w-3" />
                ) : (
                  <ShieldCheck className="h-3 w-3" />
                )}
                Contrast: {contrastRatio.toFixed(1)}:1
              </span>
            )}
          </div>
        </div>

        {/* Contrast Warning Banner */}
        {(isLowContrast || isIdenticalColor) && (
          <div
            role="alert"
            className="flex items-start gap-2 rounded-lg bg-amber-50 p-2.5 text-xs text-amber-800 border border-amber-200"
          >
            <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
            <span>
              {isIdenticalColor
                ? 'Foreground and background colors must be distinct for the QR code to be readable.'
                : 'Selected colors have low contrast ratio (< 3.5:1). Camera scanners may struggle to decode the QR code. We recommend high-contrast pairings.'}
            </span>
          </div>
        )}
      </div>

      {/* ================= GROUP B: QUICK COLOR PRESETS ================= */}
      <div className="space-y-2.5">
        <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase block">
          Visual Color Presets
        </span>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {QR_COLOR_PRESETS.map((preset) => {
            const isSelected = styleConfig.selectedPreset === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onApplyPreset(preset.id)}
                className={cn(
                  'flex items-center gap-2.5 rounded-xl border p-2 text-left transition-all focus-visible:outline-2 focus-visible:outline-indigo-600',
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-1 ring-indigo-600/20'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                )}
              >
                {/* Dual Color Swatch */}
                <div
                  className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-black/10 shadow-2xs"
                  style={{ backgroundColor: preset.backgroundColor }}
                >
                  <div
                    className="h-3 w-3 rounded-xs"
                    style={{ backgroundColor: preset.foregroundColor }}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="block text-xs font-semibold tracking-tight truncate">
                    {preset.name}
                  </span>
                </div>
                {isSelected && (
                  <Check className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= GROUP C: QR CODE SIZE ================= */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
            QR Code Resolution
          </span>
          <span className="font-mono text-xs text-slate-500 font-medium">
            {styleConfig.size} × {styleConfig.size} px
          </span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {QR_SIZES.map((sz) => {
            const isSelected = styleConfig.size === sz;
            return (
              <button
                key={sz}
                type="button"
                onClick={() => handleSizeChange(sz)}
                className={cn(
                  'rounded-xl border py-2 text-center text-xs font-semibold transition focus-visible:outline-2 focus-visible:outline-indigo-600',
                  isSelected
                    ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                )}
              >
                {sz} px
              </button>
            );
          })}
        </div>
        <p className="text-[11px] text-slate-500">
          Determines export image resolution. Preview remains contained on screen.
        </p>
      </div>

      {/* ================= GROUP D: ERROR CORRECTION LEVEL ================= */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
            Error Correction Level
          </span>
          {styleConfig.logo.enabled && (
            <span className="rounded-md bg-indigo-100 px-2 py-0.5 text-[10px] font-semibold text-indigo-800">
              High (H) enforced for logo
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {QR_ERROR_CORRECTION_LEVELS.map((info) => {
            const isSelected =
              (styleConfig.logo.enabled ? 'H' : styleConfig.errorCorrectionLevel) ===
              info.level;
            const isDisabled = styleConfig.logo.enabled && info.level !== 'H';

            return (
              <button
                key={info.level}
                type="button"
                disabled={isDisabled}
                onClick={() => handleLevelChange(info.level)}
                className={cn(
                  'flex flex-col items-center justify-between rounded-xl border p-2.5 text-center transition focus-visible:outline-2 focus-visible:outline-indigo-600',
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-1 ring-indigo-600/20'
                    : isDisabled
                    ? 'border-slate-200 bg-slate-100/60 text-slate-400 cursor-not-allowed opacity-60'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                )}
              >
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold">{info.level}</span>
                  <span className="text-[10px] text-slate-500">
                    ({info.recoveryPercentage})
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                  {info.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= GROUP E: OPTIONAL CENTER LOGO ================= */}
      <div className="space-y-4 rounded-xl border border-slate-200/80 bg-slate-50/50 p-4">
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2.5 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={styleConfig.logo.enabled}
              onChange={(e) => handleToggleLogo(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
            <span className="text-sm font-semibold text-slate-900">
              Add Logo to QR Code
            </span>
          </label>

          {styleConfig.logo.enabled && (
            <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-800">
              Active
            </span>
          )}
        </div>

        {styleConfig.logo.enabled && (
          <div className="space-y-4 pt-1 border-t border-slate-200/60">
            {/* Quick Logo Options */}
            <div>
              <span className="text-xs font-medium text-slate-700 block mb-2">
                Select Logo Asset:
              </span>
              <div className="flex flex-wrap items-center gap-2">
                {/* Option A: Use QR Studio Brand Logo */}
                <button
                  type="button"
                  onClick={handleSelectBrandLogo}
                  className={cn(
                    'inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-medium transition',
                    styleConfig.logo.dataUrl === BRAND_LOGO_SRC
                      ? 'border-indigo-600 bg-white text-indigo-950 ring-1 ring-indigo-600/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  )}
                >
                  <img
                    src={BRAND_LOGO_SRC}
                    alt="Brand Logo"
                    className="h-5 w-5 object-contain"
                  />
                  <span>QR Studio Brand</span>
                  {styleConfig.logo.dataUrl === BRAND_LOGO_SRC && (
                    <Check className="h-3 w-3 text-indigo-600" />
                  )}
                </button>

                {/* Option B: Upload Custom Logo */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition"
                >
                  <Upload className="h-3.5 w-3.5 text-slate-500" />
                  <span>Upload File</span>
                </button>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFileUpload}
                  className="hidden"
                  aria-label="Upload custom logo file"
                />

                {/* Remove Logo Button */}
                {styleConfig.logo.dataUrl && (
                  <button
                    type="button"
                    onClick={handleRemoveLogo}
                    className="inline-flex items-center gap-1 rounded-xl border border-red-200 bg-red-50/60 px-2.5 py-2 text-xs font-medium text-red-700 hover:bg-red-100/80 transition"
                    title="Remove center logo"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Remove</span>
                  </button>
                )}
              </div>
            </div>

            {/* Backing Shape Selector */}
            <div>
              <span className="text-xs font-medium text-slate-700 block mb-2">
                White Backing Shape:
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleBackingShapeChange('circle')}
                  className={cn(
                    'flex flex-1 items-center justify-center gap-2 rounded-xl border py-2 text-xs font-medium transition',
                    styleConfig.logo.backingShape === 'circle'
                      ? 'border-indigo-600 bg-white text-indigo-950 ring-1 ring-indigo-600/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  )}
                >
                  <div className="h-3.5 w-3.5 rounded-full border border-slate-400 bg-white" />
                  <span>Circular Backing</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleBackingShapeChange('rounded')}
                  className={cn(
                    'flex flex-1 items-center justify-center gap-2 rounded-xl border py-2 text-xs font-medium transition',
                    styleConfig.logo.backingShape === 'rounded'
                      ? 'border-indigo-600 bg-white text-indigo-950 ring-1 ring-indigo-600/20 shadow-xs'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  )}
                >
                  <div className="h-3.5 w-3.5 rounded-xs border border-slate-400 bg-white" />
                  <span>Rounded Square</span>
                </button>
              </div>
            </div>

            {/* Current Logo Badge & Safe Dimensions Note */}
            {styleConfig.logo.dataUrl && (
              <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-2.5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-slate-100 bg-slate-50 p-1">
                  <img
                    src={styleConfig.logo.dataUrl}
                    alt="Center logo preview"
                    className="h-full w-full object-contain"
                  />
                </div>
                <div className="min-w-0 flex-1 text-xs">
                  <span className="font-semibold text-slate-900 truncate block">
                    {styleConfig.logo.name || 'Center Logo'}
                  </span>
                  <span className="text-[11px] text-slate-500 block">
                    Auto-scaled to safe 16% width with protective quiet margin.
                  </span>
                </div>
              </div>
            )}

            <div className="flex items-start gap-2 text-xs text-slate-500">
              <ImageIcon className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
              <span>
                To preserve 100% scanning reliability, center logos are
                automatically paired with Error Correction Level H (~30% redundancy)
                and isolated by a clean white backing.
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
