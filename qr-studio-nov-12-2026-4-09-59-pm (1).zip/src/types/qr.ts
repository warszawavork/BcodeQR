export type QrCodeCategory = 'standard' | 'business';

/**
 * Extensible QR Code Type Identifiers across Standard and Business/Social categories.
 */
export type QrCodeType =
  | 'url'
  | 'text'
  | 'wifi'
  | 'vcard'
  | 'whatsapp'
  | 'reviews'
  | 'call'
  | 'maps';

export type WifiEncryptionType = 'WPA' | 'WEP' | 'nopass';

export type QrErrorCorrectionLevel = 'L' | 'M' | 'Q' | 'H';

export type QrExportFormat = 'png' | 'svg';

export interface UrlQrPayload {
  type: 'url';
  url: string;
}

export interface TextQrPayload {
  type: 'text';
  text: string;
}

export interface WifiQrPayload {
  type: 'wifi';
  ssid: string;
  password?: string;
  encryption: WifiEncryptionType;
  hidden: boolean;
}

export interface VCardQrPayload {
  type: 'vcard';
  firstName: string;
  lastName: string;
  organization?: string;
  title?: string;
  phone?: string;
  email?: string;
  website?: string;
  street?: string;
  city?: string;
  postalCode?: string;
  country?: string;
}

export interface WhatsAppQrPayload {
  type: 'whatsapp';
  phone: string;
  message?: string;
  url: string;
}

export interface GoogleReviewsQrPayload {
  type: 'reviews';
  businessName?: string;
  reviewUrl: string;
}

export interface CallUsQrPayload {
  type: 'call';
  phone: string;
  businessName?: string;
  telUri: string;
}

export interface GoogleMapsQrPayload {
  type: 'maps';
  locationName?: string;
  mapsUrl: string;
}

export interface WifiFormData {
  ssid: string;
  encryption: WifiEncryptionType;
  password?: string;
  hidden: boolean;
}

export interface VCardFormData {
  firstName: string;
  lastName: string;
  organization?: string;
  jobTitle?: string;
  phone?: string;
  email?: string;
  website?: string;
}

export interface WhatsAppFormData {
  phone: string;
  message: string;
}

export interface GoogleReviewsFormData {
  businessName: string;
  reviewUrl: string;
}

export interface CallFormData {
  phone: string;
  businessName: string;
}

export interface GoogleMapsFormData {
  locationName: string;
  mapsUrl: string;
}

/**
 * Discriminated union of all supported QR payload models.
 */
export type QrPayloadData =
  | UrlQrPayload
  | TextQrPayload
  | WifiQrPayload
  | VCardQrPayload
  | WhatsAppQrPayload
  | GoogleReviewsQrPayload
  | CallUsQrPayload
  | GoogleMapsQrPayload;

export type QrBackingShape = 'circle' | 'rounded';

export interface QrLogoConfig {
  enabled: boolean;
  dataUrl: string | null;
  name?: string;
  backingShape: QrBackingShape;
}

export interface QrColorPreset {
  id: string;
  name: string;
  foregroundColor: string;
  backgroundColor: string;
}

/**
 * Visual customization parameters for QR code rendering.
 */
export interface QrStyleConfig {
  size: number;
  margin: number;
  foregroundColor: string;
  backgroundColor: string;
  errorCorrectionLevel: QrErrorCorrectionLevel;
  selectedPreset?: string | null;
  logo: QrLogoConfig;
}

export interface UrlHistoryFormData {
  type: 'url';
  url: string;
  labelNote?: string;
}

export interface TextHistoryFormData {
  type: 'text';
  text: string;
  labelNote?: string;
}

export type QrHistoryFormData =
  | UrlHistoryFormData
  | TextHistoryFormData
  | ({ type: 'wifi' } & WifiFormData)
  | ({ type: 'vcard' } & VCardFormData)
  | ({ type: 'whatsapp' } & WhatsAppFormData)
  | ({ type: 'reviews' } & GoogleReviewsFormData)
  | ({ type: 'call' } & CallFormData)
  | ({ type: 'maps' } & GoogleMapsFormData);

/**
 * Persisted history entry stored in local IndexedDB browser storage.
 */
export interface QrHistoryItem {
  id: string;
  title: string;
  type: QrCodeType;
  category: QrCodeCategory;
  payload: string;
  formData: QrHistoryFormData;
  styleConfig: QrStyleConfig;
  createdAt: number;
  updatedAt: number;
  containsSensitiveData: boolean;
  logoData?: string | null;
}

/**
 * Metadata descriptor for registering QR code types in the UI and architecture.
 */
export interface QrTypeDefinition {
  id: QrCodeType;
  category: QrCodeCategory;
  label: string;
  description: string;
  iconName: string;
}
