import test from 'node:test';
import assert from 'node:assert/strict';
import { SUPPORTED_QR_TYPES, SIDEBAR_NAV_ITEMS } from '../lib/constants';
import { cn } from './cn';
import { isValidHexColor, isValidHttpUrl } from './validators';

test('cn joins non-empty class names cleanly', () => {
  assert.equal(cn('px-4', false, undefined, 'py-2', null), 'px-4 py-2');
});

test('isValidHexColor validates 3-digit and 6-digit hex colors', () => {
  assert.equal(isValidHexColor('#0F172A'), true);
  assert.equal(isValidHexColor('#fff'), true);
  assert.equal(isValidHexColor('0F172A'), false);
  assert.equal(isValidHexColor('#12345'), false);
});

test('isValidHttpUrl validates HTTP and HTTPS URLs accurately', () => {
  assert.equal(isValidHttpUrl('https://qrstudio.dev'), true);
  assert.equal(isValidHttpUrl('http://localhost:3000/test'), true);
  assert.equal(isValidHttpUrl('ftp://files.example.com'), false);
  assert.equal(isValidHttpUrl('not-a-url'), false);
});

test('SUPPORTED_QR_TYPES defines all 8 Standard and Business & Social options in order', () => {
  assert.deepEqual(
    SUPPORTED_QR_TYPES.map((t) => t.id),
    ['url', 'text', 'wifi', 'vcard', 'whatsapp', 'reviews', 'call', 'maps']
  );
  assert.deepEqual(
    SUPPORTED_QR_TYPES.map((t) => t.label),
    [
      'URL',
      'Text',
      'Wi-Fi',
      'vCard',
      'WhatsApp Chat',
      'Google Reviews',
      'Call Us',
      'Google Maps',
    ]
  );
});

test('SIDEBAR_NAV_ITEMS defines all 4 SaaS navigation sections with create active', () => {
  assert.equal(SIDEBAR_NAV_ITEMS.length, 4);
  assert.equal(SIDEBAR_NAV_ITEMS[0]?.id, 'create');
  assert.equal(SIDEBAR_NAV_ITEMS[0]?.label, 'Create QR Code');
});
