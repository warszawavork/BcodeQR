import type { QrColorPreset, QrErrorCorrectionLevel, QrStyleConfig, QrTypeDefinition } from '@/types';

export const APP_CONFIG = {
  name: 'QR Studio',
  subtitle: 'SMART QR CODE GENERATOR',
  version: '0.6.0',
  stage: 'Stage 6/10 — Customization & Brand Identity',
  storageKeys: {
    history: 'qr_studio_history_v1',
    preferences: 'qr_studio_preferences_v1',
  },
} as const;

export const QR_SIZES = [256, 512, 1024, 2048] as const;
export type QrSizeOption = (typeof QR_SIZES)[number];

export const QR_COLOR_PRESETS: readonly QrColorPreset[] = [
  {
    id: 'classic',
    name: 'Classic',
    foregroundColor: '#0F172A',
    backgroundColor: '#FFFFFF',
  },
  {
    id: 'midnight',
    name: 'Midnight',
    foregroundColor: '#111827',
    backgroundColor: '#F9FAFB',
  },
  {
    id: 'ocean',
    name: 'Ocean',
    foregroundColor: '#075985',
    backgroundColor: '#F0F9FF',
  },
  {
    id: 'emerald',
    name: 'Emerald',
    foregroundColor: '#065F46',
    backgroundColor: '#ECFDF5',
  },
  {
    id: 'royal-violet',
    name: 'Royal Violet',
    foregroundColor: '#5B21B6',
    backgroundColor: '#F5F3FF',
  },
  {
    id: 'crimson',
    name: 'Crimson',
    foregroundColor: '#991B1B',
    backgroundColor: '#FEF2F2',
  },
] as const;

export interface QrErrorCorrectionInfo {
  level: QrErrorCorrectionLevel;
  label: string;
  recoveryPercentage: string;
  description: string;
}

export const QR_ERROR_CORRECTION_LEVELS: readonly QrErrorCorrectionInfo[] = [
  {
    level: 'L',
    label: 'Low',
    recoveryPercentage: '~7%',
    description: 'Best for simple QR codes with minimal additional damage tolerance.',
  },
  {
    level: 'M',
    label: 'Medium',
    recoveryPercentage: '~15%',
    description: 'Balanced choice for everyday use and clean scanning.',
  },
  {
    level: 'Q',
    label: 'Quartile',
    recoveryPercentage: '~25%',
    description: 'Higher resistance to damage, suitable for outdoor prints.',
  },
  {
    level: 'H',
    label: 'High',
    recoveryPercentage: '~30%',
    description: 'Maximum error correction, automatically used when adding a center logo.',
  },
] as const;

export const DEFAULT_QR_STYLE: QrStyleConfig = {
  size: 512,
  margin: 4,
  foregroundColor: '#0F172A',
  backgroundColor: '#FFFFFF',
  errorCorrectionLevel: 'M',
  selectedPreset: 'classic',
  logo: {
    enabled: false,
    dataUrl: null,
    name: '',
    backingShape: 'circle',
  },
};

export const QR_CATEGORIES = [
  {
    id: 'standard' as const,
    label: 'Standard QR',
    description: 'URLs, plain text, Wi-Fi access, and digital business cards.',
  },
  {
    id: 'business' as const,
    label: 'Business & Social',
    description: 'WhatsApp chats, Google Reviews, direct calls, and Maps.',
  },
] as const;

export const SUPPORTED_QR_TYPES: readonly QrTypeDefinition[] = [
  // Standard Category
  {
    id: 'url',
    category: 'standard',
    label: 'URL',
    description: 'Open any website or web link when scanned.',
    iconName: 'Globe',
  },
  {
    id: 'text',
    category: 'standard',
    label: 'Text',
    description: 'Display plain text notes, codes, or messages.',
    iconName: 'FileText',
  },
  {
    id: 'wifi',
    category: 'standard',
    label: 'Wi-Fi',
    description: 'Connect to a wireless network automatically.',
    iconName: 'Wifi',
  },
  {
    id: 'vcard',
    category: 'standard',
    label: 'vCard',
    description: 'Share contact details and digital business card.',
    iconName: 'Contact',
  },
  // Business & Social Category
  {
    id: 'whatsapp',
    category: 'business',
    label: 'WhatsApp Chat',
    description: 'Start a WhatsApp conversation with pre-filled text.',
    iconName: 'MessageCircle',
  },
  {
    id: 'reviews',
    category: 'business',
    label: 'Google Reviews',
    description: 'Collect genuine reviews on your Google Business Profile.',
    iconName: 'Star',
  },
  {
    id: 'call',
    category: 'business',
    label: 'Call Us',
    description: 'Let customers call your business with a single tap.',
    iconName: 'PhoneCall',
  },
  {
    id: 'maps',
    category: 'business',
    label: 'Google Maps',
    description: 'Help customers navigate directly to your address.',
    iconName: 'MapPin',
  },
] as const;

export type SidebarNavId = 'create' | 'saved' | 'templates' | 'settings';

export interface SidebarNavItem {
  id: SidebarNavId;
  label: string;
  isAvailableInStage: boolean;
}

export const SIDEBAR_NAV_ITEMS: readonly SidebarNavItem[] = [
  { id: 'create', label: 'Create QR Code', isAvailableInStage: true },
  { id: 'saved', label: 'My QR Codes', isAvailableInStage: false },
  { id: 'templates', label: 'Templates', isAvailableInStage: false },
  { id: 'settings', label: 'Settings', isAvailableInStage: false },
] as const;
